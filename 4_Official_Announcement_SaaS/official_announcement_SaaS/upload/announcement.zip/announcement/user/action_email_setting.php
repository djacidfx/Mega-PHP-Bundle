<?php
ob_start();
session_start();
include("../admin/db/config.php");
include("../admin/db/function_xss.php");
// Checking User is logged in or not
if(!isset($_SESSION['user'])) {
	header('location: index.php');
	exit;
}
if($_POST['sub_submit_pr']){
	if($_POST['sub_submit_pr'] == 'Submit') {
		$adminEmail = filter_var($_POST['adminEmail'], FILTER_SANITIZE_EMAIL) ;
		$email_subscriber = filter_var($_POST['email_subscriber'], FILTER_SANITIZE_NUMBER_INT) ;
		$email_comment = filter_var($_POST['email_comment'], FILTER_SANITIZE_NUMBER_INT) ;
		$rec_email_comment = filter_var($_POST['rec_email_comment'], FILTER_SANITIZE_NUMBER_INT) ;
		$uid = filter_var($_POST['uid'], FILTER_SANITIZE_NUMBER_INT) ;
		$statement = $pdo->prepare("update user_saas set u_rec_email = '".$adminEmail."' , u_email_subscriber = '".$email_subscriber."' , u_email_comment = '".$email_comment."'  , u_rec_email_comment = '".$rec_email_comment."' where uid = '".$uid."'");
		$statement->execute() ;
		$form_message = "Email Settings Updated Successfully.";
		$output = array( 
						'form_message' => $form_message
					) ;
		echo json_encode($output);
		
	}
} 
?>
