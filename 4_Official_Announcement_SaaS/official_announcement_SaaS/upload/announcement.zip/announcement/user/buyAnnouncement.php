<?php include("header.php") ; ?>
<div class="container mar-top">
	<div class="row">
		<div class="col-lg-12 col-md-12">
			<div class="row">
				<div class="col-lg-3 col-md-3"></div>
				<div class="col-lg-6 col-md-6">
					<div class="card">
                		<div class="card-header bg-secondary text-white text-center"><h4> Buy Announcement Credit</h4></div>
                		<div class="card-body">
							<form action="payments.php" class="form-signin"  id="payment_form" method="post">
							<select name="item_number" class="selectPlan form-control" required >
							<option value="">Select Plan</option>
							<?php
							$plan = $pdo->prepare("select * from create_package where package_status = '1' order by package_id asc") ;
							$plan->execute();
							$planData = $plan->fetchAll(PDO::FETCH_ASSOC);
							foreach($planData as $data){
							?>
							<option value="<?php echo _e($data['package_id']); ?>"><?php echo _e($data['package_name']); ?></option>
							<?php
							}
							?>
							</select>
							<div class="row">
								<div class="col-lg-6">
									<div class="form-group mt-2">
										<label class="text-muted">Amount</label>
										<div class="input-group mb-3">
											<div class="input-group-prepend">
												<span class="input-group-text">(USD)&ensp;<b> $</b></span>
											</div>
											<input type="text" name="item_amount" id="price" class="form-control" placeholder="Amount" required autofocus readonly="readonly"> 
										</div>
										</div>
									</div>
									<div class="col-lg-6">
										<div class="form-group mt-2">
											<label class="text-muted">No. of Announcements Credit</label>
											<div class="input-group mb-3">
												
												<input type="text" name="item_credit" id="item_credit" class="form-control" placeholder="Announcements" required autofocus readonly="readonly"> 
											</div>
										</div>
								</div>
							</div>
							<div class="resl">
							<div class="form-group">
								<div class="row">
								<div class="col-lg-6">
									<label class="text-muted">Cardholder Name</label>
									<div class="input-group">
										<input type="text" class="form-control input-sm" name="name" id="name" placeholder="Cardholder Name" required autofocus maxlength="50" />
									</div>
								</div>
								
								<div class="col-lg-6">
									<label class="text-muted">Email</label>
									<div class="input-group">
										<input type="email" class="form-control input-sm" name="email" id="email" value="<?php echo $email ;?>" required autofocus readonly="readonly" />							
									</div>
								</div>
								</div>
							</div>
							<div class="form-group">
								<div class="row">
								<div class="col-lg-6">
									<label class="text-muted">Card Number</label>
									<div class="input-group">
										<div id="card_number" class="field form-control"></div>
									</div>
								</div>
								<div class="col-lg-3">
										<label class="text-muted">Expiry MM/YY</label>
										<div class="input-group">
											<div id="card_expiry" class="field"></div>
										</div>
									</div>
								<div class="col-lg-3">
										<label  class="text-muted">CVC</label>
										<div id="card_cvc" class="field"></div>
									</div> 
								</div>
							</div>
							<div class="form-group">
								<div class="row">
									<div class="col-lg-12 p-2"><div id="paymentResponse"></div> </div>
									<div class="col-lg-12 text-center">
										<input type='hidden' name='currency_code' value='USD'> 
										<input type="hidden" name="uId" value="<?php echo $id ; ?>" >
										<input type="hidden" name="username" value="<?php echo $username ; ?>" >
										<input type="hidden" name="pchse" value="<?php echo $purchase_announcements ; ?>" >
										<input type="hidden" name="creditLeft" value="<?php echo $announcement_left ; ?>" >
										<button type="submit" class="btn btn-sm btn-warning" id="submitBtn"><img src="images/Checkout.png" class="img-fluid w-75"  alt="Stripe Checkout"></button>
									</div> 
								</div>                     
							</div>
							</div>
						 </form>
			 				
                		</div>
           			 </div>
				</div>
				<div class="col-lg-3 col-md-3"></div>
			</div>
		</div>
	</div>
</div>
<?php include("stripefooter.php") ; ?>