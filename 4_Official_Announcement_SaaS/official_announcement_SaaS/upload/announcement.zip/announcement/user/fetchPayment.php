<?php
ob_start();
session_start();
include("../admin/db/config.php");
include("../admin/db/function_xss.php");
// Checking User is logged in or not
if(!isset($_SESSION['user'])) {
	header('location: index.php');
	exit;
}
$Statement = $pdo->prepare("SELECT * FROM payments WHERE uid = '".$_SESSION['user']['uid']."' order by id desc ");
$Statement->execute(); 
$total = $Statement->rowCount();    
$result = $Statement->fetchAll(PDO::FETCH_ASSOC); 
$output = array('data' => array());
$sum = 0 ;
if($total > 0) {
	$active = "";
	foreach($result as $row) {
		$sum = $sum + 1 ;
		$item_name = _e($row['item_name']) ;
		$announcement_credit = _e($row['announcement_credit']);
		$date = _e($row['created_date']);
		$date =  date('d F, Y',strtotime($date));
		$amount = _e($row['amount']) ;
		$amount = "$".$amount ;
		$txn_id = _e($row['txn_id']) ;
		$pay_method = _e($row['pay_method']) ;
		$status = _e($row['payment_status']);
		
		$output['data'][] = array( 		
		$sum,
		$date,
		$item_name,
		$announcement_credit,
		$amount,
		$txn_id,
		$status,
		$pay_method
		); 	
	}
}
echo json_encode($output);
?>