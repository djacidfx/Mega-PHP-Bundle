<?php
ob_start();
session_start();
include("../admin/db/config.php");
include("../admin/db/function_xss.php");
// Checking Admin is logged in or not
if(!isset($_SESSION['user'])) {
	header('location: index.php');
	exit;
}

if(isset($_POST['btn_action_sb']))
{
	if($_POST['btn_action_sb'] == 'add_code')
	{
		$first_no = code(1) ;
		$second_no = code(1) ;
		$output = '' ;
		$output = array( 
					'first_no' => $first_no,
					'second_no' => $second_no
					);
		echo json_encode($output);
	}
	if($_POST['btn_action_sb'] == 'Subscribe')
	{
		$err = 0 ;
		$first_no = code(1) ;
		$second_no = code(1) ;
		$subemail = filter_var($_POST['subemail'], FILTER_SANITIZE_EMAIL) ;
		$date = date('Y-m-d') ;
		$firstno = filter_var($_POST['firstno'], FILTER_SANITIZE_NUMBER_INT) ;
		$secondno = filter_var($_POST['secondno'], FILTER_SANITIZE_NUMBER_INT) ;
		$sumvalue = filter_var($_POST['sumvalue'], FILTER_SANITIZE_NUMBER_INT) ;
		$total = $firstno + $secondno ;
		if($total == $sumvalue) {
			$chk = $pdo->prepare("select * from user_tbl_subscriber where subscriber_email = '".$subemail."' and user_id = '".$_SESSION['user']['uid']."'");
			$chk->execute();
			$tot = $chk->rowCount();
			if($tot > 0) {
				$err = 0;
				$form_msg =  "Sorry, This email already Subscribed.";
				$output = array( 
						'first_no' => $first_no,
						'second_no' => $second_no,
						'form_msg' => $form_msg,
						'err' => '0'
						);
				echo json_encode($output);
			
			} else {
				$ins = $pdo->prepare("insert into user_tbl_subscriber (user_id,subscriber_email,subscriber_date)  values ('".$_SESSION['user']['uid']."','".$subemail."','".$date."')");
				$ins->execute();
				$err = 1;
				$form_msg =  "Susbcriber added successfully.";
				$output = array( 
						'form_msg' => $form_msg,
						'err' => '1'
						);
				echo json_encode($output);
			}
		} else {
			$err = 0 ;
			$form_msg =  "Sorry Your Sum is Wrong. Please Prove You are Human.";
			$output = array( 
					'first_no' => $first_no,
					'second_no' => $second_no,
					'form_msg' => $form_msg,
					'err' => '0'
					);
			echo json_encode($output);
		}
	}
}
?>