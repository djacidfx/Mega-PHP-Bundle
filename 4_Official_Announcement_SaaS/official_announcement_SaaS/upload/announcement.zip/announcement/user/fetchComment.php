<?php
ob_start();
session_start();
include("../admin/db/config.php");
include("../admin/db/function_xss.php");
// Checking Admin is logged in or not
if(!isset($_SESSION['user'])) {
	header('location: index.php');
	exit;
}
$Statement = $pdo->prepare("SELECT * FROM `user_comments` left JOIN user_announcement on (user_announcement.announcement_id = user_comments.announceID) left JOIN user_saas on (user_saas.uid = user_announcement.user_id) where user_saas.uid='".$_SESSION['user']['uid']."'  order by comment_id desc  ");
$Statement->execute(); 
$total = $Statement->rowCount();    
$result = $Statement->fetchAll(PDO::FETCH_ASSOC); 
$output = array('data' => array());
if($total > 0) {
	$active = "";
	foreach($result as $row) {
		$announceId = _e($row['announceID']) ;
		$announceText = strip_tags($row['announceText']);
		$commentDate = _e($row['comment_date']);
		$commentDate =  date('d F, Y',strtotime($commentDate));
		$status = _e($row['comment_status']);
		$commentId = _e($row['comment_id']) ;
		$commentText = strip_tags($row['comment_text']);
		$username = _e($row['fullname']) ; 
		$useremail = _e($row['useremail']) ; 
		$reply = strip_tags($row['admin_reply']) ; 
		if($status== 1) {
			// deactivate comment
			$active ="<b>Approved</b>";
			$banComment = '<button type="button" name="changeCommentStatus" id="'.$commentId.'" class="btn btn-danger btn-sm changeCommentStatus" data-status="0">Unapprove</button>';
		} else {
			// activate comment
			$active ="Unapproved";
			$banComment = '<button type="button" name="changeCommentStatus" id="'.$commentId.'" class="btn btn-success btn-sm changeCommentStatus" data-status="1">Approve</button>';
		} 
		$editComment = '<button type="button" name="editCommentStatus" id="'.$commentId.'" class="btn btn-light btn-sm editCommentStatus" ><i class="fa fa-pencil-alt"></i></button>'; 
		$output['data'][] = array( 
		$commentId,	
		$commentDate,
		$username,
		$useremail,	
		$announceId,
		$announceText,
		$commentText,
		$reply,
		$active,
		$editComment,
		$banComment
		); 	
	}
}
echo json_encode($output);
?>