<?php
ob_start();
session_start();
include("../admin/db/config.php");
include("../admin/db/function_xss.php");
// Checking Admin is logged in or not
if(!isset($_SESSION['user'])) {
	header('location: index.php');
	exit;
}
if($_POST['logo_submit_pr']){
	if($_POST['logo_submit_pr'] == 'Submit') {
		$newlogo = filter_var($_POST['newlogo'], FILTER_SANITIZE_URL) ;
		$altlogo = filter_var($_POST['altlogo'], FILTER_SANITIZE_STRING) ;
		$id = filter_var($_POST['uid'], FILTER_SANITIZE_NUMBER_INT) ;
		$statement = $pdo->prepare("select * from user_saas where uid = ?");
		$statement->execute(array($id)) ;
		$result = $statement->fetchAll(PDO::FETCH_ASSOC); 
		$user_ok = $statement->rowCount();
		if($user_ok > 0) {
				
					$update_password = $pdo->prepare("update user_saas set logo_url = ? , logo_alt = ? where uid = ?");
					$update_password->execute(array($newlogo,$altlogo,$id));
					$form_message = "Logo Updated Successfully.";
					$output = array( 
							'form_message' => $form_message
							) ;
					echo json_encode($output);
				
			
		} else {
			$form_message = "This is not authorized user.";
			$output = array( 
					'form_message' => $form_message
					) ;
			echo json_encode($output);
		}
	}
} 
?>