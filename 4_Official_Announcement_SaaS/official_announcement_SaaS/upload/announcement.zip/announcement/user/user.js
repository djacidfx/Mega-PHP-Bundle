// JavaScript Document
jQuery(function ($) {
	
	"use strict";
	
	function RemoveLastDirectoryPartOf(the_url)
	{
		var the_arr = the_url.split('/');
		the_arr.pop();
		return( the_arr.join('/') );
	}
	var base_url =  window.location.href;
	base_url = RemoveLastDirectoryPartOf(base_url) ;
	
	$(document).ready(function(){
	$(document).on("click","#hide", function() {
		$(".errorMessage").hide();
	});
    $(document).on('click','.show_more_announcement',function(){
        var ID = $(this).attr('id');
        $('.show_more_announcement').hide();
        $('#loader-icon').show();
        $.ajax({
            type:'POST',
            url:base_url+'/getAnnouncement.php',
            data:'id='+ID,
            success:function(html){
				$('#loader-icon').hide();
                $('#show_more_new_announcement'+ID).remove();
                $('.announce-res').append(html);
            }
        });
    });
	$(document).on('submit','.like_form', function(event){
		event.preventDefault();
		 var aID = $(this).attr('id');
		var form_data = $(this).serialize();
		$('#lik'+aID).attr('disabled','disabled');
		var LikeCount = parseInt($('#like_counting'+aID).val());
		LikeCount = parseInt(LikeCount + 1) ;
		$('.myLike'+aID).html('<b class="myFo">'+LikeCount+' Likes</b>');
		$.ajax({
			url:base_url+"/likeCount.php",
			method:"POST",
			data:form_data,
			beforeSend: function(){
			$('#preloader'+aID).show();
			},
			complete: function(){
			$('#preloader'+aID).hide();
			},
			success:function(data)
			{	
				$('.remove-messages'+aID).fadeIn().html('<div class="alert alert-info">'+(data)+'</div>');
						setTimeout(function(){
							$(".remove-messages"+aID).fadeOut("slow");
						},1000);
			}
		})
	});
	$(document).on('click', '.add_comment', function(){
		var cID = $(this).attr('id');
		$('#commentModal'+cID).modal('show');
		$('.comment_form')[0].reset();
		$('.modal-title').html("<i class='fa fa-comment'></i> Add Comment");
		$('#action').val('Add Comment');
		
	});
	$(document).on('submit','.comment_form', function(event){
		event.preventDefault();
		var newID = $(this).attr('id');
		$('#action').attr('disabled','disabled');
		var form_data = $(this).serialize();
		$.ajax({
			url:base_url+"/add_comment_action.php",
			method:"POST",
			data:form_data,
			success:function(data)
			{
				
				$('.comment_form')[0].reset();
				$('#commentModal'+newID).modal('hide');
				$('#commentSuccessModal').modal('show');
				$('#action').attr('disabled', false);
			}
		})
	});
	$(document).on('click','.showComment',function(){
        var comID = $(this).attr('id');
		$('.myComment'+comID).toggle('slow') ;
	});
	$(document).on('click','.show_more_comment',function(){
        var commentsID = $(this).attr('id');
		var ann = $(this).attr('class');
		ann = ann.replace("show_more_comment",'');
		ann = ann.replace("btn",'');
		ann = ann.replace("btn-light",'');
		ann = ann.replace("btn-sm",'');
		ann = ann.replace("ann",'');
		var nc = '.nc'+$.trim(ann) ;
        $(nc).hide();
       
        $.ajax({
            type:'POST',
            url:base_url+'/getComments.php',
            data:{id:commentsID,announceId:ann},
			beforeSend: function(){
			 $('#loader-icon').show();
			},
			complete: function(){
			 $('#loader-icon').hide();
			},
            success:function(data){
				var cl = '.myComment'+$.trim(ann) ;
				$('#loader-icon').hide();
                $('#show_more_new_comment'+commentsID).remove();
				$(cl).append(data);
            }
        });
    });
});
	$(document).on('click', '.subscribe', function(){
		var btn_action_sb = 'add_code';
		 $.ajax({
            url:base_url+"/add_code.php",
            method:"POST",
            data:{btn_action_sb:btn_action_sb},
            success:function(data)
            {
				data = JSON.parse(data);
				$('#firstno').val(data.first_no);
				$('#secondno').val(data.second_no);
				$('#newfirst').html(data.first_no);
				$('#newsecond').html(data.second_no);
				$('#subscribeModal').modal('show');
				$('.subscribe_form')[0].reset();
				$('.modal-title').html("<i class='fa fa-bell'></i> Susbcribe Now");
				$('#action_sb').val('Subscribe');
			}
		});
	});
	$(document).on('submit','.subscribe_form', function(event){
		event.preventDefault();
		$('#action_sb').attr('disabled','disabled');
		var form_data = $(this).serialize();
		$.ajax({
			url:base_url+"/add_code.php",
			method:"POST",
			data:form_data,
			success:function(data)
			{
				data = JSON.parse(data);
				if(data.err == 0) {
					$('#action_sb').attr('disabled',false);
					$('#firstno').val(data.first_no);
					$('#secondno').val(data.second_no);
					$('#newfirst').html(data.first_no);
					$('#newsecond').html(data.second_no);
					$('.remove-messages').fadeIn().html('<div  class="alert alert-danger errorMessage">'+data.form_msg+'<button type="button" class="close float-right" aria-label="Close" > <span aria-hidden="true" id="hide">&times;</span></button></div>');
				} else {
					$('.subscribe_form')[0].reset();
					$('#subscribeModal').modal('hide');
					$('#sbSuccessModal').modal('show');
					$('#action_sb').attr('disabled', false);
				}
			}
		})
	});
});