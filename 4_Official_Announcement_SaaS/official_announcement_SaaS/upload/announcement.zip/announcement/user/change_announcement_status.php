<?php
ob_start();
session_start();
include("../admin/db/config.php");
include("../admin/db/function_xss.php");
// Checking Admin is logged in or not
if(!isset($_SESSION['user'])) {
	header('location: index.php');
	exit;
}
if(isset($_POST['btn_action']))
{
	if($_POST['btn_action'] == 'changePinnedStatus')
	{
		$announceId = filter_var($_POST['announceId'], FILTER_SANITIZE_NUMBER_INT);
		$status = filter_var($_POST['status'], FILTER_SANITIZE_NUMBER_INT);
		if($announceId) { 
			$update_old = $pdo->prepare("UPDATE user_announcement SET pinned=?   WHERE user_id = '".$_SESSION['user']['uid']."'");
			$result_old = $update_old->execute(array("0"));
			$update = $pdo->prepare("UPDATE user_announcement SET pinned=?   WHERE announcement_id=?");
			$result_new = $update->execute(array($status,$announceId));
			if($result_new) {
				echo 'Pinned Status of Announcement changed .' ;		
			}
		}
	}
	if($_POST['btn_action'] == 'changeAnnounceStatus')
	{
		$announceId = filter_var($_POST['announceId'], FILTER_SANITIZE_NUMBER_INT);
		$status = filter_var($_POST['status'], FILTER_SANITIZE_NUMBER_INT);
		if($announceId) { 
			$update = $pdo->prepare("UPDATE user_announcement SET announcement_status=?   WHERE announcement_id=? and user_id = '".$_SESSION['user']['uid']."'");
			$result_new = $update->execute(array($status,$announceId));
			if($result_new) {
				echo 'Announcement status changed .' ;		
			}
		}
	}
	if($_POST['btn_action'] == 'changeComStatus')
	{
		$announceId = filter_var($_POST['announceId'], FILTER_SANITIZE_NUMBER_INT);
		$status = filter_var($_POST['status'], FILTER_SANITIZE_NUMBER_INT);
		if($announceId) { 
			$update = $pdo->prepare("UPDATE user_announcement SET comment_active=?   WHERE announcement_id=? and user_id = '".$_SESSION['user']['uid']."'");
			$result_new = $update->execute(array($status,$announceId));
			if($result_new) {
				echo 'Adding New Comments to Announcement status changed .' ;		
			}
		}
	}
	if($_POST['btn_action'] == 'fetch_announcement')
	{	
		if(!empty($_POST['announceId'])){
			$announceId = filter_var($_POST['announceId'], FILTER_SANITIZE_NUMBER_INT);
			$announce = $pdo->prepare("select * from user_announcement where announcement_id = ? and user_id = '".$_SESSION['user']['uid']."'");
			$announce->execute(array($announceId));
			$result = $announce->fetchAll(PDO::FETCH_ASSOC);
			foreach($result as $row) {
				$output['announcementId'] = _e($row['announcement_id']);
				$output['announcementText'] = strip_tags($row['announcement_text']);
				$output['announcementDate'] = _e($row['announcement_date']);
				$output['you_vid'] = _e($row['youtube_url']);
				$output['twitter_status'] = _e($row['twitter_url']);
				$output['fb_status'] = _e($row['fb_url']);
				$output['insta_status'] = _e($row['insta_url']);
			}
			echo json_encode($output) ;
		} else {
			echo "Error : Announcement Id is mandatory to View." ;
		}
	}
}
?>