<?php
ob_start();
session_start();
require_once('../admin/db/config.php');
require_once("../admin/db/function_xss.php");
if( !empty($_POST['email']) && !empty($_POST['password']) ){
	$email = filter_var($_POST['email'], FILTER_SANITIZE_STRING) ;
	$password = filter_var($_POST['password'], FILTER_SANITIZE_STRING) ;
	$userAuthentication =  $pdo->prepare("SELECT * FROM user_saas WHERE (u_email=? or u_username = ?) and u_blocked ='0'");
	$userAuthentication->execute(array($email,$email));
	$user_ok = $userAuthentication->rowCount();
	$userData = $userAuthentication->fetchAll(PDO::FETCH_ASSOC);
	if($user_ok > 0) {
		foreach($userData as $row){
			$auth_pass = _e($row['u_pass']) ;
		}
			if(password_verify($password, $auth_pass)) {
				$_SESSION['user'] = $row ;
				header("location: dashboard.php");
			} else {
				$_SESSION['error_message'] = 'Either wrong Email/Username or Password. Try Again.';
				header("location: index.php");
			}
	}
	else {
		$_SESSION['error_message'] = 'Either wrong Email/Username or Account Deactivated.';
		header("location: index.php");
	}

} else {
	$_SESSION['error_message'] = 'Email/Password cannot be empty.';
	header("location: index.php");
}
?>