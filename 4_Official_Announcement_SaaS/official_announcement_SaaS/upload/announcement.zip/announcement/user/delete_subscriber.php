<?php
ob_start();
session_start();
include("../admin/db/config.php");
include("../admin/db/function_xss.php");
// Checking Admin is logged in or not
if(!isset($_SESSION['user'])) {
	header('location: index.php');
	exit;
}

if(isset($_POST['btn_action']))
{
	if($_POST['btn_action'] == 'deleteSubscriber')
	{
		$delId = filter_var($_POST['delId'], FILTER_SANITIZE_NUMBER_INT);
		if($delId) { 
			$update = $pdo->prepare("DELETE FROM `user_tbl_subscriber`  WHERE id=?");
			$result_new = $update->execute(array($delId));
			if($result_new) {
				echo 'Subscriber Deleted Successfully.' ;		
			}
		}
	}
}
?>