<?php include("header.php") ; ?>
<div class="app-title">
        <div>
          <h1><i class="fa fa-laptop"></i> User Dashboard</h1>
          <p>Announcement Remaining : <?php echo $announcement_left ; ?> </p>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
        </ul>
 </div>
  <div class="row">
 		<div class="col-lg-12 col-md-12">
				<h5 class="border-bottom text-muted">Purchased Analysis</h5>
			</div>
        <div class="col-md-4 col-lg-4">
          <div class="widget-small primary coloured-icon"><i class="icon fa fa-bullhorn fa-3x"></i>
            <div class="info">
              <h5 class="font-italic text-muted">Announcements Purchased</h5>
              <p><b><?php echo count_total_purchased_announcement($pdo); ?></b></p>
            </div>
          </div>
        </div>
        <div class="col-md-4 col-lg-4">
          <div class="widget-small info coloured-icon"><i class="icon fa fa-dollar-sign fa-3x"></i>
            <div class="info">
              <h5 class="font-italic text-muted">Announcements Amount</h5>
              <p><b><?php echo count_total_amount_announcement($pdo) ; ?></b></p>
            </div>
          </div>
        </div>
        <div class="col-md-4 col-lg-4">
          <div class="widget-small warning coloured-icon"><i class="icon fa fa-check fa-3x"></i>
            <div class="info">
              <h5 class="font-italic text-muted">Announcements Credit</h5>
              <p><b><?php echo  $announcement_left ;  ?></b></p>
            </div>
          </div>
        </div>
        
      </div>
 <div class="row">
 		<div class="col-lg-12 col-md-12">
				<h5 class="border-bottom text-muted">Announcement Analysis</h5>
			</div>
        <div class="col-md-4 col-lg-4">
          <div class="widget-small primary coloured-icon"><i class="icon fa fa-bullhorn fa-3x"></i>
            <div class="info">
              <h5 class="font-italic text-muted">Total Announcements</h5>
              <p><b><?php echo count_total_announcement($pdo); ?></b></p>
            </div>
          </div>
        </div>
        <div class="col-md-4 col-lg-4">
          <div class="widget-small info coloured-icon"><i class="icon fa fa-check fa-3x"></i>
            <div class="info">
              <h5 class="font-italic text-muted">Active Announcements</h5>
              <p><b><?php echo count_total_active_announcement($pdo) ; ?></b></p>
            </div>
          </div>
        </div>
        <div class="col-md-4 col-lg-4">
          <div class="widget-small danger coloured-icon"><i class="icon fa fa-times fa-3x"></i>
            <div class="info">
              <h5 class="font-italic text-muted">Deactive Announcements</h5>
              <p><b><?php echo  count_total_deactive_announcement($pdo) ;  ?></b></p>
            </div>
          </div>
        </div>
        
      </div>
<div class="row">
 		<div class="col-lg-12 col-md-12">
				<h5 class="border-bottom text-muted">Comments Analysis</h5>
			</div>
        <div class="col-md-4 col-lg-4">
          <div class="widget-small primary coloured-icon"><i class="icon fa fa-comment fa-3x"></i>
            <div class="info">
			<a href="comments.php">
              <h5 class="font-italic text-muted">Total Comments</h5>
              <p><b><?php echo count_total_comments($pdo); ?></b></p>
			</a>
            </div>
          </div>
        </div>
		
        <div class="col-md-4 col-lg-4">
          <div class="widget-small info coloured-icon"><i class="icon fa fa-check fa-3x"></i>
            <div class="info">
			<a href="approvecomments.php">
              <h5 class="font-italic text-muted">Approved Comments</h5>
              <p><b><?php echo count_total_approved_comments($pdo) ; ?></b></p>
			</a>
            </div>
          </div>
        </div>
		
		
        <div class="col-md-4 col-lg-4">
          <div class="widget-small danger coloured-icon"><i class="icon fa fa-times fa-3x"></i>
            <div class="info">
			<a href="unapprovecomments.php">
              <h5 class="font-italic text-muted">Unapproved Comments</h5>
              <p><b><?php echo  count_total_unapproved_comments($pdo) ;  ?></b></p>
			</a>
            </div>
          </div>
        </div>
		
        
      </div>
<?php include("footer.php") ; ?>