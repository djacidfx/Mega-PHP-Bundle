<?php 
require_once('../admin/db/config.php') ;
require_once('../admin/db/function_xss.php') ;

if(isset($_POST['btn_action_sb']))
{
	if($_POST['btn_action_sb'] == 'add_code')
	{
		$first_no = code(1) ;
		$second_no = code(1) ;
		$output = '' ;
		$output = array( 
					'first_no' => $first_no,
					'second_no' => $second_no
					);
		echo json_encode($output);
	}
	if($_POST['btn_action_sb'] == 'Subscribe')
	{
		$err = 0 ;
		$first_no = code(1) ;
		$second_no = code(1) ;
		$subemail = filter_var($_POST['subemail'], FILTER_SANITIZE_EMAIL) ;
		$uid = filter_var($_POST['uId'], FILTER_SANITIZE_NUMBER_INT) ;
		$date = date('Y-m-d') ;
		$firstno = filter_var($_POST['firstno'], FILTER_SANITIZE_NUMBER_INT) ;
		$secondno = filter_var($_POST['secondno'], FILTER_SANITIZE_NUMBER_INT) ;
		$sumvalue = filter_var($_POST['sumvalue'], FILTER_SANITIZE_NUMBER_INT) ;
		$total = $firstno + $secondno ;
		if($total == $sumvalue) {
			$chk = $pdo->prepare("select * from user_tbl_subscriber where subscriber_email = '".$subemail."' and user_id = '".$uid."'");
			$chk->execute();
			$tot = $chk->rowCount();
			if($tot > 0) {
				$err = 0;
				$form_msg =  "Sorry, You already Subscribe Us.";
				$output = array( 
						'first_no' => $first_no,
						'second_no' => $second_no,
						'form_msg' => $form_msg,
						'err' => '0'
						);
				echo json_encode($output);
			
			} else {
				$ins = $pdo->prepare("insert into user_tbl_subscriber (user_id,subscriber_email,subscriber_date)  values ('".$uid."','".$subemail."','".$date."')");
				$ins->execute();
				$err = 1;
				$output = array( 
						'err' => '1'
						);
				echo json_encode($output);
			}
		} else {
			$err = 0 ;
			$form_msg =  "Sorry Your Sum is Wrong. Please Prove You are Human.";
			$output = array( 
					'first_no' => $first_no,
					'second_no' => $second_no,
					'form_msg' => $form_msg,
					'err' => '0'
					);
			echo json_encode($output);
		}
	}
}
?>