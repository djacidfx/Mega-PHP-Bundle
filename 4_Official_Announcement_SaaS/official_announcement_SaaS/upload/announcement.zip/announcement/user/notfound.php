<!DOCTYPE html>
<html>
<head>
	
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Not Found</title>
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<link rel="stylesheet" type="text/css" href="<?php echo $url ; ?>css/main.css" />
	<link rel="stylesheet" href="<?php echo $url ; ?>css/all.min.css">
	<link rel="stylesheet" href="<?php echo $url ; ?>css/Latofont.css">
	<link rel="stylesheet" href="<?php echo $url ; ?>css/Niconnefont.css">
</head>
<body class="myColor">
<main class="page-content">
    <div class="container-fluid">
      <div class="row">
	  	<div class="col-lg-12 col-md-12">
		<div class="row">
				<div class="col-md-3 col-lg-3"></div>
				<div class="col-md-6 col-lg-6">
					<div class="card-deck mb-3 text-center  ">
					<div class="card mb-3 box-shadow basic-my-div shadow-lg p-4">
						<h5 class="text-danger">Sorry, But The Announcement You are Looking for Disabled By Admin.</h5>
					</div>
					</div>
				</div>
				<div class="col-md-3 col-lg-3"></div>
		</div>
		</div>
	</div>
	</div>
</main>
</body>
</html>