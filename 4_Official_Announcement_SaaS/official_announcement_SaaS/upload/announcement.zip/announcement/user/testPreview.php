<?php
ob_start();
session_start();
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: 0"); 
include("../admin/db/config.php");
include("../admin/db/function_xss.php");
// Checking Admin is logged in or not
if(!isset($_SESSION['user'])) {
	header('location: index.php');
	exit;
}
$username = filter_var($_POST['username'], FILTER_SANITIZE_STRING) ;
$newurl = filter_var($_POST['newurl'], FILTER_SANITIZE_URL) ;
$newurl = $newurl."?cachebust=1" ;
$container = filter_var($_POST['container'], FILTER_SANITIZE_NUMBER_INT) ;
$check = $pdo->prepare("select * from user_saas where u_username = '".$username."'");
$check->execute();
$chk = $check->rowCount();
if($chk > 0) {
?>
<link type="text/css" rel="stylesheet" href="iframe.css" />
<?php if($container == "46") { ?>
	<div class="iframe-container-46">
<?php } if($container == "64") { ?>
	<div class="iframe-container-64">
<?php } if($container == "66") { ?>
	<div class="iframe-container-66">
<?php } if($container == "100") { ?>
	<div class="iframe-container-100">
<?php } ?>
		<iframe class="myIframe" src="<?php echo $newurl ; ?>" scrolling="yes"></iframe>
	</div>
<?php
}
?>