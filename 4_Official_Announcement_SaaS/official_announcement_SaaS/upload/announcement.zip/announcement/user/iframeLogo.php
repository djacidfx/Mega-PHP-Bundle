<?php include("header.php") ; ?>
<div class="container mar-top">
	<div class="row">
		<div class="col-lg-12 col-md-12">
			<div class="row">
				<div class="col-lg-3 col-md-3"></div>
				<div class="col-lg-6 col-md-6">
					<div class="card">
                		<div class="card-header bg-secondary text-white text-center"><h4> Iframe Logo</h4></div>
                		<div class="card-body">
							<form method="post" id="logo_validation" class="logo_validation">
								<div class="form-group">
									<label><i class="fa fa-link"></i> Image Link(Optional) <br><small>Complete Image Link hosted on your server (For Best View Width 150 px * Height 50 px Transparent png Image)</small></label>
									<input type="text" class="form-control" name="newlogo" id="newlogo" placeholder="https://www.example.com/images/SiteLogo.png" maxlength="100" value="<?php if(!empty($logoUrl)){ echo $logoUrl ; } ?>" >
								</div>
								<div class="form-group">
									<label><i class="fa fa-pencil"></i> Alt Text* <br><small>If no image link then this text showing.</small></label>
									<input type="text" class="form-control" name="altlogo" id="altlogo" placeholder="Username" maxlength="15" value="<?php if(!empty($altUrl)){ echo $altUrl ; } ?>" >
								</div>
								<div class="col-md-12 text-center">
									<div class="remove-messages"></div>
								<input type="hidden" name="uid" value="<?php echo $id ; ?>">
								<input type="hidden" name="logo_submit_pr" value="Submit" />
								<input type="submit" id="logo_submit" name="logo_submit" class="btn btn-primary text-center form_submit" value="Update Logo" />
								
								</div>
							</form>
                		</div>
           			 </div>
				</div>
				<div class="col-lg-3 col-md-3"></div>
			</div>
		</div>
	</div>
</div>
<?php include("footer.php") ; ?>