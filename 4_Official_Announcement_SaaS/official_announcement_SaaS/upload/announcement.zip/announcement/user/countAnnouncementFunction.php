<?php
function count_total_announcement($pdo){
	$Statement = $pdo->prepare("SELECT * FROM user_announcement WHERE user_id = '".$_SESSION['user']['uid']."'");
	$Statement->execute(); 
	$total = $Statement->rowCount();
	return $total ;
}
function count_total_active_announcement($pdo){
	$Statement = $pdo->prepare("SELECT * FROM user_announcement WHERE announcement_status = '1' and user_id = '".$_SESSION['user']['uid']."' ");
	$Statement->execute(); 
	$total = $Statement->rowCount();
	return $total ;
}
function count_total_deactive_announcement($pdo){
	$Statement = $pdo->prepare("SELECT * FROM user_announcement WHERE  announcement_status = '0'  and user_id = '".$_SESSION['user']['uid']."' ");
	$Statement->execute(); 
	$total = $Statement->rowCount();
	return $total ;
}
function count_total_comments($pdo){
	$Statement = $pdo->prepare("SELECT * FROM `user_comments` left JOIN user_announcement on (user_announcement.announcement_id = user_comments.announceID) left JOIN user_saas on (user_saas.uid = user_announcement.user_id) where user_saas.uid='".$_SESSION['user']['uid']."' ");
	$Statement->execute(); 
	$total = $Statement->rowCount();
	return $total ;
}
function count_total_approved_comments($pdo){
	$Statement = $pdo->prepare("SELECT * FROM `user_comments` left JOIN user_announcement on (user_announcement.announcement_id = user_comments.announceID) left JOIN user_saas on (user_saas.uid = user_announcement.user_id) where user_saas.uid='".$_SESSION['user']['uid']."' and comment_status = '1' ");
	$Statement->execute(); 
	$total = $Statement->rowCount();
	return $total ;
}
function count_total_unapproved_comments($pdo){
	$Statement = $pdo->prepare("SELECT * FROM `user_comments` left JOIN user_announcement on (user_announcement.announcement_id = user_comments.announceID) left JOIN user_saas on (user_saas.uid = user_announcement.user_id) where user_saas.uid='".$_SESSION['user']['uid']."' and   comment_status = '0' ");
	$Statement->execute(); 
	$total = $Statement->rowCount();
	return $total ;
}
function count_total_amount_announcement($pdo)
{
	$query = "SELECT sum(amount) as amt FROM payments WHERE payment_status = 'Success' AND uid = '".$_SESSION['user']['uid']."'";
	$statement = $pdo->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	$output = '';
	foreach($result as $row)
	{
		$output .= _e($row["amt"]);
	}
	if($output == '') {
		$output = 0 ;
	}
	return ($output);
}
function count_total_purchased_announcement($pdo)
{
	$query = "SELECT sum(announcement_credit) as credit FROM payments WHERE payment_status = 'Success' AND uid = '".$_SESSION['user']['uid']."'";
	$statement = $pdo->prepare($query);
	$statement->execute();
	$result = $statement->fetchAll();
	$output = '';
	foreach($result as $row)
	{
		$output .= _e($row["credit"]);
	}
	if($output == '') {
		$output = 0 ;
	}
	return ($output);
}
?>