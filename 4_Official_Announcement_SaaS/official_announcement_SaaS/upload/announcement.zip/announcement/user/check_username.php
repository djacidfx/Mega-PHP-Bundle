<?php
require_once("../admin/db/config.php");
require_once("../admin/db/function_xss.php");

if(isset($_POST['btn_action']))
{
	if($_POST['btn_action'] == 'fetch_username')
	{
		if(!empty($_POST['value'])){
			$value =  filter_var($_POST['value'], FILTER_SANITIZE_STRING);
			$chk = $pdo->prepare("select * from user_saas where u_username = ?") ;
			$chk->execute(array($value)) ;
			$ok = $chk->rowCount();
			$output = "";
			if($ok > 0) {
				$output = array( 
							'form_msg' => 'This Username is Not Available.',
							'err' => '1'
							
						) ;
				echo json_encode($output);
			} else {
				$output = array( 
							'form_msg' => 'Username is Available.',
							'err' => '0'
							
						) ;
				echo json_encode($output);
			}
		} 
	}
	
}
?>