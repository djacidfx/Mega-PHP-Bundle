<?php
ob_start();
session_start();
include("../admin/db/config.php");
include("../admin/db/function_xss.php");
// Checking User is logged in or not
if(!isset($_SESSION['user'])) {
	header('location: index.php');
	exit;
}
$admin = $pdo->prepare("SELECT * FROM user_saas WHERE uid = '".$_SESSION['user']['uid']."'");
$admin->execute();   
$admin_result = $admin->fetchAll(PDO::FETCH_ASSOC);
$total = $admin->rowCount();
foreach($admin_result as $adm) {
//escape all  data
	$email_subscriber = _e($adm['u_email_subscriber']);
	$rec_email = _e($adm['u_rec_email']);
	$announcement_left = _e($adm['announcement_left']);
}
if(isset($_POST['btn_action']))
{
	if($_POST['btn_action'] == 'check')
	{
		
		$output = '' ;
		if($announcement_left > '0'){
			$output = array( 
					'err' => '0'
					);
			echo json_encode($output);
		} else {
			$output = array( 
					'err' => '1'
					);
			echo json_encode($output);
		}
	}
}
?>