<?php include("header.php") ; 
if(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
         $url = "https://";   
   } else  {
         $url = "http://";  
	} 
    // Append the host(domain name, ip) to the URL.   
    $url.= $_SERVER['HTTP_HOST'];   
    
    // Append the requested resource location to the URL   
    $url.= $_SERVER['REQUEST_URI'];
	$iframeurl = $url."iframe.css" ;
	$replace = "";
	$url = str_replace('/iframePreview.php', '' . $replace . '/', $url); 
	$serverUrl = $url ; 
	$serverUrl .= $username ;
	$iframeUrl = $serverUrl."?cachebust=1" ;
?>
<div class="container mar-top">
	<div class="row">
		<div class="col-lg-12 col-md-12">
			<div class="row">
				<div class="col-lg-3 col-md-3"></div>
				<div class="col-lg-6 col-md-6">
					<div class="card">
                		<div class="card-header bg-secondary text-white text-center"><h4> Iframe Previews & Embed Code</h4></div>
                		<div class="card-body ">
							<form method="post" enctype="multipart/form-data" action="testPreview.php">
							
								<div class="form-group">
									<input type="hidden" name="newurl" value="<?php if(!empty($serverUrl)){ echo $serverUrl ; } ?>">
								</div>
								<div class="col-md-12 text-center">
								<input type="hidden" name="container" value="46" >
								<input type="hidden" name="username" value="<?php echo $username ; ?>">
								<div class="row">
								<div class="col-lg-6 text-center p-2">
								<input type="submit" name="submit_pre" class="btn btn-primary text-center form_submit" value="Preview Iframe 400px * 600px" />
								</div>
								<div class="col-lg-6 text-center p-2">
								<a href="#/" class="show-46 btn btn-success btn-md"> Embed Code</a> 
								</div>
								</div>
								</div>
							</form>
							<hr>
							<form method="post" enctype="multipart/form-data" action="testPreview.php">
								<div class="form-group">
									<input type="hidden" name="newurl" value="<?php if(!empty($serverUrl)){ echo $serverUrl ; } ?>">
								</div>
								<div class="col-md-12 text-center">
								<input type="hidden" name="container" value="64" >
								<input type="hidden" name="username" value="<?php echo $username ; ?>">
								<div class="row">
								<div class="col-lg-6 text-center p-2">
								<input type="submit" name="submit_pre" class="btn btn-primary text-center form_submit" value="Preview Iframe 600px * 400px" />
								</div>
								<div class="col-lg-6 text-center p-2">
								<a href="#/" class="show-64 btn btn-success btn-md"> Embed Code</a> 
								</div>
								</div>
								</div>
							</form>
							<hr>
							<form method="post" enctype="multipart/form-data" action="testPreview.php">
								<div class="form-group">
									<input type="hidden" name="newurl" value="<?php if(!empty($serverUrl)){ echo $serverUrl ; } ?>">
								</div>
								<div class="col-md-12 text-center">
								<input type="hidden" name="container" value="66" >
								<input type="hidden" name="username" value="<?php echo $username ; ?>">
								<div class="row">
								<div class="col-lg-6 text-center p-2">
								<input type="submit" name="submit_pre" class="btn btn-primary text-center form_submit" value="Preview Iframe 600px * 600px" />
								</div>
								<div class="col-lg-6 text-center p-2">
								<a href="#/" class="show-66 btn btn-success btn-md"> Embed Code</a> 
								</div>
								</div>
								</div>
							</form>
							<hr>
							<form method="post" enctype="multipart/form-data" action="testPreview.php">
								<div class="form-group">
									<input type="hidden" name="newurl" value="<?php if(!empty($serverUrl)){ echo $serverUrl ; } ?>">
								</div>
								<div class="col-md-12 text-center">
								<input type="hidden" name="container" value="100" >
								<input type="hidden" name="username" value="<?php echo $username ; ?>">
								<div class="row">
								<div class="col-lg-6 text-center p-2">
								<input type="submit" name="submit_pre" class="btn btn-primary text-center form_submit" value="Preview Iframe 100% * 100% &ensp;" />
								</div>
								<div class="col-lg-6 text-center p-2">
								<a href="#/" class="show-100 btn btn-success btn-md"> Embed Code</a> 
								</div>
								</div>
								</div>
							</form>
                		</div>
           			 </div>
				</div>
				<div class="col-lg-3 col-md-3"></div>
			</div>
		</div>
	</div>
</div>
<!--Iframe Embed Modal 400px * 600px-->
<div id="embedModal46" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title text-success"><i class="fa fa-clipboard"></i> Embed Code 400px * 600px</h4>
				
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<div class="row">
					<div class="col-lg-12">
						<textarea class="form-control" rows="8" readonly="readonly"><!--Put CSS Link in Head Part of Your Page-->
<link type="text/css" rel="stylesheet" href="<?php echo $url."iframe.css" ; ?>" />
<!--Put Iframe Link in Body Part of Your Page -->
<div class="iframe-container-46">
<iframe class="myIframe" src="<?php echo $iframeUrl ; ?>" scrolling="yes"></iframe>
</div></textarea>
					</div>
					<div class="col-lg-12 text-center p-2">
					<h6 class="text-muted justify-content-center"> Copy all the part and put it in right place on your page. Thanks.</h6>
					</div>
				</div>
			</div> 
			<div class="modal-footer"> 
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>
<!--Iframe Embed Modal 600px * 400px-->
<div id="embedModal64" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title text-success"><i class="fa fa-clipboard"></i> Embed Code 600px * 400px</h4>
				
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<div class="row">
					<div class="col-lg-12">
						<textarea class="form-control" rows="8" readonly="readonly"><!--Put CSS Link in Head Part of Your Page-->
<link type="text/css" rel="stylesheet" href="<?php echo $url."iframe.css" ; ?>" />
<!--Put Iframe Link in Body Part of Your Page -->
<div class="iframe-container-64">
<iframe class="myIframe" src="<?php echo $iframeUrl ; ?>" scrolling="yes"></iframe>
</div></textarea>
					</div>
					<div class="col-lg-12 text-center p-2">
					<h6 class="text-muted justify-content-center"> Copy all the part and put it in right place on your page. Thanks.</h6>
					</div>
				</div>
			</div> 
			<div class="modal-footer"> 
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>
<!--Iframe Embed Modal 600px * 600px-->
<div id="embedModal66" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title text-success"><i class="fa fa-clipboard"></i> Embed Code 600px * 600px</h4>
				
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<div class="row">
					<div class="col-lg-12">
						<textarea class="form-control" rows="8" readonly="readonly"><!--Put CSS Link in Head Part of Your Page-->
<link type="text/css" rel="stylesheet" href="<?php echo $url."iframe.css" ; ?>" />
<!--Put Iframe Link in Body Part of Your Page -->
<div class="iframe-container-66">
<iframe class="myIframe" src="<?php echo $iframeUrl ; ?>" scrolling="yes"></iframe>
</div></textarea>
					</div>
					<div class="col-lg-12 text-center p-2">
					<h6 class="text-muted justify-content-center"> Copy all the part and put it in right place on your page. Thanks.</h6>
					</div>
				</div>
			</div> 
			<div class="modal-footer"> 
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>
<!--Iframe Embed Modal 100% * 100%-->
<div id="embedModal100" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title text-success"><i class="fa fa-clipboard"></i> Embed Code 100% * 100%</h4>
				
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<div class="row">
					<div class="col-lg-12">
						<textarea class="form-control" rows="8" readonly="readonly"><!--Put CSS Link in Head Part of Your Page-->
<link type="text/css" rel="stylesheet" href="<?php echo $url."iframe.css" ; ?>" />
<!--Put Iframe Link in Body Part of Your Page -->
<div class="iframe-container-100">
<iframe class="myIframe" src="<?php echo $iframeUrl ; ?>" scrolling="yes"></iframe>
</div></textarea>
					</div>
					<div class="col-lg-12 text-center p-2">
					<h6 class="text-muted justify-content-center"> Copy all the part and put it in right place on your page. Thanks.</h6>
					</div>
				</div>
			</div> 
			<div class="modal-footer"> 
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>
<?php include("footer.php") ; ?>