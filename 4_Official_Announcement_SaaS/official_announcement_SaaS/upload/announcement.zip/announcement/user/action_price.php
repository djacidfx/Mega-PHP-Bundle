<?php
ob_start();
session_start();
require_once("../admin/db/config.php");
require_once("../admin/db/function_xss.php");
// Checking User is logged in or not
if($_SESSION['user'] == '' ){
	header('location: index.php');
	exit;
}
if(isset($_POST['btn_action']))
{
	if($_POST['btn_action'] == 'load_price')
	{
		if(!empty($_POST['sub_id'])){
			$price =  fill_package_price($pdo, filter_var($_POST['sub_id'], FILTER_SANITIZE_NUMBER_INT));
			$item_credit =  fill_package_announcement($pdo, filter_var($_POST['sub_id'], FILTER_SANITIZE_NUMBER_INT));
			$output = array( 
						'price' => $price,
						'item_credit' => $item_credit
						
					) ;
			echo json_encode($output);
		} else {
			$output = array( 
						'price' => ''
						
					) ;
			echo json_encode($output);
		}
	}
}
?>