<?php
require_once('../admin/db/config.php') ;
require_once('../admin/db/function_xss.php') ;
if(isset($_POST['btn_action']))
{
	if($_POST['btn_action'] == 'Submit')
	{
		$userIP = filter_var($_POST['user_ip'],FILTER_VALIDATE_IP) ;
		$announceId = filter_var($_POST['announceId'], FILTER_SANITIZE_NUMBER_INT) ;
		$like_counting = filter_var($_POST['like_counting'],FILTER_SANITIZE_NUMBER_INT) ;
		$like_counting = $like_counting + 1 ;
		$ins = $pdo->prepare("INSERT INTO user_announcement_like (announce_id, user_ip) VALUES (?,?)");
		$ins->execute(array($announceId,$userIP));
		$upd = $pdo->prepare("update user_announcement set like_count = '".$like_counting."' where announcement_id = '".$announceId."'");
		$upd->execute();
		if($ins) {
			echo "Thanks For Like." ;
		}
	}
}
?>