<?php
ob_start();
session_start();
include("../admin/db/config.php");
include("../admin/db/CSRF_Protect.php");
include("../admin/db/function_xss.php");
include("countAnnouncementFunction.php") ; 
$csrf = new CSRF_Protect();
// Checking User is logged in or not
if($_SESSION['user'] == '' ){
	header('location: index.php');
	exit;
}
$data = STRIPE_PUBLISHABLE_KEY ;
echo $data ;
?>