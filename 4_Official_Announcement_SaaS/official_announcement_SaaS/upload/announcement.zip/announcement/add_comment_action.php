<?php
include("admin/db/config.php");
include("admin/db/function_xss.php");
$admin = $pdo->prepare("SELECT * FROM ot_admin WHERE id = '1'");
$admin->execute();   
$admin_result = $admin->fetchAll(PDO::FETCH_ASSOC);
$total = $admin->rowCount();
foreach($admin_result as $adm) {
//escape all  data
	$email_comment = _e($adm['email_comment']);
	$rec_email = _e($adm['rec_email']);
	$rec_email_comment = _e($adm['rec_email_comment']);
}
if($_POST['btn_action']){
	if($_POST['btn_action'] == 'AddComment') {
		$fullname = filter_var($_POST['username'], FILTER_SANITIZE_STRING) ;
		$useremail = filter_var($_POST['useremail'], FILTER_SANITIZE_EMAIL) ;
		$comment = filter_var($_POST['comment'], FILTER_SANITIZE_STRING) ;
		$announcement_id = filter_var($_POST['announcement_id'], FILTER_SANITIZE_NUMBER_INT) ;
		$comment_date = filter_var($_POST['comment_date'], FILTER_SANITIZE_STRING) ;
		$announcement_text = filter_var($_POST['announcement_text'], FILTER_SANITIZE_STRING) ;
		$ins = $pdo->prepare("insert into comments (announceID,announceText,fullname,useremail,comment_text,comment_date) values (?,?,?,?,?,?)");
		$ins->execute(array($announcement_id,$announcement_text,$fullname,$useremail,$comment,$comment_date));
		if(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
			$url = "https://";   
	   	} else  {
			 $url = "http://";  
		} 
		// Append the host(domain name, ip) to the URL.   
		$url.= $_SERVER['HTTP_HOST'];   
		
		// Append the requested resource location to the URL   
		$url.= $_SERVER['REQUEST_URI'];
		$replace = "";
		$url = str_replace('/add_comment_action.php', '' . $replace . '/', $url); 
		$serverUrl = $url ; 
		$serverUrl .= "announce/".$announcement_id ;
		if($rec_email_comment == '1') {
			$to = $rec_email ;
			$subject = "New Comment on your Announcement" ;
			$headers .= 'MIME-Version: 1.0' . "\r\n" ;
			$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n" ; 
			$headers .= "X-Priority: 1 (Highest)\n";
			$headers .= "X-MSMail-Priority: High\n";
			$headers .= "Importance: High\n";
			$body = "<html><body><h3>User Name : ".$fullname."</h3><br><h3>User Email : ".$useremail."</h3><br><h2>".$announcement_text."</h2><br><br><h3>User Comment : ".$comment."</h3><br><b>View Announcement : ".$serverUrl."</b><br></body></html>";
			$mail_result = mail($to, $subject, $body, $headers);
		}
	}

}
?>