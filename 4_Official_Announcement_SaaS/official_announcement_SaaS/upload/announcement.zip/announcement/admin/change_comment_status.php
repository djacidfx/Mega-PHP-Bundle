<?php
ob_start();
session_start();
include("db/config.php");
include("db/function_xss.php") ;
// Checking Admin is logged in or not
if(!isset($_SESSION['admin'])) {
	header('location: login.php');
	exit;
}
$admin = $pdo->prepare("SELECT * FROM ot_admin WHERE id = '1'");
$admin->execute();   
$admin_result = $admin->fetchAll(PDO::FETCH_ASSOC);
$total = $admin->rowCount();
foreach($admin_result as $adm) {
//escape all  data
	$email_comment = _e($adm['email_comment']);
	$rec_email = _e($adm['rec_email']);
}
$headers = "";
if(isset($_POST['btn_action']))
{
	if($_POST['btn_action'] == 'changeCommentStatus')
	{
		$commentId = filter_var($_POST['commentId'], FILTER_SANITIZE_NUMBER_INT);
		$status = filter_var($_POST['status'], FILTER_SANITIZE_NUMBER_INT);
		if($commentId) { 
			$update = $pdo->prepare("UPDATE comments SET comment_status=?   WHERE comment_id=?");
			$result_new = $update->execute(array($status,$commentId));
			if($result_new) {
				echo 'Comment status changed .' ;		
			}
		}
	}
	if($_POST['btn_action'] == 'fetch_comment')
	{	
		if(!empty($_POST['commentId'])){
			$commentId = filter_var($_POST['commentId'], FILTER_SANITIZE_NUMBER_INT);
			$announce = $pdo->prepare("select * from comments where comment_id = ?");
			$announce->execute(array($commentId));
			$result = $announce->fetchAll(PDO::FETCH_ASSOC);
			foreach($result as $row) {
				$output['commentId'] = _e($row['comment_id']);
				$output['commentText'] = strip_tags($row['comment_text']);
				$output['commentDate'] = _e($row['comment_date']);
				$output['commentName'] = _e($row['fullname']);
				$output['commentEmail'] = _e($row['useremail']);
				$output['replyText'] = strip_tags($row['admin_reply']);
			}
			echo json_encode($output) ;
		} else {
			echo "Error : Comment Id is mandatory." ;
		}
	}
	if($_POST['btn_action'] == 'EditComment') {
		if(!empty($_POST['comment_date']) && !empty($_POST['commentText']) && !empty($_POST['comment_id']) && !empty($_POST['comment_name']) && !empty($_POST['comment_email']) ) {
			$commentId = filter_var($_POST['comment_id'], FILTER_SANITIZE_NUMBER_INT);
			$comment_date = filter_var(date($_POST['comment_date']) , FILTER_SANITIZE_STRING);
			$commentText = filter_var($_POST['commentText'], FILTER_SANITIZE_STRING) ;
			$commentName = filter_var($_POST['comment_name'], FILTER_SANITIZE_STRING) ;
			$commentEmail = filter_var($_POST['comment_email'], FILTER_SANITIZE_EMAIL) ;
			$replyText = filter_var($_POST['replyText'], FILTER_SANITIZE_STRING) ;
			$webUrl = filter_var($_POST['webUrl'], FILTER_SANITIZE_URL) ;
			$upd = $pdo->prepare("update comments set comment_text=? , comment_date=?, fullname = ?, useremail = ? , admin_reply = ? where comment_id = ?");
			$upd->execute(array($commentText,$comment_date,$commentName,$commentEmail,$replyText,$commentId));
			$announceId = $pdo->prepare("select announceID, announceText from comments where comment_id = '".$commentId."'");
			$announceId->execute();
			$result = $announceId->fetchAll(PDO::FETCH_ASSOC);
			foreach($result as $ann){
				$aId = _e($ann['announceID']) ;
				$announceText = strip_tags($ann['announceText']) ;
			}
			$newUrl = $webUrl.$aId ;
			if($upd) {
				if(!empty($replyText)){
					//auto approve comment because Admin Replied
					$approveComment = $pdo->prepare("update comments set comment_status='1' where comment_id = '".$commentId."'");
					$approveComment->execute();
					if($email_comment == '0') {
						echo 'Admin Replied Successfully & No Email sent to this User.' ;
					} else {
						$to = $commentEmail ;
						$subject = "Admin Replied on Your Comment" ;
						$from = "Email: ".$rec_email ;
						$headers .= 'MIME-Version: 1.0' . "\r\n" ;
						$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n" ; 
						$headers .= $from . "<br>" ;
						$headers .= "X-Priority: 1 (Highest)\n";
						$headers .= "X-MSMail-Priority: High\n";
						$headers .= "Importance: High\n";
						$body = "<html><body><h2>".$announceText."</h2><br><br><h3>Your Comment : ".$commentText."</h3><br><br><h3>Admin Reply : ".$replyText."<br><br><b>View Announcement : ".$newUrl ."</b><br></body></html>";
						$mail_result = mail($to, $subject, $body, $headers);
					}
					if($mail_result) {
						echo 'Admin Replied Successfully & Email sent to this User.' ;
					} else {
						echo 'Admin Replied Successfully & But problem in sending email. Try again.' ;
					}
				} else {
				echo 'Comment Edited Successfully .' ;
				}	 	
		} else {
			echo 'Something went wrong. Try again after Refresh the page.';
		}
	} else {
		echo "All fields are mandatory." ; 
	}
}
}
?>