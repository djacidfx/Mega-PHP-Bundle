<?php
ob_start();
session_start();
include("db/config.php");
include("db/CSRF_Protect.php");
include("db/function_xss.php");
include("countAnnouncementFunction.php") ; 
$csrf = new CSRF_Protect();
// Checking Admin is logged in or not
if($_SESSION['admin'] == '' ){
	header('location: index.php');
	exit;
}
$id = _e($_SESSION['admin']['id']) ; 
$admin = $pdo->prepare("SELECT * FROM ot_admin WHERE id = ?");
$admin->execute(array($id));   
$admin_result = $admin->fetchAll(PDO::FETCH_ASSOC);
$total = $admin->rowCount();
foreach($admin_result as $adm) {
//escape all  data
	$id = _e($adm['id']);
	$email   = _e($adm['admin_email']);
	$old_password = _e($adm['auth_pass']);
	$alignment = _e($adm['alignment']) ;
	$rec_email = _e($adm['rec_email']);
	$email_subscriber = _e($adm['email_subscriber']);
	$email_comment = _e($adm['email_comment']);
	$rec_email_comment = _e($adm['rec_email_comment']);
	$pay_email = _e($adm['pay_email']);
	$unblock_msg = strip_tags($adm['unblock_msg']);
	$free_announcement = _e($adm['free_announcement']);
	$chance = _e($adm['user_chance']);
	$annUrl = _e($adm['announcement_url']);
}
$lim = $pdo->prepare("select * from announcement_limit where id= '1'");
$lim->execute();
$limi = $lim->fetchAll(PDO::FETCH_ASSOC);
foreach($limi as $stLimit){
	$startLim = _e($stLimit['start_lim']);
	$endLim = _e($stLimit['load_lim']);
}

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Dashboard</title>

	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<link rel="stylesheet" href="css/main.css">
	<link rel="stylesheet" href="css/bootstrap-select.min.css">
	<link rel="stylesheet" href="css/all.min.css">
	<link rel="stylesheet" href="css/datepicker.css">
	<link rel="stylesheet" href="css/Latofont.css">
	<link rel="stylesheet" href="css/Niconnefont.css">
	
</head>
<body class="app sidebar-mini">
    <!-- Navbar-->
    <header class="app-header"><a class="app-header__logo" href="dashboard.php"><img src="images/siteLogo.png" class="img-fluid" alt="Logo"></a>
      <!-- Sidebar toggle button--><a class="app-sidebar__toggle" href="#" data-toggle="sidebar" aria-label="Hide Sidebar"><i class="fa fa-bars fa-2x"></i></a>
      <!-- Navbar Right Menu-->
      <ul class="app-nav">
        <!-- User Menu-->
        <li class="dropdown"><a class="app-nav__item" href="#" data-toggle="dropdown" aria-label="Open Profile Menu"><i class="fa fa-user fa-lg"></i></a>
          <ul class="dropdown-menu settings-menu dropdown-menu-right">
		  	<li><a class="dropdown-item"  href="change_email.php"><i class="fa fa-envelope"></i> Email</a></li>
            <li><a class="dropdown-item"  href="change_password.php"><i class="fa fa-key"></i> Password</a></li>
            <li><a class="dropdown-item" href="logout.php"><i class="fa fa-sign-out-alt fa-lg"></i> Logout</a></li>
          </ul>
        </li>
      </ul>
    </header>
    <!-- Sidebar menu-->
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
    <aside class="app-sidebar">
      <div class="app-sidebar__user"><i class="fa fa-user-secret fa-2x text-warning"></i>
        <div>
          <p class="app-sidebar__user-name"><?php echo $email ;?></p>
          <p class="app-sidebar__user-designation">Admin</p>
        </div>
      </div>
      <ul class="app-menu">
        <li><a class="app-menu__item" href="dashboard.php"><i class="app-menu__icon fa fa-laptop"></i><span class="app-menu__label">Dashboard</span></a></li>
		<li><a class="app-menu__item" href="payHistory.php"><i class="app-menu__icon fa fa-dollar-sign text-warning"></i><span class="app-menu__label text-warning"><b>Payments</b></span></a></li>
		<li><a class="app-menu__item" href="<?php echo $annUrl ; ?>" target="_blank"><i class="app-menu__icon fa fa-bookmark text-warning"></i><span class="app-menu__label text-warning"><b>Admin Annoucements</b></span></a></li>
		<li><a class="app-menu__item" href="users.php"><i class="app-menu__icon fa fa-users"></i><span class="app-menu__label">Users</span></a></li>
		<li><a class="app-menu__item" href="blockedusers.php"><i class="app-menu__icon fa fa-ban text-danger"></i><span class="app-menu__label  text-danger"><b>Blocked Users</b></span></a></li>
		<li><a class="app-menu__item" href="emailSetting.php"><i class="app-menu__icon fa fa-cog"></i><span class="app-menu__label"> Settings &ensp;<span class="badge badge-warning badge-pill">Imp</span></span></a></li>
		<li><a class="app-menu__item" href="addPlan.php"><i class="app-menu__icon fa fa-space-shuttle text-warning"></i><span class="app-menu__label text-warning"><b>Package</b></span></a></li>
		 <li><a class="app-menu__item" href="setLimit.php"><i class="app-menu__icon fa fa-cubes"></i><span class="app-menu__label">Set Limits</span></a></li>
		<li><a href="addAnnouncement.php" class="app-menu__item"><i class="app-menu__icon fa fa-pencil-alt"></i><span class="app-menu__label"> Announcements</span></a></li>
		<li><a href="subscribers.php" class="app-menu__item"><i class="app-menu__icon fa fa-chart-bar"></i><span class="app-menu__label"> Subscribers</span></a></li>
		<li><a href="comments.php" class="app-menu__item"><i class="app-menu__icon fa fa-comment"></i><span class="app-menu__label"> Comments</span></a></li>
		<li><a href="approvecomments.php" class="app-menu__item"><i class="app-menu__icon fa fa-check"></i><span class="app-menu__label"> Approved Comments</span></a></li>
		<li><a href="unapprovecomments.php" class="app-menu__item"><i class="app-menu__icon fa fa-times"></i><span class="app-menu__label"> Unapproved Comments</span></a></li>
		<li><a href="setalignment.php" class="app-menu__item"><i class="app-menu__icon fa fa-align-center"></i><span class="app-menu__label"> Design Alignment</span></a></li>
	  </ul>
    </aside>
    <main class="app-content">