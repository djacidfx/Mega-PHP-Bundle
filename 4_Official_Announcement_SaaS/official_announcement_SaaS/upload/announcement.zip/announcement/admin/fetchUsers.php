<?php
ob_start();
session_start();
include("db/config.php");
include("db/function_xss.php");
// Checking Admin is logged in or not
if(!isset($_SESSION['admin'])) {
	header('location: index.php');
	exit;
}
$Statement = $pdo->prepare("SELECT * FROM user_saas WHERE 1 order by uid desc ");
$Statement->execute(); 
$total = $Statement->rowCount();    
$result = $Statement->fetchAll(PDO::FETCH_ASSOC); 
$output = array('data' => array());
$sum = 0 ;
if($total > 0) {
	$active = "";
	foreach($result as $row) {
		$sum = $sum + 1 ;
		$email = _e($row['u_email']) ;
		$announcement_left = _e($row['announcement_left']);
		$date = _e($row['created_date']);
		$date =  date('d F, Y',strtotime($date));
		$purchase_announcements = _e($row['purchase_announcements']) ;
		$purchase_announcements = "$".$purchase_announcements ;
		$status = _e($row['u_status']) ;
		if($status == '1') {
			$status = "<b>Active</b>" ;
		} else {
			$status = "Not Active";
		}
		$blocked = _e($row['u_blocked']) ;
		if($blocked == '1') {
			$blocked = "<b>Yes</b>" ;
		} else {
			$blocked = "No";
		}
		$username = _e($row['u_username']);
		$uid = _e($row['uid']);
		$output['data'][] = array( 		
		$sum,
		$date,
		$uid,
		$username,
		$email,
		$announcement_left,
		$purchase_announcements,
		$status,
		$blocked
		); 	
	}
}
echo json_encode($output);
?>