<?php
ob_start();
session_start();
require_once('db/config.php');
require_once("db/function_xss.php");
// Checking Admin is logged in or not
if($_SESSION['admin'] == '' ){
	header('location: index.php');
	exit;
}
if(isset($_POST['submit'])){
	$align = filter_var($_POST['align'], FILTER_SANITIZE_NUMBER_INT) ;
	$upd = $pdo->prepare("update ot_admin set alignment = '".$align."'");
	$upd->execute();
	if($upd) {
		$_SESSION['error_message'] = 'Alignment Design Updated Successfully.';
		header("location: setalignment.php");
	} else {
		$_SESSION['error_message'] = 'Something went wrong. Try Again';
		header("location: setalignment.php");
	}
}
?>