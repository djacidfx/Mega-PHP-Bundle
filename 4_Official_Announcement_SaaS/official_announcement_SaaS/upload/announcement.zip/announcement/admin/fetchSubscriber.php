<?php
ob_start();
session_start();
include("db/config.php");
include("db/function_xss.php");
// Checking Admin is logged in or not
if(!isset($_SESSION['admin'])) {
	header('location: login.php');
	exit;
}
$Statement = $pdo->prepare("SELECT * FROM tbl_subscriber WHERE 1 order by id desc ");
$Statement->execute(); 
$total = $Statement->rowCount();    
$result = $Statement->fetchAll(PDO::FETCH_ASSOC); 
$sum = 0;
$output = array('data' => array());
if($total > 0) {
	$active = "";
	foreach($result as $row) {
		$sum = $sum + 1 ;
		$subId = _e($row['id']);
		$subEmail = _e($row['subscriber_email']);
		$subDate = _e($row['subscriber_date']);
		
		$deleteSubscriber = '<button type="button" name="deleteSubscriber" id="'.$subId.'" class="btn btn-light btn-sm deleteSubscriber" ><i class="fa fa-trash"></i></button>'; 
		$output['data'][] = array( 
		$sum,
		$subEmail,
		$subDate,
		$deleteSubscriber
		); 	
	}
}
echo json_encode($output);
?>