<?php
function count_total_announcement($pdo){
	$Statement = $pdo->prepare("SELECT * FROM admin_announcement WHERE 1  ");
	$Statement->execute(); 
	$total = $Statement->rowCount();
	return $total ;
}
function count_total_active_announcement($pdo){
	$Statement = $pdo->prepare("SELECT * FROM admin_announcement WHERE announcement_status = '1' ");
	$Statement->execute(); 
	$total = $Statement->rowCount();
	return $total ;
}
function count_total_deactive_announcement($pdo){
	$Statement = $pdo->prepare("SELECT * FROM admin_announcement WHERE  announcement_status = '0' ");
	$Statement->execute(); 
	$total = $Statement->rowCount();
	return $total ;
}
function count_total_comments($pdo){
	$Statement = $pdo->prepare("SELECT * FROM comments WHERE 1  ");
	$Statement->execute(); 
	$total = $Statement->rowCount();
	return $total ;
}
function count_total_approved_comments($pdo){
	$Statement = $pdo->prepare("SELECT * FROM comments WHERE comment_status = '1' ");
	$Statement->execute(); 
	$total = $Statement->rowCount();
	return $total ;
}
function count_total_unapproved_comments($pdo){
	$Statement = $pdo->prepare("SELECT * FROM comments WHERE  comment_status = '0' ");
	$Statement->execute(); 
	$total = $Statement->rowCount();
	return $total ;
}
function count_total_user($pdo){
	$Statement = $pdo->prepare("SELECT * FROM user_saas WHERE 1  ");
	$Statement->execute(); 
	$total = $Statement->rowCount();
	return $total ;
}
function count_total_verified_user($pdo){
	$Statement = $pdo->prepare("SELECT * FROM user_saas WHERE u_status = '1' ");
	$Statement->execute(); 
	$total = $Statement->rowCount();
	return $total ;
}
function count_total_unverified_user($pdo){
	$Statement = $pdo->prepare("SELECT * FROM user_saas WHERE  u_status = '0' ");
	$Statement->execute(); 
	$total = $Statement->rowCount();
	return $total ;
}
function count_total_blocked_user($pdo){
	$Statement = $pdo->prepare("SELECT * FROM user_saas WHERE  u_blocked = '1' ");
	$Statement->execute(); 
	$total = $Statement->rowCount();
	return $total ;
}
function count_total_package($pdo){
	$Statement = $pdo->prepare("SELECT * FROM create_package WHERE 1  ");
	$Statement->execute(); 
	$total = $Statement->rowCount();
	return $total ;
}
function count_total_active_package($pdo){
	$Statement = $pdo->prepare("SELECT * FROM create_package WHERE package_status = '1' ");
	$Statement->execute(); 
	$total = $Statement->rowCount();
	return $total ;
}
function count_total_unactive_package($pdo){
	$Statement = $pdo->prepare("SELECT * FROM create_package WHERE  package_status = '0' ");
	$Statement->execute(); 
	$total = $Statement->rowCount();
	return $total ;
}
function count_total_earning($pdo){
	$Statement = $pdo->prepare("SELECT sum(amount) as amt FROM payments WHERE payment_status = 'Success'  ");
	$Statement->execute(); 
	$total = $Statement->rowCount();
	$result = $Statement->fetchAll(PDO::FETCH_ASSOC);
	$amt = "" ;
	foreach($result as $row) {
		$amt = _e($row['amt']) ;
	}
	if(!empty($amt)) {
		return $amt ;
	} else {
		$amt = 0 ;
		return $amt ;
	}
}
function count_total_earning_curmonth($pdo){
	$firstDay = date('Y-m-1') ;
	$lastDay = date('Y-m-t') ;
	$Statement = $pdo->prepare("SELECT sum(amount) as amt FROM payments WHERE payment_status = 'Success' and created_date between '".$firstDay."' and '".$lastDay."'");
	$Statement->execute(); 
	$total = $Statement->rowCount();
	$result = $Statement->fetchAll(PDO::FETCH_ASSOC);
	$amt = "" ;
	foreach($result as $row) {
		$amt = _e($row['amt']) ;
	}
	if(!empty($amt)) {
		return $amt ;
	} else {
		$amt = 0 ;
		return $amt ;
	}
}
function count_total_earning_curday($pdo){
	$today = date('Y-m-d') ;
	$Statement = $pdo->prepare("SELECT sum(amount) as amt FROM payments WHERE payment_status = 'Success' and created_date = '".$today."'");
	$Statement->execute(); 
	$total = $Statement->rowCount();
	$result = $Statement->fetchAll(PDO::FETCH_ASSOC);
	$amt = "" ;
	foreach($result as $row) {
		$amt = _e($row['amt']) ;
	}
	if(!empty($amt)) {
		return $amt ;
	} else {
		$amt = 0 ;
		return $amt ;
	}
}
?>