<?php
ob_start();
session_start();
include("db/config.php");
include("db/function_xss.php");
// Checking Admin is logged in or not
if($_SESSION['admin'] == '' ){
	header('location: index.php');
	exit;
}
$Statement = $pdo->prepare("SELECT * FROM create_package WHERE 1 order by package_id desc");
$Statement->execute(); 
$total = $Statement->rowCount();    
$result = $Statement->fetchAll(PDO::FETCH_ASSOC); 
$sum = 0;
$output = array('data' => array());
if($total > 0) {
	$statuss = "";
	foreach($result as $row) {
		$sum = $sum + 1;
		$id = _e($row['package_id']);
		$sub_name = strip_tags($row['package_name']);
		$package_number = _e($row['announcement_number']);
		$price = "$" ;
		$price .= _e($row['package_price']);
		
		$date = _e($row['package_date']);
		$date =  date('d F, Y',strtotime($date));
		$statuss = _e($row['package_status']);
		if($statuss == 1) {
			// Deactivate  Plan
			$statuss = "<b>Active</b>";
			$myLink = '<button type="button" name="changePlanStatus" id="'.$id.'" class="btn btn-danger btn-sm changePlanStatus" data-status="0"><i class="fa fa-ban"></i></button>';
			
		} else {
			// Activate  Plan
			$statuss = "Not Active";
			$myLink = '<button type="button" name="changePlanStatus" id="'.$id.'" class="btn btn-success btn-sm changePlanStatus" data-status="1"><i class="fa fa-check-circle"></i></button>';
			
		}
		$editPlan = '<button type="button" name="editPlan" id="'.$id.'" class="btn btn-default btn-sm editPlan"><i class="fa fa-pencil-alt"></i></button>';
		$output['data'][] = array( 		
		$sum, 
		$id,
		$date,
		$sub_name,
		$package_number,
		$price,
		$statuss,
		$editPlan,
		$myLink		
		); 	
	}
}
echo json_encode($output);
?>