<?php 
require_once('header.php');
?>
<main class="page-content">
	<div class="container-fluid">
      	<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="row">
		   			<div class="col-md-12 col-lg-12">
						<div class="panel panel-default">
							<div class="panel-heading">
								<div class="page-heading d-inline"><h5 class="text-left">Manage Subscribers
									</h5>
								</div>
								<hr>
								<button class="btn btn-info  m-1 subscribe" id="subscribe"><i class="fa fa-plus-square"></i> Add Subscriber</button>
							</div> <!-- /panel-heading -->
							<div class="panel-body">
								<div class="remove-messages"></div>
								<div class="row">
									<div class="col-md-12">
									  <div class="tile">
										<div class="tile-body">
											<div class="table-responsive">
												<table class="table table-bordered table-hover" id="manageSubscriberTable">
													<thead>
														<tr>
															<th>S.No.</th>
															<th>Subscriber Email</th>	
															<th>Date</th>	
															<th><i class="fa fa-trash"></i></th>
														</tr>
													</thead>
												</table><!-- /table -->
											</div>
										</div>
									</div>
								</div>
							</div>
							</div> <!-- /panel-body -->
					</div> <!-- /panel -->	
					</div>
				</div>
			</div>
		</div>
	</div>
</main><!-- page-content" -->
	<!-- Add Subscriber Modal -->
	<div id="subscribeModal" class="modal fade subscribeModal">
	<div class="modal-dialog">
		<form method="post" class="subscribe_form">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title text-success"><i class="fa fa-bell"></i> Subscribe Now</h4>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<div class="form-group mb-3">
						<input type="email" name="subemail" id="subemail" class="form-control" placeholder="Email Address*" maxlength="50" required autofocus>
						
					</div> 
					<div class="form-group text-left">
						<label for="message"><i class="fa fa-user-circle text-success"></i> Prove, You are Human*</label>
						<div class="input-group mb-3">
							<div class="input-group-prepend">
								<span class="input-group-text" id="basic-addon1"><span id="newfirst"></span>+<span id="newsecond"></span>
							</div>
							<input type="text" class="form-control" placeholder="Sum & Enter Value" name="sumvalue" id="sumvalue" autocomplete="off" >
						</div>
					</div>
					<div class="remove-messagess"></div>
				</div> 
				<div class="modal-footer"> 
					<input type="hidden" name="firstno"  id="firstno" />
					<input type="hidden" name="secondno" id="secondno" />
					<input type="hidden" name="btn_action_sb" id="btn_action_sb" value="Subscribe" />
					<input type="submit" name="action_sb" id="action_sb" class="btn btn-info" value="Subscribe" />
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				</div>
			</div>
		</form>
	</div>
</div>
	<!-- View Youtube Video Modal -->
	<div id="youtubeModal" class="modal fade youtubeModal">
    	<div class="modal-dialog">
    			<div class="modal-content">
    				<div class="modal-header">
						<h4 class="modal-title"><i class="fa fa-video"></i> Youtube Video</h4>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						  <span aria-hidden="true">&times;</span>
						</button>
    				</div>
    				<div class="modal-body1 text-center">
    				</div> 
    				<div class="modal-footer"> 
    					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
    				</div>
    			</div>
    		
    	</div>
    </div>
<?php require_once('footer.php'); ?>


