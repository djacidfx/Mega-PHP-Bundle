<?php
require_once('admin/db/config.php') ;
require_once('admin/db/function_xss.php') ;
if(!empty($_POST["id"]) && !empty($_POST['announceId']) ){
	$sql = "SELECT count(*) as comment_number_rows FROM comments WHERE comment_status='1' and comment_id < ".$_POST['id']." and announceId = '".$_POST['announceId']."' order by comment_id desc " ;
	$admin_announcement = $pdo->prepare($sql);
	$admin_announcement->execute(); 
	$announcement = $admin_announcement->fetchAll(PDO::FETCH_ASSOC);
	
	$limit = "3";
	foreach($announcement as $row) {
		$totalRows = _e($row['comment_number_rows']);
	}
	$statement = $pdo->prepare("select * from comments WHERE comment_status='1' and comment_id < ".$_POST['id']." and announceId = '".$_POST['announceId']."' order by comment_id desc Limit ".$limit."");
	$statement->execute();
	$total = $statement->rowCount();
	$announ = $statement->fetchAll(PDO::FETCH_ASSOC);
	if($total > 0) {
		foreach($announ as $notice) {
						$commentId = _e($notice['comment_id']) ;
						$username = _e($notice['fullname']) ;
						$comment_text = strip_tags($notice['comment_text']) ;
						$commentDate = _e($notice['comment_date']);
						$adminReply = strip_tags($notice['admin_reply']);
						$commentDate =  date('d F, Y',strtotime($commentDate));
						$announceId = _e($notice['announceID']) ;
						?>
						
									<div class="col-lg-12 col-md-12">
										<i class="fa fa-user text-secondary"></i>  &ensp;<?php echo $username ; ?>&ensp;-&ensp;<small><?php echo $commentDate ; ?></small>
									</div>
									<?php if(empty($adminReply)){ ?>
									<div class="col-lg-12 col-md-12 text-muted ml-4 mt-1">
										 <?php echo nl2br($comment_text) ; ?>
									</div>
									<?php } else { ?>
									<div class="col-lg-12 col-md-12 text-muted ml-4 mt-1 border bg-white">
										<div class="mt-2">
										 <?php echo nl2br($comment_text) ; ?>
										 <hr />
										</div>
										<div>
										<i class="fa fa-user-secret text-secondary"></i>  &ensp;Admin&ensp;<i class="fa fa-check-circle text-success"></i> <br /><?php echo nl2br($adminReply) ; ?>
										</div>
									</div>
									<?php } ?>
									<hr />
									
						<?php
					}
					?>
					<?php if($totalRows > $limit){ ?>
						<div class="show_more_new_comment" id="show_more_new_comment<?php echo $commentId; ?>">
							
									<div class="col text-center p-2">
									<div id="loader-icon"><img src="admin/images/LoaderIcon.gif" class="img-fluid w-25" /></div>
									<button id="<?php echo $commentId; ?>" class="show_more_comment btn btn-light btn-sm ann<?php echo $announceId ; ?>" >Load More Comment</button>
									</div>
									
								</div>
					<?php
					} else {
					?>
						<div class="col text-center p-2"><button  class="disabled btn btn-danger btn-sm" >No More Comments</button></div>
					<?php
					}
	
	}
}
?>