<?php
ob_start();
session_start();
require_once('admin/db/config.php');
require_once("admin/db/function_xss.php");
require_once("admin/db/api_otp_generate.php");
require_once("admin/db/CSRF_Protect.php");
$csrf = new CSRF_Protect();
unset($_SESSION['LastRequest']);
$admin = $pdo->prepare("SELECT * FROM ot_admin WHERE admin_status=?");
$admin->execute(array(filter_var("1", FILTER_SANITIZE_NUMBER_INT)));   
$admin_result = $admin->fetchAll(PDO::FETCH_ASSOC);
foreach($admin_result as $adm) {
//escape admin email
	$admin_email   = _e($adm['email']);
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Contact Us</title>
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<meta name="description" content="Contact Us">
	<link rel="stylesheet" href="cformcss/main.css">
	<link rel="stylesheet" href="cformcss/all.min.css">
	<link rel="stylesheet" href="cformcss/custom.css" />
	<link rel="stylesheet" href="cformcss/Latofont.css">
	<link rel="stylesheet" href="cformcss/Niconnefont.css">
</head>

<body>
<div id="logreg-forms" class="shadow-lg">
<div class="modal-header justify-content-center bg-secondary">
		<img src="images/siteLogo.png" class="img-fluid"  alt="Logo">
  </div>
			<?php 
					if(! empty($_SESSION['error_message'])){ ?>
						<div  class="alert alert-danger errorMessage">
						<button type="button" class="close float-right" aria-label="Close" >
						  <span aria-hidden="true" id="hide">&times;</span></button>
				<?php
						echo $_SESSION['error_message'] ;
						unset($_SESSION['error_message']);
				?>
						</div>
			<?php } ?>
			<div class="remove-messages"></div>
        	
			
			<div class="removecontact-messages"></div>
			<form class="form-signin form_validation" method="post">
				<h5 class="d-flex justify-content-center text-muted"> Never Hesitate to Contact Us. </h5>
				<input type="text" name="resetName" id="resetName" class="form-control" placeholder="Full Name*" maxlength="20" required autofocus>
                <input type="email" name="resetEmail" id="resetEmail" class="form-control" placeholder="Email Address*" maxlength="50" required autofocus>
				<select name="subject" id="subject" class="form-control selectpicker text-muted" data-live-search="true" data-style="warning"  required>
					<option value="" class="">Select Subject*</option>
					<?php 
						$select = $pdo->prepare("select * from ticket_subject where subject_status = '1' order by subject_id asc") ;
						$select->execute() ;
						$result = $select->fetchAll(PDO::FETCH_ASSOC); 
						foreach($result as $sel) {
						?>
							<option value="<?php echo _e($sel['subject_name']) ; ?>"><?php echo _e($sel['subject_name']) ; ?></option>
						<?php
						}
						?>
				</select>
				<textarea class="form-control" id="message" name="message" placeholder = "Message*" required autofocus></textarea>
				<div class="form-group mt-2">
				<label class="text-muted">Prove, You are Human*</label>
				<span id="form_numbers">
				<?php
					$first_no = code(1) ;
					$second_no = code(1) ;
				?>
				</span>
				<input type="hidden" name="firstno" value="<?php echo $first_no ; ?>" id="firstno" />
				<input type="hidden" name="secondno" value="<?php echo $second_no ; ?>" id="secondno" />
				<div class="form-group text-left">
					<div class="input-group mb-3">
						<div class="input-group-prepend">
							<span class="input-group-text" id="basic-addon1"><span id="newfirst"><?php echo $first_no ; ?></span>+<span id="newsecond"><?php echo $second_no ; ?></span></span>						</div>
						<input type="text" class="form-control" placeholder="Sum & Enter Value" name="sumvalue" id="sumvalue" autocomplete="off" required >
					</div>
				</div>
				</div>
                <input type="hidden" name="form_submit_pr" value="Submit" />
				<div class="text-center"><input type="submit" id="form_submit" name="form_submit" class="btn btn-success btn-md form_submit" value="Send Message" /></div>
            </form>
            
			
            <br>
            
</div>

<script type="text/javascript" src="cformjs/jquery-3.5.0.min.js"></script>
<script type="text/javascript" src="cformjs/popper.min.js"></script>
<script type="text/javascript" src="cformjs/bootstrap.min.js"></script>
<script type="text/javascript" src="cformjs/custom.js"></script>
</body>
</html>
