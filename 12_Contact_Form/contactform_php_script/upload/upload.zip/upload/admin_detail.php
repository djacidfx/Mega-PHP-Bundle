<?php
require_once('admin/db/config.php');
require_once("admin/db/function_xss.php");
require_once("admin/db/api_otp_generate.php");
$adminStatement = $pdo->prepare("select * from ot_admin where id = '1'");
$adminStatement->execute();
$result = $adminStatement->fetchAll(PDO::FETCH_ASSOC);
foreach($result as $row) {
	$admin_email = _e($row['email']) ;
}
if(isset($_POST['form_submit_pr'])) {
	if($_POST['form_submit_pr'] == 'Submit') {
		$name = filter_var($_POST['resetName'], FILTER_SANITIZE_STRING) ;
		$email = filter_var($_POST['resetEmail'], FILTER_SANITIZE_EMAIL) ;
		$subject = filter_var($_POST['subject'], FILTER_SANITIZE_STRING) ;
		$message = filter_var($_POST['message'], FILTER_SANITIZE_STRING) ;
		$firstno = filter_var($_POST['firstno'], FILTER_SANITIZE_NUMBER_INT) ;
		$secondno = filter_var($_POST['secondno'], FILTER_SANITIZE_NUMBER_INT) ;
		$sumvalue = filter_var($_POST['sumvalue'], FILTER_SANITIZE_NUMBER_INT) ;
		$date = filter_var(date("Y-m-d"), FILTER_SANITIZE_STRING) ;
		$headers = '';
		$body = '' ;
		$total = $firstno + $secondno ;
		if(!empty($name) && !empty($email) && !empty($subject) && !empty($message) && !empty($firstno) && !empty($secondno) && !empty($sumvalue) ){
			if($total == $sumvalue) {
				$to = $admin_email ;
				$from = $email ;
				$headers  = 'MIME-Version: 1.0' . "\r\n";
				$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
				$headers .= 'From: '.$from.'' . "\r\n";
				$body = "Name : ".$name."<br>Email : ".$email."<br>Phone : ".$phone."<br>Subject : ".$subject."<br>Message : ".$message ;
				if(mail($to, $subject, $body, $headers)) {
					$ins = $pdo->prepare("insert into ticket_system (ticket_subject, ticket_email, ticket_body, ticket_name, ticket_date) Values (?,?,?,?,?)");
					$ins->execute(array($subject,$email,$message,$name,$date));
					$form_message = "Your Email has been sent. We'll contact you shortly." ;
					$new_first_no = code(1);
					$new_second_no = code(1);
					$output = array( 
					'form_message' => $form_message,
					'first_no' => $new_first_no,
					'second_no' => $new_second_no,
					'form_message' => $form_message
					);
					echo json_encode($output);
				} else {
					$form_message = "Error: Either you are on Localhost or Mail function not enabled on your server. Check phpinfo() on your Server." ;
					$new_first_no = code(1);
					$new_second_no = code(1);
					$output = array( 
					'form_message' => $form_message,
					'first_no' => $new_first_no,
					'second_no' => $new_second_no,
					'form_message' => $form_message
					);
					echo json_encode($output);
				}
			} else {
				
				$form_message = "Your Sum is not correct. Please Prove You are Human." ;
				$new_first_no = code(1);
				$new_second_no = code(1);
				$output = array( 
				'first_no' => $new_first_no,
				'first_no' => $new_first_no,
				'second_no' => $new_second_no,
				'form_message' => $form_message
				);
				echo json_encode($output) ;
			}
			
		} else {
			$form_message = "All fields are mandatory. Try again." ;
			$output = array( 
					'form_message' => $form_message
					);
			echo json_encode($output) ;
		}
		
	}
} else {
	header("location:login.php");
}

?>