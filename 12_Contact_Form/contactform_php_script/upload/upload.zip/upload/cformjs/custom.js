jQuery(function ($) {
	
	"use strict";
	var base_url = location.protocol + '//' + location.host + location.pathname ;
	base_url = base_url.substring(0, base_url.lastIndexOf("/") + 1);
 $(document).on("click","#logreg-forms #btn-signup ", function() {
		$('#logreg-forms .form-signup').toggle();
		$('#logreg-forms .form-signin').toggle();
	});
 $(document).on("click","#logreg-forms #cancel_signup ", function() {
		$('#logreg-forms .form-signup').toggle();
		$('#logreg-forms .form-signin').toggle();
	});
  $(document).on("click","#logreg-forms #forgot_pswd", function() {
		$('#logreg-forms .form-signin').toggle(); 
   		$('#logreg-forms .form-reset').toggle();											 
	});
  $(document).on("click","#logreg-forms #cancel_reset", function() {
		$('#logreg-forms .form-signin').toggle(); 
   		$('#logreg-forms .form-reset').toggle();											 
	});
  $(document).on("click","#hide", function() {
		$(".errorMessage").hide();
	});
  
	$(document).on('submit','.form_validation', function(event){
		event.preventDefault();
		var form_data = $(this).serialize();
		$('.form_validation')[0].reset();
		$.ajax({
			url:base_url+"admin_detail.php",
			method:"POST",
			data:form_data,
			success:function(data)
			{	
				data = JSON.parse(data);
				$('.removecontact-messages').fadeIn().html('<div  class="alert alert-danger errorMessage">'+(data.form_message)+'<button type="button" class="close float-right" aria-label="Close" > <span aria-hidden="true" id="hide">&times;</span></button></div>');
				$('#firstno').val(data.first_no);
				$('#secondno').val(data.second_no);
				$('#newfirst').html(data.first_no);
				$('#newsecond').html(data.second_no);
				$('.selectpicker').selectpicker("refresh") ;
			}
		})
	});
});