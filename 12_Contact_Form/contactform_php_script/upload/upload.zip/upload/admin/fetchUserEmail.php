<?php
ob_start();
session_start();
include("db/config.php");
include("db/function_xss.php");
// Checking Admin is logged in or not
if(!isset($_SESSION['admin'])) {
	header('location: login.php');
	exit;
}
$Statement = $pdo->prepare("SELECT * FROM ticket_system WHERE ticket_status = '0' order by ticket_id desc");
$Statement->execute(); 
$total = $Statement->rowCount();    
$result = $Statement->fetchAll(PDO::FETCH_ASSOC); 
$output = array('data' => array());
if($total > 0){
	foreach($result as $row) {
		$ticket_id = _e($row['ticket_id']);
		$ticket_subject = _e($row['ticket_subject']);
		$ticket_email = _e($row['ticket_email']);
		$ticket_body = _e($row['ticket_body']);
		$ticket_name = _e($row['ticket_name']);
		$ticket_date = _e($row['ticket_date']);
		$ticket_date =  date('d F, Y',strtotime($ticket_date));
		$link = '<button type="button" name="sendEmailUser" id="'.$ticket_id.'" class="btn btn-success btn-sm sendEmailUser">Send Email</button>';
		$output['data'][] = array( 		
		$ticket_id,
		$ticket_date,
		$ticket_name,
		$ticket_email,
		$ticket_subject,		
		$ticket_body,
		$link
		); 	
	}
	
} 
echo json_encode($output);

?>