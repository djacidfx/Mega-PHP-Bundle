</main> <!-- page-content" -->
<script type="text/javascript" src="<?php echo ADMIN_URL; ?>/js/jquery-3.5.1.min.js"></script>
<script type="text/javascript" src="<?php echo ADMIN_URL; ?>/js/popper.min.js"></script>
<script type="text/javascript" src="<?php echo ADMIN_URL; ?>/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo ADMIN_URL; ?>/js/bootstrap-select.min.js"></script>
<script type="text/javascript" src="<?php echo ADMIN_URL; ?>/js/main.js"></script>
<script type="text/javascript" src="<?php echo ADMIN_URL; ?>/js/jquery.form.js"></script>
<script type="text/javascript" src="<?php echo ADMIN_URL; ?>/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="<?php echo ADMIN_URL; ?>/js/dataTables.bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo ADMIN_URL; ?>/js/bootstrap-datepicker.js"></script>
<script type="text/javascript" src="<?php echo ADMIN_URL; ?>/js/custom.js"></script>
<script type="text/javascript" src="<?php echo ADMIN_URL; ?>/js/spotlight.bundle.js"></script>
</body>
</html>