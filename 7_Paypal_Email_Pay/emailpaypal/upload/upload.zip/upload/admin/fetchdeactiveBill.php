<?php
ob_start();
session_start();
include("db/config.php");
include("db/function_xss.php");
// Checking Admin is logged in or not
if( empty($_SESSION['admin']['id'])  ){
	header('location: '.ADMIN_URL.'/index.php');
	exit;
}
$Statement = $pdo->prepare("SELECT * FROM payments WHERE bill_status = '0' order by id desc");
$Statement->execute(); 
$total = $Statement->rowCount();    
$result = $Statement->fetchAll(PDO::FETCH_ASSOC); 
$sum = 0;
$output = array('data' => array());
if($total > 0) {
	$statuss = "";
	foreach($result as $row) {
		$sum = $sum + 1;
		$id = _e($row['id']);
		$customer_name = _e($row['customer_name']);
		$customer_email = _e($row['customer_email']);
		$customer_phone = _e($row['customer_phone']);
		$customer_tax_number = _e($row['customer_tax_number']);
		$payment_purpose = _e($row['payment_purpose']);
		$txn_id = _e($row['txn_id']);
		$txn_type = _e($row['txn_type']);
		$address_country = _e($row['address_country']);
		$payer_email = _e($row['payer_email']);
		$price = "$" ;
		$price .= _e($row['total_amt']);
		
		$date = _e($row['pay_date']);
		if(empty($date)){
			$date = '' ;
		} else {
			$date =  date('d F, Y',strtotime($date));
		}
		$billdate = _e($row['bill_date']);
		$billdate =  date('d F, Y',strtotime($billdate));
		$statuss = _e($row['payment_status']);
		$bill_status = _e($row['bill_status']);
		if(!empty($statuss) || $statuss == 'Completed') {
			// Deactivate Plan
			$statuss = "<b class='btn btn-disabled btn-sm btn-success'>Paid</b>";
			$resendEmail = '';
			$plan = '';
			
		} else {
			// Activate Subscription Plan
			$statuss = "<b class='btn btn-disabled btn-sm btn-danger'>Due</b>";
			if($bill_status == '0'){
				$plan = '<button type="button" name="changeBillStatus" id="'.$id.'" class="btn btn-success btn-sm changeBillStatus" data-status="1">Activate</button>';
			} else {
				$plan = '<button type="button" name="changeBillStatus" id="'.$id.'" class="btn btn-danger btn-sm changeBillStatus" data-status="0">Deactivate</button>';
			}
			
		}
		$emailDecode = base64_encode($customer_email) ;
		$view = '<a href="'.BASE_URL.'order/'.$id.'/'.$emailDecode.'" target="_blank" class="btn btn-sm btn-light"><i class="fa fa-eye"></i></a>';
		$output['data'][] = array( 		
		$sum, 
		$id,
		$billdate,
		$date,
		$customer_name,
		$customer_email,
		$customer_phone,
		$customer_tax_number,
		$payment_purpose,
		$txn_id,
		$txn_type,
		$address_country,
		$payer_email,
		$price,
		$statuss,
		$view,
		$plan
		); 	
	}
}
echo json_encode($output);
?>