<?php include("header.php") ; ?>
<div class="app-title">
        <div>
          <h1><i class="fa fa-arrows-alt"></i> Bills</h1>
          <p>Create Bills & Send / Resend Email for Due Payments.</p>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
        </ul>
 </div>
 <div class="container-fluid mar-top">
      	<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="row">
		   			<div class="col-md-12 col-lg-12">
						<div class="panel panel-default">
							<div class="panel-heading">
								<div class="page-heading"> <h6>Manage Bills</h6></div>
								<button class="btn btn-success btn-sm  m-1" id="add_bill"><i class="fa fa-plus-square"></i> Add Bill & Send Email</button>
							</div> <!-- /panel-heading -->
							<div class="panel-body">
								<div class="remove-messages"></div>
								<div class="row">
									<div class="col-md-12">
									  <div class="tile">
										<div class="tile-body">
										  <div class="table-responsive">
											<div class="table-responsive">
												<table class="table table-bordered table-hover" id="manageBillsTable">
													<thead>
														<tr>
															<th>S.No.</th>
															<th>Order ID</th>
															<th>Order Date</th>
															<th>Paid Date</th>
															<th>Customer Name</th>
															<th>Customer Email</th>
															<th>Customer Phone</th>
															<th>Customer Tax No.</th>
															<th>Payment Purpose</th>
															<th>Transaction ID</th>
															<th>Transaction Type</th>
															<th>Country</th>
															<th>Payer Email</th>
															<th>Price</th>	
															<th>Status</th>
															<th>Edit</th>
															<th>View</th>
															<th>Resend Email</th>
															<th>Deactivate</th>
														</tr>
													</thead>
												</table><!-- /table -->
											</div>
										  </div>
										</div>
									</div>
								</div>
							</div> <!-- /panel-body -->
					</div> <!-- /panel -->	
					</div>
				</div>
			</div>
		</div>
	</div><!-- page-content" -->
	<!-- Payment Modal -->
	<div id="paymentModal" class="modal fade " data-backdrop="static" data-keyboard="false">
    	<div class="modal-dialog modal-lg">
    		<form method="post" id="payment_form">
    			<div class="modal-content">
    				<div class="modal-header">
						<h4 class="modal-title"><i class='fa fa-plus'></i> Add Bill</h4>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						  <span aria-hidden="true">&times;</span>
						</button>
    				</div>
    				<div class="modal-body">
						<div class="row">
							<div class="col-lg-6 col-md-6">
								<div class="form-group">
									<label>Customer Name*</label>
									<input type="text" name="cname" id="cname" class="form-control" maxlength="50" required />
								</div>
							</div>
							<div class="col-lg-6 col-md-6">
								<div class="form-group">
									<label>Customer Email*</label>
									<input type="email" name="cemail" id="cemail" class="form-control" maxlength="50" required  />
								</div>
							</div>
							<div class="col-lg-6 col-md-6">
								<div class="form-group">
									<label>Customer Phone<small> (Optional)</small></label>
									<input type="text" name="cphone" id="cphone" class="form-control" maxlength="25" />
								</div>
							</div>
							<div class="col-lg-6 col-md-6">
								<div class="form-group">
									<label>Customer Tax Number<small> (Optional)</small></label>
									<input type="text" name="ctax" id="ctax" class="form-control" maxlength="50"  />
								</div>
							</div>
								<div class="col-lg-3 col-md-3">
									<div class="form-group">
										<label>Date*</label>
										<input type="text" name="sdate" id="sdate" class="form-control order_date" autocomplete="off" required  />
									</div>
								</div>
								<div class="col-lg-6 col-md-6">
									<div class="form-group">
										<label>Purpose of Payment*</label>
										<input type="text" name="purpose" id="purpose" class="form-control" autocomplete="off" required maxlength="50" placeholder="e.g. Software Service Payment" />
									</div>
								</div>
								<div class="col-lg-3 col-md-3">
									<label>Price*</label>
									<div class="input-group mb-3">
									  <div class="input-group-prepend">
										<span class="input-group-text">$</span>
									  </div>
									  <input type="text" class="form-control" placeholder="99" name="price" id="price" autocomplete="off" required maxlength="10"  >
									</div>
								</div>
							</div>						
					</div>
					
					
    				<div class="modal-footer">
						<input type="hidden" name="sid" id="sid" >
						<input type="hidden" name="btn_action_payment" id="btn_action_payment" />
    					<input type="submit" name="action_payment" id="action_payment" class="action_payment btn btn-success" value="Save & Send Email"  />
    					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
    				</div>
    			</div>
    		</form>
    	</div>
    </div>
<?php include("footer.php") ; ?>