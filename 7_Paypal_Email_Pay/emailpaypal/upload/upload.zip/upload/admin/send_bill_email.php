<?php
$body = '
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="'.ADMIN_URL.'/css/main.css">
</head>
<body>
<center>
<table style="border:1px dotted #00CCFF; min-width:300px;">
<tr>
<td  colspan="2">
<center> <img src="'.ADMIN_URL.'/images/siteLogo.png" ></center>
</td>
</tr>
<tr>
<td  colspan="2">
<center> <b>'.$c_name.'</b></center>
</td>
</tr>
<tr>
<td  colspan="2">
<center>'.$c_email.'</center>
</td>
</tr>
<tr>
<td  colspan="2">
<center>'.$c_phone.'</center>
</td>
</tr>
<tr >
<td colspan="2" style="border-bottom:2px dotted #99CC99;">
<center>'.$c_tax.'</center>
</td>
</tr>
<tr >
<td width="50%" style="border:1px solid #00CC33;">
Name 
</td>
<td style="border:1px solid #00CC33;" >
'.$cname.'
</td>
</tr>
</tr>
<tr >
<td width="50%" style="border:1px solid #00CC33;">
Email 
</td>
<td style="border:1px solid #00CC33;">
'.$cemail.'
</td>
</tr>
<tr >
<td width="50%" style="border:1px solid #00CC33;">
Phone 
</td>
<td style="border:1px solid #00CC33;">
'.$cphone.'
</td>
</tr>
<tr >
<td width="50%" style="border:1px solid #00CC33;">
Tax Number 
</td>
<td style="border:1px solid #00CC33;">
'.$ctax.'
</td>
</tr>
<tr >
<td width="50%" style="border:1px solid #00CC33;">
Payment Purpose 
</td>
<td style="border:1px solid #00CC33;">
'.$purpose.'
</td>
</tr>
<tr >
<td width="50%" style="border:1px solid #00CC33;">
Amount 
</td>
<td style="border:1px solid #00CC33;">
(USD) $'.$price.'
</td>
</tr>
<tr >
<td width="50%" style="border:1px solid #00CC33;">
Order ID 
</td>
<td style="border:1px solid #00CC33;" >
'.$order_id.'
</td>
</tr>
<tr >
<td colspan="2" style="border:1px solid #00CC33;">
<center><a href="'.BASE_URL.'order/'.$order_id.'/'.$hex.'"><img src="'.ADMIN_URL.'/images/payButton.png" ></a> </center>
</td>
</tr>
<tr >
<td colspan="2" style="border:1px solid #00CC33;">
<center><small>'.$c_name.' &#169; '.date('Y').' . All Rights Reserved.</small></center>
</td>
</tr>
</table>
</center>
</body>
</html>';
?>
