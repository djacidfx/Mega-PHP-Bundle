<?php
require_once("admin/db/config.php");
require_once("admin/db/function_xss.php");
$orderId = filter_var($_GET['oid'],FILTER_SANITIZE_STRING) ;
$customerEmail = base64_decode($_GET['email']) ;
$customerEmail = filter_var($customerEmail,FILTER_SANITIZE_EMAIL) ;
$statement = $pdo->prepare("select * from payments where customer_email = '".$customerEmail."' and id = '".$orderId."'");
$statement->execute();
$ok = $statement->rowCount();
$result = $statement->fetchAll(PDO::FETCH_ASSOC); 
foreach($result as $row) {
	$status = _e($row['bill_status']) ;
	$payment_status = _e($row['payment_status']) ;
	$customer_name = _e($row['customer_name']);
	$customer_phone = _e($row['customer_phone']);
	$customer_tax_number = _e($row['customer_tax_number']);
	$price = _e($row['total_amt']);
	$payment_purpose = _e($row['payment_purpose']);
	$txn_id = _e($row['txn_id']);
	$pay_date = _e($row['pay_date']);
	$pay_date =  date('d F, Y',strtotime($pay_date));
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Order Payment Page</title>
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<meta name="description" content="Order Payment Page">
	<link rel="stylesheet" type="text/css" href="<?php echo BASE_URL; ?>css/main.css">
	<link rel="stylesheet" type="text/css" href="<?php echo BASE_URL; ?>css/all.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo BASE_URL; ?>css/custom.css">
</head>

<body>
<?php 
if($ok > 0){
if($status == '1'){
?>
<div id="logreg-forms" class="shadow-lg">
	<div class="modal-header justify-content-center bg-secondary">
		<img src="<?php echo ADMIN_URL; ?>/images/siteLogo.png" class="img-fluid"  alt="Logo">
	</div>
        	<form action="<?php echo BASE_URL; ?>payment.php" class="form-signin" method="post">
				<div class="row">
				<div class="col-lg-6 col-md-6">
								<div class="form-group">
									<label>Customer Name</label>
									<input type="text" name="cname" id="cname" class="form-control" value="<?php echo $customer_name ; ?>" readonly="readonly"/>
								</div>
							</div>
							<div class="col-lg-6 col-md-6">
								<div class="form-group">
									<label>Customer Email</label>
									<input type="email" name="cemail" id="cemail" class="form-control"  value="<?php echo $customerEmail ; ?>" readonly="readonly"  />
								</div>
							</div>
							<div class="col-lg-6 col-md-6">
								<div class="form-group">
									<label>Customer Phone</label>
									<input type="text" name="cphone" id="cphone" class="form-control" value="<?php echo $customer_phone ; ?>" readonly="readonly"/>
								</div>
							</div>
							<div class="col-lg-6 col-md-6">
								<div class="form-group">
									<label>Customer Tax Number</label>
									<input type="text" name="ctax" id="ctax" class="form-control"  value="<?php echo $customer_tax_number ; ?>" readonly="readonly"  />
								</div>
							</div>
							<div class="col-lg-12">
								<div class="form-group">
									<label>Purpose of Payment</label>
									<input type="text" name="item_name" id="item_name" class="form-control"  value="<?php echo $payment_purpose ; ?>" readonly="readonly"  />
								</div>
							</div>
							<div class="col-lg-6 col-md-6">
								<div class="form-group">
									<label>Order ID</label>
									<input type="text" name="item_number" id="item_number" class="form-control"  value="<?php echo $orderId ; ?>" readonly="readonly"  />
								</div>
							</div>
							<div class="col-lg-6 col-md-6">
								<label>Amount</label>
								<div class="input-group mb-3">
					<div class="input-group-prepend">
						<span class="input-group-text">(USD)&ensp;<b> $</b></span>
					</div>
					<input type="text" name="item_amount" id="price" class="form-control" value="<?php echo $price ; ?>" required autofocus readonly="readonly"> 
				</div>
							</div>
				<input type="hidden" name="cmd" value="_xclick" />
				<input type="hidden" name="item_name" value="plan"  >
				<input type="hidden" name="no_note" value="1" /> 
				<input type="hidden" name="lc" value="UK" /> 
				<input type="hidden" name="bn" value="PP-BuyNowBF:btn_buynow_LG.gif:NonHostedGuest" /> 
				
				<?php 
				if($payment_status == 'Completed') {
				?>
				<div class="col-lg-6 col-md-6">
								<div class="form-group">
									<label>Transaction ID</label>
									<input type="text" class="form-control"  value="<?php echo $txn_id ; ?>" readonly="readonly"  />
								</div>
							</div>
							<div class="col-lg-6 col-md-6">
								<div class="form-group">
									<label>Paid Date</label>
									<input type="text" class="form-control"  value="<?php echo $pay_date ; ?>" readonly="readonly"  />
								</div>
							</div>
				<div class="col-lg-12 text-center"> <button class="btn btn-success btn-disabled btn-sm" disabled="disabled">Already Paid</button></div>
				<?php
				} else {
				?>
				
				<div class="col-lg-12 text-center"> <button type="submit" class="btn btn-sm btn-warning"><img src="<?php echo BASE_URL; ?>images/Checkout.png" class="img-fluid w-75"  alt="PayPal Checkout"></button></div>
				<?php
				} 
				?>
				</div>
				</div>
				
            </form>
</div>
<?php
} else {
?>
<div id="logreg-forms" class="shadow-lg">
	<div class="modal-header justify-content-center bg-white">
		<img src="<?php echo ADMIN_URL; ?>/images/siteLogo.png" class="img-fluid"  alt="Logo">
	</div>
	<div class="row">
		<div class="col-lg-12 text-danger text-center">
			<b>Sorry, This Order is Deactivated By Owner.</b>
		</div>
	</div>
</div>

<?php
}
} else {
?>
<div id="logreg-forms" class="shadow-lg">
	<div class="modal-header justify-content-center bg-white">
		<img src="<?php echo ADMIN_URL; ?>/images/siteLogo.png" class="img-fluid"  alt="Logo">
	</div>
	<div class="row">
		<div class="col-lg-12 text-danger text-center p-3">
			<h4 class="text-danger">Sorry, This Order is not Exist.</h4>
		</div>
	</div>
</div>
<?php
}
?>
<script type="text/javascript" src="<?php echo BASE_URL; ?>js/jquery-3.5.1.min.js"></script>
<script type="text/javascript" src="<?php echo BASE_URL; ?>js/errorMsg.js"></script>
</body>
</html>
