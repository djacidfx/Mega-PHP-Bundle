<?php
require_once("admin/db/config.php");
require_once("admin/db/function_xss.php");
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Paypal Order Status</title>
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<meta name="description" content="Paypal Order Status">
	<link rel="stylesheet" type="text/css" href="<?php echo BASE_URL; ?>css/main.css">
	<link rel="stylesheet" type="text/css" href="<?php echo BASE_URL; ?>css/all.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo BASE_URL; ?>css/custom.css">
</head>

<body>
<div id="logreg-forms" class="shadow-lg">
<div class="modal-header justify-content-center bg-secondary">
	<img src="<?php echo ADMIN_URL ; ?>/images/siteLogo.png" class="img-fluid"  alt="Logo">
</div>
<form  id="od_form" class="form-signin" method="post">
	<h4 class="d-flex justify-content-center"> Check Payment Status</h4>
	<div class="row">
	<div class="col-lg-6">
	<input type="email" name="email" id="inputEmail" class="form-control" placeholder="Email Address" maxlength="50" required autofocus>
	</div>
	<div class="col-lg-6">
	<input type="text" name="orderId" id="orderId" class="form-control" placeholder="Order ID" required>
	</div>
	</div>
	<div class="remove-messages mt-2"></div>
	<div class="text-center"><button class="btn btn-info btn-sm" type="submit" name="action_log" id="action_log"><i class="fas fa-sign-in"></i> Check Status</button></div>
</form>
</div>
<script type="text/javascript" src="<?php echo BASE_URL; ?>js/jquery-3.5.1.min.js"></script>
<script type="text/javascript" src="<?php echo BASE_URL; ?>js/errorMsg.js"></script>
</body>
</html>
