<?php
ob_start();
session_start();
require_once('db/config.php');
if(!isset($_SESSION['admin'])) {
	header('location: '.ADMIN_URL.'/login.php');
	exit;
}
$err = 1 ;
$Api = filter_var($_POST['Api'], FILTER_SANITIZE_STRING) ;
$senderid = filter_var($_POST['senderid'], FILTER_SANITIZE_STRING);
$route = filter_var($_POST['route'], FILTER_SANITIZE_NUMBER_INT);
$country = filter_var($_POST['country'], FILTER_SANITIZE_NUMBER_INT);
$template = filter_var($_POST['template'], FILTER_SANITIZE_STRING);
if( !empty($_POST['Api']) && !empty($_POST['senderid']) && !empty($_POST['route']) ){
	$update_setting = $pdo->prepare("UPDATE ot_admin SET sms_apikey='".$Api."' , sms_senderid = '".$senderid."' , sms_route = '".$route."' , sms_country = '".$country."' , sms_template = '".$template."' WHERE id='1'");
	$update_setting->execute();
	$err = 0 ;
	echo $err ;
} else {
	$err = 1;
	echo $err ;
}
?>