// JavaScript Document
jQuery(function ($) {
	
	"use strict";
	$('.selectpicker').selectpicker('refresh') ;
});