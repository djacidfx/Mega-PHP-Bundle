<?php
function count_total_users($pdo)
{	
	$query = "SELECT * FROM customer_active WHERE 1";
	$statement = $pdo->prepare($query);
	$statement->execute();
	$total = $statement->rowCount();
	return _e($total) ;
	
}
function count_total_active_users($pdo)
{	
	$query = "SELECT * FROM customer_active WHERE active_status='1'";
	$statement = $pdo->prepare($query);
	$statement->execute();
	$total = $statement->rowCount();
	return _e($total) ;
	
}
function count_total_deactive_users($pdo)
{	
	$query = "SELECT * FROM customer_active WHERE active_status='0'";
	$statement = $pdo->prepare($query);
	$statement->execute();
	$total = $statement->rowCount();
	return _e($total) ;
	
}
function count_total_email($pdo)
{	
	$query = "SELECT * FROM ticket_system WHERE 1";
	$statement = $pdo->prepare($query);
	$statement->execute();
	$total = $statement->rowCount();
	return _e($total) ;
	
}
function count_total_active_email($pdo)
{	
	$query = "SELECT * FROM ticket_system WHERE ticket_status='1'";
	$statement = $pdo->prepare($query);
	$statement->execute();
	$total = $statement->rowCount();
	return _e($total) ;
	
}
function count_total_deactive_email($pdo)
{	
	$query = "SELECT * FROM ticket_system WHERE ticket_status='0'";
	$statement = $pdo->prepare($query);
	$statement->execute();
	$total = $statement->rowCount();
	return _e($total) ;
	
}
function count_total_option($pdo)
{	
	$query = "SELECT * FROM ticket_subject WHERE 1";
	$statement = $pdo->prepare($query);
	$statement->execute();
	$total = $statement->rowCount();
	return _e($total) ;
	
}
function count_total_active_option($pdo)
{	
	$query = "SELECT * FROM ticket_subject WHERE subject_status='1'";
	$statement = $pdo->prepare($query);
	$statement->execute();
	$total = $statement->rowCount();
	return _e($total) ;
	
}
function count_total_deactive_option($pdo)
{	
	$query = "SELECT * FROM ticket_subject WHERE subject_status='0'";
	$statement = $pdo->prepare($query);
	$statement->execute();
	$total = $statement->rowCount();
	return _e($total) ;
	
}
?>