<?php 
require_once('header.php');
if(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
         $url = "https://";   
   } else  {
         $url = "http://";  
	} 
    // Append the host(domain name, ip) to the URL.   
    $url.= $_SERVER['HTTP_HOST'];   
    
    // Append the requested resource location to the URL   
    $url.= $_SERVER['REQUEST_URI'];
	$replace = "";
	$url = str_replace('/admin/edit_user.php', '' . $replace . '/', $url); 
	$serverUrl = $url ; 
?>
<div class="app-title">
        <div>
          <h1><i class="fa fa-users"></i> User Details</h1>
		  <p class="text-success">Activate or Deactivate User. Deactivated User automatically Logout when they click any option.</p>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
        </ul>
 </div>
	<div class="container">
		
      	<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="row">
		   			<div class="col-md-12 col-lg-12">
						<div class="panel panel-default">
							<div class="panel-heading">
								<div class="page-heading"> Manage Users</div>
								<button class="btn btn-info btn-sm   m-1" id="add_user"><i class="fa fa-plus-square"></i> Add User</button>
							</div> <!-- /panel-heading -->
							<div class="panel-body">
								<div class="remove-messages"></div>
								<div class="row">
									<div class="col-md-12">
									  <div class="tile">
										<div class="tile-body">
								<div class="table-responsive">
									<table class="table table-bordered table-hover" id="manageCustomerTable">
										<thead>
											<tr>
												<th>ID</th>						
												<th>Fullname</th>							
												<th>Email</th>
												<th>Status</th>
												<th>Options</th>
											</tr>
										</thead>
									</table><!-- /table -->
								</div>
							</div> 
									</div>
								</div>
							</div><!-- /panel-body -->
					</div> <!-- /panel -->	
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- Contact Form Select Option Modal -->
	<div id="selectuserModal" class="modal fade"  data-backdrop="static" data-keyboard="false">
    	<div class="modal-dialog">
    		<form method="post" id="selectuser_form">
    			<div class="modal-content">
    				<div class="modal-header">
						<h4 class="modal-title"><i class="fa fa-plus"></i> Add User</h4>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						  <span aria-hidden="true">&times;</span>
						</button>
    				</div>
    				<div class="modal-body">
						<div class="form-group">
							<label>User Fullname*</label>
							<input type="text" name="user_name" id="user_name" class="form-control" maxlength="25" required />
						</div>
						<div class="form-group">
							<label>User Email*</label>
							<input type="email" name="user_email" id="user_email" class="form-control" maxlength="50" required />
						</div>
						<div class="form-group">
							<label>User Password* <br><small>Password must contain minimum 8 characters, 1 Uppercase character, 1 Lowercase character & 1 number.</small></label>
							<input type="text" name="user_pass" id="user_pass" class="form-control" required maxlength="40" />
						</div>
					</div>
					<div class="col-lg-12">
						<div class="removeuser-messages"></div>
					</div>
    				<div class="modal-footer">
						<input type="hidden" name="login_url" value="<?php echo $serverUrl ; ?>" >
						<input type="hidden" name="adm_email" value="<?php echo $email_old ; ?>" >
						<input type="hidden" name="btn_action_user" id="btn_action_user"  value="Submit"/>
						<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
    					<input type="submit" name="action_user" id="action_user" class="btn btn-info" value="Add User" />
    				</div>
    			</div>
    		</form>
    	</div>
 </div>
<?php require_once('footer.php'); ?>

