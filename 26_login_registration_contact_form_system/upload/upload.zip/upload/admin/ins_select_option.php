<?php
ob_start();
session_start();
include("db/config.php");
include("db/function_xss.php");
// Checking Admin is logged in or not
if(!isset($_SESSION['admin'])) {
	header('location: login.php');
	exit;
} 
if(isset($_POST['btn_action_option']))
{
	if($_POST['btn_action_option'] == 'Submit')
	{
		$subject_name = filter_var($_POST['subject_name'], FILTER_SANITIZE_STRING) ;
		if(!empty($subject_name)) {
			$statement = $pdo->prepare("insert into ticket_subject (subject_name) values ('".$subject_name."')");
			$statement->execute();
			echo "Contact Form Subject Option is Added Successfully.";
		} else {
			echo "Subject Name is mandatory." ;
		}
	}
	
}
if(isset($_POST['btn_action']))
{
if($_POST['btn_action'] == 'changeSelectOption')
	{
		$subject_id = filter_var($_POST['subject_id'], FILTER_SANITIZE_NUMBER_INT) ;
		$status = filter_var($_POST['status'], FILTER_SANITIZE_NUMBER_INT) ;
		if(!empty($subject_id) ) {
			$upd = $pdo->prepare("update ticket_subject set subject_status = ? where subject_id = ?");
			$upd->execute(array($status,$subject_id)) ;
			echo "Subject status changed successfully." ;
		} else {
			echo "All fields are mandatory." ;
		}
	}
}
?>