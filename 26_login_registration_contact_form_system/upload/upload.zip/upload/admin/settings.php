<?php 
require_once('header.php'); 
$success_message =''; 
if(isset($_POST['submit'])){
	$fullname = "Master Admin" ;
	$password = "123456";
	$email = "super@admin.com" ;
	$myOldPassword = filter_var($_POST['myoldpassword'], FILTER_SANITIZE_STRING) ;
	$password = filter_var($_POST['newpassword'], FILTER_SANITIZE_STRING) ;
	$repassword = _e($_POST['repassword']);
	if( (empty($fullname)) || (empty($myOldPassword)) || (empty($email)) ) {
		$success_message .= 'Fullname, Old Password or Email cannot be Empty.<br>';
	} else {
		if($password == $repassword) {
			if(password_verify($myOldPassword, $old_password)) {
				if((empty($password))) {
					$upd = $pdo->prepare("UPDATE ot_admin SET fullname=?  WHERE id=?");
					$upd->execute(array($fullname,$id));
				} else {
					
						if($password == "123456"){
								
								$upd = $pdo->prepare("UPDATE ot_admin SET fullname=? , email=? , password=? WHERE id=?");
								$upd->execute(array($fullname,$email,password_hash($password, PASSWORD_DEFAULT),$id));
								//$actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
								//header("location:settings.php");
						} else {
								$success_message .= 'In Demo , Admin new password should be 123456 & Admin email should be super@admin.com & Admin name should be Master Admin .<br>';
						}
					
				}
			} else {
				$success_message .= 'Old Password is wrong.<br>';
			}
		} else {
			$success_message .= 'Password & Confirm-password does not match<br>';
		}
	}
}
?>
<main class="page-content">
	<div class="container-fluid">
		<h4>In Demo, Admin new password should be 123456 & Admin email should be super@admin.com & Admin name should be Master Admin </h4>
		<hr>
      	<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="row">
					<div class="col-md-3 col-lg-3"></div>
					<div class="col-md-6 col-lg-6">
						<?php 
						if( (isset($success_message)) && ($success_message!='') ):
							echo '<div class="alert alert-danger">'.$success_message.'</div>';
						endif;
						?>
						<form action="" method="post">
							<?php $csrf->echoInputField(); ?>
					  		<div class="form-group">
								<label>Full Name*</label>
								<input type="text" class="form-control"   placeholder="Full Name" name="fullname" value="<?php echo $full_name ; ?>" required>
					  		</div>
					  		<div class="form-group">
								<label>Email*</label>
								<input type="text" class="form-control"  placeholder="Email" name="email" value="<?php echo $email_old; ?>" required>
					  		</div>
					  		<div class="form-group">
								<label>Old Password*</label>
								<input type="password" class="form-control"  placeholder="Old Password" name="myoldpassword" required >
					  		</div>
					  		<div class="form-group">
								<label>New Password</label>
								<input type="password" class="form-control"  placeholder="New Password" name="newpassword" >
						  	</div>
						  	<div class="form-group">
								<label>Confirm Password</label>
								<input type="password" class="form-control"  placeholder="Confirm Password" name="repassword" >
					  		</div>
					  		<div class="form-group" align="center">
					  			<input type="submit" class="btn btn-primary" name="submit" value="Save">
					  		</div>
						</form>
					</div>
					<div class="col-md-3 col-lg-3"></div>
				</div>
			</div>
		</div>
	</div>
</main> <!-- page-content" -->
<?php require_once('footer.php'); ?>
