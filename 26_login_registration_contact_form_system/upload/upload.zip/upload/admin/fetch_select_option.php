<?php
ob_start();
session_start();
include("db/config.php");
include("db/function_xss.php");
// Checking Admin is logged in or not
if(!isset($_SESSION['admin'])) {
	header('location: login.php');
	exit;
}
$Statement = $pdo->prepare("SELECT * FROM ticket_subject WHERE 1 order by subject_id desc");
$Statement->execute(); 
$total = $Statement->rowCount();    
$result = $Statement->fetchAll(PDO::FETCH_ASSOC); 
$output = array('data' => array());
if($total > 0){
	foreach($result as $row) {
		$subject_id = _e($row['subject_id']);
		$subject_name = _e($row['subject_name']);
		$subject_status = _e($row['subject_status']);
		if($subject_status == '1') {
		//deactivate select option
			$active = "<b>Active</b>" ;
			$link = '<button type="button" name="changeSelectOption" id="'.$subject_id.'" class="btn btn-danger btn-sm changeSelectOption" data-status ="0" >Deactivate</button>';
		} else {
		//activate select option
			$active = "Not Active" ; 
			$link = '<button type="button" name="changeSelectOption" id="'.$subject_id.'" class="btn btn-success btn-sm changeSelectOption" data-status="1">Activate</button>';
		}
		$output['data'][] = array( 		
		$subject_id,
		$subject_name,
		$active,
		$link
		); 	
	}
	
} 
echo json_encode($output);

?>