<a href="https://twitter.com/share?url=<?php echo $serverUrl ; ?>&text=<?php echo $announceTitle ; ?>" target="_blank" class="float-right ml-2">
<i class="fab fa-twitter-square text-info fa-2x"></i>
</a>
<a href="http://www.facebook.com/share.php?u=<?php echo $serverUrl ; ?>" target="_blank" class="float-right ml-2">
<i class="fab fa-facebook-square text-primary fa-2x"></i></a>
<a href="https://wa.me/?text=<?php echo $serverUrl ; ?>" target="_blank" class="float-right ml-2">
<i class="fab fa-whatsapp text-whatsapp fa-2x"></i>
</a>