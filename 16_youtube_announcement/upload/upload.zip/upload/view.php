<?php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: 0");  
require_once('admin/db/config.php') ;
require_once('admin/db/function_xss.php') ;
function displayTextWithLinks($s) {
  return preg_replace('@(https?://([-\w\.]+[-\w])+(:\d+)?(/([\w/_\.#-]*(\?\S+)?[^\.\s])?)?)@', '<a href="$1" target="_blank">$1</a>', $s);
}
$alignment_sql = "SELECT alignment,dark_mode FROM ot_admin WHERE id = '1'" ;
$alignment = $pdo->prepare($alignment_sql);
$alignment->execute(); 
$align = $alignment->fetchAll(PDO::FETCH_ASSOC);
foreach($align as $alig) {
	$design = _e($alig['alignment']);
	$darkMode = _e($alig['dark_mode']) ;
}
$bg = "";
$color = "text-muted";
$btn = "btn-light";
$border = "";
if($darkMode == '1') {
	$bg = "bg-dark" ;
	$color = "text-white";
	$border = "border border-white";
	$btn = "btn-dark";
}
function removeParam($url, $param) {
    $url = preg_replace('/(&|\?)'.preg_quote($param).'=[^&]*$/', '', $url);
    $url = preg_replace('/(&|\?)'.preg_quote($param).'=[^&]*&/', '$1', $url);
    return $url;
}
$aid = filter_var($_GET['aid'], FILTER_SANITIZE_NUMBER_INT) ; 
$sql = "SELECT * FROM admin_announcement WHERE announcement_status='1' and announcement_id = '".$aid."'" ;
$admin_announcement = $pdo->prepare($sql);
$admin_announcement->execute(); 
$announcement = $admin_announcement->fetchAll(PDO::FETCH_ASSOC);
$total = $admin_announcement->rowCount();
 if(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
         $url = "https://";   
   } else  {
         $url = "http://";  
	} 
    // Append the host(domain name, ip) to the URL.   
    $url.= $_SERVER['HTTP_HOST'];   
    
    // Append the requested resource location to the URL   
    $url.= $_SERVER['REQUEST_URI']; 
	$url = removeParam($url, 'fbclid');
	$serverUrl = $url ; 
	if($total > 0){ 
						foreach($announcement as $notice) {
						$announceId = _e($notice['announcement_id']);
						$Note = strip_tags($notice['announcement_text']);
						$announceTitle = substr_replace($Note, "...", 80);
						$Note = displayTextWithLinks($Note);
						$officialDate = _e($notice['announcement_date']);
						$officialDate =  date('d F, Y',strtotime($officialDate));
						$like = _e($notice['like_count']) ;
						$youtubeId = _e($notice['youtube_id']);
						$comStatus = _e($notice['comment_active']);
						$comment_sql = "SELECT * FROM comments WHERE announceID = '".$announceId."' and comment_status = '1' " ;
						$comment = $pdo->prepare($comment_sql);
						$comment->execute();
						$total_comment = $comment->rowCount();
						$newcomment_sql = "SELECT * FROM comments WHERE announceID = '".$announceId."' and comment_status = '1' order by comment_id desc LIMIT 3  " ;
						$newcomment = $pdo->prepare($newcomment_sql);
						$newcomment->execute();
						$myComment = $newcomment->fetchAll(PDO::FETCH_ASSOC);
						$total_newcomment = $newcomment->rowCount();
						}
?>
<!DOCTYPE html>
<html>
<head>
	
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title><?php echo $announceTitle ; ?></title>
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<meta name="description" content="<?php echo $announceTitle ; ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo ADMIN_URL ; ?>/css/main.css" />
	<link rel="stylesheet" href="<?php echo ADMIN_URL ; ?>/css/all.min.css">
	<link rel="stylesheet" href="<?php echo ADMIN_URL ; ?>/css/Latofont.css">
	<link rel="stylesheet" href="<?php echo ADMIN_URL ; ?>/css/Niconnefont.css">
	<link rel="stylesheet" href="<?php echo ADMIN_URL ; ?>/css/link.css">
	<link rel="icon" href="<?php echo ADMIN_URL; ?>/favicon.png" type="image/png">
</head>
<body class="myColor <?php echo $bg ; ?>">
<!-- Navbar-->
    <header class="app-header"><a class="app-header__logo" href=""><img src="<?php echo ADMIN_URL ; ?>/images/siteLogo.png" class="img-fluid" alt="Logo"></a>
	<!-- Navbar Right Menu-->
      <ul class="app-nav">
        <!-- User Menu-->
        <li class="dropdown"><a class="app-nav__item" href="#" data-toggle="dropdown" aria-label="Open Profile Menu"><i class="fa fa-bars fa-lg"></i></a>
          <ul class="dropdown-menu settings-menu dropdown-menu-right">
            <li><a class="dropdown-item subscribe" href="#!"><i class="fa fa-handshake fa-lg"></i> Subscribe Now</a></li>
          </ul>
        </li>
      </ul>
    </header>
<main class="">
    <div class="container-fluid mt-5">
      
      <div class="row">
	  	<div class="col-lg-12 col-md-12">
		<div class="row">
				<div class="col-md-3 col-lg-3"></div>
				<div class="col-md-6 col-lg-6">
				<div class="announce-res mt-3">
		
			<div class="card-deck mb-3 text-left  ">
							<div class="card mb-3 box-shadow basic-my-div shadow-lg <?php echo $bg ; ?> <?php echo $border ; ?>">
								  <div class="card-header <?php echo $border ; ?>">
									<h4 class="my-0 font-weight-normal <?php echo $color ; ?>"><?php echo $officialDate ; ?></h4>
								  </div>
								  <div class="card-body <?php echo $border ; ?>">
									<h5 class="myLi <?php echo $color ; ?>"><?php echo nl2br($Note) ; ?></h5>
									<?php
									if(!empty($youtubeId)){
									?>
									<hr class="<?php echo $color ; ?> <?php echo $border ; ?>">
									<div class="embed-responsive embed-responsive-16by9">
										<iframe  allowfullscreen="allowfullscreen" mozallowfullscreen="mozallowfullscreen"  msallowfullscreen="msallowfullscreen" oallowfullscreen="oallowfullscreen"  webkitallowfullscreen="webkitallowfullscreen" src="https://www.youtube.com/embed/<?php echo $youtubeId ; ?>"></iframe>
									</div>
									<?php
									}
									?>
								  </div>
								  <div class="card-footer <?php echo $border ; ?>">
								  <?php
								  	if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
											$ip = $_SERVER['HTTP_CLIENT_IP'];
										} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
											$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
										} else {
											$ip = $_SERVER['REMOTE_ADDR'];
										}
							$statement = $pdo->prepare("select * from announcement_like where announce_id = ? and user_ip = ?");
							$statement->execute(array($announceId,$ip));
							$total_like = $statement->rowCount();
								  ?>
								  <form method="post" class="like_form" id="<?php echo $announceId ; ?>">
								  <input type="hidden" name="announceId" class="announceId" value="<?php echo $announceId ; ?>" >
								  <input type="hidden" name="user_ip" value="<?php echo $ip ; ?>" >
								  <input type="hidden" name="like_counting" id="like_counting<?php echo $announceId ; ?>" value="<?php echo $like ; ?>" >
								  <input type="hidden" name="btn_action" value="Submit">
								  <?php
								  if($total_like > 0){
								  ?>
								  <button  class="btn-darks mt-n2 ml-n3 disabled" disabled="disabled"><img src="<?php echo ADMIN_URL ; ?>/images/like.png" class="img-fluid img-comment" /></button><b class="myFo text-success myLike<?php echo $announceId ; ?>"><?php echo $like ; ?></b><?php if($comStatus == '1'){ ?><a href="#!" class="btn-darks text-primary add_comment" id="<?php echo $announceId ; ?>" ><img src="<?php echo ADMIN_URL ; ?>/images/comment.png" class="img-fluid img-comment" /></a><?php } ?> <a href="#!" class="btn-darks showComment text-success " id="<?php echo $announceId ; ?>"><b class="myFo">&ensp;<?php echo $total_comment ; ?> Comments</b> <i class="fa fa-caret-down"></i></a> <?php include("sharer.php") ; ?>
								  <?php
								  } else {
								  ?>
								  <button type="submit" id="lik<?php echo $announceId ; ?>" class="btn-darks mt-n2 ml-n3"><img src="<?php echo ADMIN_URL ; ?>/images/like.png" class="img-fluid img-comment" /></button><b class="myFo text-success myLike<?php echo $announceId ; ?>"><?php echo $like ; ?></b><?php if($comStatus == '1'){ ?><a href="#!" class="btn-darks  text-primary add_comment" id="<?php echo $announceId ; ?>" ><img src="<?php echo ADMIN_URL ; ?>/images/comment.png" class="img-fluid img-comment" /></a><?php } ?><a href="#!" class="btn-darks showComment text-success " id="<?php echo $announceId ; ?>"><b class="myFo">&ensp;<?php echo $total_comment ; ?> Comments</b> <i class="fa fa-caret-down"></i></a>  <?php include("sharer.php") ; ?>
								  <div class="col-lg-12 col-md-12 remove-messages<?php echo $announceId ; ?>"></div>
								  <?php 
								  }
								  ?>
								</form>
								<?php
								if($total_comment > 0) {
								?>
								<div class="col-lg-12 col-md-12 myComment<?php echo $announceId ; ?>  myComm ml-n4 mt-2">
									<span class="shCom">
									<?php 
										foreach($myComment as $com) {
										$commentId = _e($com['comment_id']) ;
										$username = _e($com['fullname']) ;
										$comment_text = strip_tags($com['comment_text']) ;
										$commentDate = _e($com['comment_date']);
										$adminReply = strip_tags($com['admin_reply']);
										$commentDate =  date('d F, Y',strtotime($commentDate));
										?>
									<div class="col-lg-12 col-md-12 <?php echo $color ; ?>">
										<i class="fa fa-user  <?php echo $color ; ?>"></i>  &ensp;<?php echo $username ; ?>&ensp;-&ensp;<small><?php echo $commentDate ; ?></small>
									</div>
									<?php if(empty($adminReply)){ ?>
									<div class="col-lg-12 col-md-12 <?php echo $color ; ?> ml-4 mt-1">
										 <?php echo nl2br($comment_text) ; ?>
									</div>
									<?php } else { ?>
									<div class="col-lg-12 col-md-12 <?php echo $color ; ?> ml-4 mt-1 border <?php echo $bg ; ?>">
										<div class="mt-2">
										 <?php echo nl2br($comment_text) ; ?>
										 <hr class="<?php echo $border ; ?>">
										</div>
										<div>
										<i class="fa fa-user-secret <?php echo $color ; ?>"></i>  &ensp;Admin&ensp;<i class="fa fa-check-circle text-success"></i> <br /><?php echo nl2br($adminReply) ; ?>
										</div>
									</div>
									<?php } ?>
									<hr />
									</span>
									<?php
									}
									?>
									<div class="show_more_new_comment " id="show_more_new_comment<?php echo $commentId; ?>">
							
									<div class="col text-center p-2">
									<div id="loader-icon"><img src="<?php echo ADMIN_URL ; ?>/images/loader.gif" class="img-fluid w-25" /></div>
									<button id="<?php echo $commentId; ?>" class="show_more_comment btn btn-light btn-sm ann<?php echo $announceId ; ?> " >Load More Comment</button>
									</div>
									</div>
								</div>
								<?php
									}
									?>
								  </div>
							</div>
						</div>
			<!-- Add Comment Modal -->
			<div id="commentModal<?php echo $announceId; ?>" class="modal fade commentModal ">
									<div class="modal-dialog ">
										<form method="post" id="<?php echo $announceId; ?>" class="comment_form">
											<div class="modal-content <?php echo $bg ; ?> <?php echo $border ; ?>">
												<div class="modal-header">
													<h4 class="modal-title text-success"><i class="fa fa-comment"></i> Add Comment</h4>
													<button type="button" class="close  <?php echo $color ; ?>" data-dismiss="modal" aria-label="Close">
													  <span aria-hidden="true">&times;</span>
													</button>
												</div>
												<div class="modal-body">
													
													<div class="form-group col-md-12">
													<input type="text" name="username" id="username" class="form-control <?php echo $bg ; ?> <?php echo $color ; ?>" placeholder="Full Name*" maxlength="50" required autofocus>
													<input type="email" name="useremail" id="useremail" class="form-control <?php echo $bg ; ?> <?php echo $color ; ?>" placeholder="Email Address*" maxlength="50" required autofocus>
														<textarea placeholder="Comment*" rows="6" class="form-control <?php echo $bg ; ?> <?php echo $color ; ?>" id="comment" name="comment" required ></textarea>
													</div> 
												</div> 
												<div class="modal-footer"> 
													<input type="hidden" name="announcement_id"  value="<?php echo $announceId ; ?>"/>
													<input type="hidden" name="comment_date" value="<?php echo date('Y-m-d') ; ?>"  />
													<input type="hidden" name="announcement_text"  value="<?php echo _e($Note) ; ?>"/>
													<input type="hidden" name="btn_action" id="btn_action" value="AddComment" />
													<input type="submit" name="action" id="action" class="btn btn-info" value="Add Comment" />
													<button type="button" class="btn <?php echo $btn ; ?> <?php echo $border ; ?>" data-dismiss="modal">Close</button>
												</div>
											</div>
										</form>
									</div>
								</div>
			
			</div>
				<div class="col-md-3 col-lg-3"></div>
			  </div>
		</div>
	  </div>
   </div>
</main> <!-- page-content" -->
<!-- Add Subscribe Modal -->
<div id="subscribeModal" class="modal fade subscribeModal">
	<div class="modal-dialog ">
		<form method="post" class="subscribe_form">
			<div class="modal-content <?php echo $bg ; ?> <?php echo $border ; ?>">
				<div class="modal-header">
					<h4 class="modal-title text-success"><i class="fa fa-bell"></i> Subscribe Now</h4>
					<button type="button" class="close <?php echo $color ; ?>" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<div class="form-group mb-3">
						<input type="email" name="subemail" id="subemail" class="form-control <?php echo $bg ; ?> <?php echo $color ; ?>" placeholder="Email Address*" maxlength="50" required autofocus>
						
					</div> 
					<div class="form-group text-left">
						<label for="message" class="<?php echo $color ; ?>"><i class="fa fa-user-circle "></i> Prove, You are Human*</label>
						<div class="input-group mb-3">
							<div class="input-group-prepend">
								<span class="input-group-text" id="basic-addon1"><span id="newfirst"></span>+<span id="newsecond"></span>
							</div>
							<input type="text" class="form-control <?php echo $bg ; ?> <?php echo $color ; ?>" placeholder="Sum & Enter Value" name="sumvalue" id="sumvalue" autocomplete="off" >
						</div>
					</div>
					<br>
					<small class="<?php echo $color ; ?>">You will never miss New Announcements. We'll Notified you via Email.</small>
					<br>
					<div class="remove-messages"></div>
				</div> 
				<div class="modal-footer"> 
					<input type="hidden" name="firstno"  id="firstno" />
					<input type="hidden" name="secondno" id="secondno" />
					<input type="hidden" name="btn_action_sb" id="btn_action_sb" value="Subscribe" />
					<input type="submit" name="action_sb" id="action_sb" class="btn btn-info" value="Subscribe" />
					<button type="button" class="btn <?php echo $btn ; ?> <?php echo $border ; ?>" data-dismiss="modal">Close</button>
				</div>
			</div>
		</form>
	</div>
</div>
<!--Success Comment Modal -->
<div id="commentSuccessModal" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content <?php echo $bg ; ?> <?php echo $border ; ?>">
			<div class="modal-header">
				<h4 class="modal-title text-success"><i class="fa fa-comment"></i> Comment Message</h4>
				
				<button type="button" class="close <?php echo $color ; ?>" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<h5 class="<?php echo $color ; ?>"> Your comment has been sent to Admin for Approval. Thanks.</h5>
			</div> 
			<div class="modal-footer"> 
				<button type="button" class="btn <?php echo $btn ; ?> <?php echo $border ; ?>" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>
<!--Success Subscriber Modal -->
<div id="sbSuccessModal" class="modal fade">
	<div class="modal-dialog ">
		<div class="modal-content <?php echo $bg ; ?> <?php echo $border ; ?>">
			<div class="modal-header">
				<h4 class="modal-title text-success"><i class="fa fa-bell"></i> Subscriber</h4>
				
				<button type="button" class="close <?php echo $color ; ?>" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<h5 class="<?php echo $color ; ?>"> Thanks for Subscribing Us. We'll Notified you via Email whenever New Announcement Posts.</h5>
			</div> 
			<div class="modal-footer"> 
				<button type="button" class="btn btn-light" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript" src="<?php echo ADMIN_URL ; ?>/js/jquery-3.5.1.min.js"></script>
<script type="text/javascript" src="<?php echo ADMIN_URL ; ?>/js/popper.min.js"></script>
<script type="text/javascript" src="<?php echo ADMIN_URL ; ?>/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo BASE_URL ; ?>singleview.js"></script>
</body>
</html>
<?php 
} else { 
	include_once("notfound.php") ;
}
?>
