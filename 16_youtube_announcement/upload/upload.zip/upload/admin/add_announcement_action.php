<?php
ob_start();
session_start();
include("db/config.php");
include("db/function_xss.php");
// Checking Admin is logged in or not
if($_SESSION['admin'] == '' ){
	header('location: '.ADMIN_URL.'/index.php');
	exit;
}
$admin = $pdo->prepare("SELECT * FROM ot_admin WHERE id = '1'");
$admin->execute();   
$admin_result = $admin->fetchAll(PDO::FETCH_ASSOC);
$total = $admin->rowCount();
foreach($admin_result as $adm) {
//escape all  data
	$email_subscriber = _e($adm['email_subscriber']);
	$rec_email = _e($adm['rec_email']);
}
$headers = "";
if(isset($_POST['btn_action']))
{
	if($_POST['btn_action'] == 'AddAnnouncement') {
		if(!empty($_POST['announce_date']) && !empty($_POST['announceText']) ) {
			$announce_date = filter_var(date($_POST['announce_date']) , FILTER_SANITIZE_STRING);
			$announceText = filter_var($_POST['announceText'], FILTER_SANITIZE_STRING) ;
			$webUrl = filter_var($_POST['webUrl'], FILTER_SANITIZE_URL) ;
			$you_vid = filter_var($_POST['you_vid'], FILTER_SANITIZE_URL);
			$youtubeId = "";
			$y_err = 0 ;
			
			if(!empty($you_vid)){
				if (preg_match("/(?:https?:\/\/)?(?:youtu\.be\/|(?:www\.|m\.)?youtube\.com\/(?:watch|v|embed)(?:\.php)?(?:\?.*v=|\/))([a-zA-Z0-9\-_]+)/", $you_vid) == 1){
			    	$y_err = 0 ;
			   } else {
			   		$y_err = 1;
			   }
				if($y_err == '0'){
					preg_match("/^(?:http(?:s)?:\/\/)?(?:www\.)?(?:m\.)?(?:youtu\.be\/|youtube\.com\/(?:(?:watch)?\?(?:.*&)?v(?:i)?=|(?:embed|v|vi|user)\/))([^\?&\"'>]+)/", $you_vid, $matches);
					$youtubeId = $matches[1] ;
				}
			}
			if(($y_err == 0)) {
				$ins = $pdo->prepare("insert into admin_announcement (announcement_text, announcement_date ,  youtube_id, youtube_url) values (?,?,?,?)");
				$ins->execute(array($announceText,$announce_date,$youtubeId,$you_vid));
				$statement = $pdo->query("SELECT LAST_INSERT_ID()");
				$announceId = $statement->fetchColumn();
				$newUrl = $webUrl.$announceId ;
				if($email_subscriber == '0') {
					echo 'Announcement Live Successfully & No Email sent to any Subscriber.' ;
				} else {
					$subscriber = $pdo->prepare("select * from tbl_subscriber where 1");
					$subscriber->execute();
					$subs = $subscriber->fetchAll(PDO::FETCH_ASSOC);
					foreach($subs as $sub){
						$to = $sub['subscriber_email'] ;
						$subject = "New Announcement Posts" ;
						$from = "Email: ".$rec_email ;
						$headers .= 'MIME-Version: 1.0' . "\r\n" ;
						$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n" ; 
						$headers .= $from . "<br>" ;
						$headers .= "X-Priority: 1 (Highest)\n";
						$headers .= "X-MSMail-Priority: High\n";
						$headers .= "Importance: High\n";
						$body = "<html><body><h2>".$announceText."</h2><br><br><b>View Announcement : ".$newUrl ."</b><br></body></html>";
						$mail_result = mail($to, $subject, $body, $headers);
					}
					if($mail_result) {
						echo 'Announcement Live Successfully & Email sent to All Subscribers.' ;
					} else {
						echo 'Announcement Live Successfully & But problem in sending email. Try again.' ;
					}
				}	
			} else {
				echo 'Error: Youtube Link is wrong. Try Again.' ;	
			}
		} else {
			echo "All fields are mandatory" ; 
		}
	}
	if($_POST['btn_action'] == 'EditAnnouncement') {
		if(!empty($_POST['announce_date']) && !empty($_POST['announceText']) && !empty($_POST['announcement_id']) ) {
			$announceId = filter_var($_POST['announcement_id'], FILTER_SANITIZE_NUMBER_INT);
			$announce_date = filter_var(date($_POST['announce_date']) , FILTER_SANITIZE_STRING);
			$announceText = filter_var($_POST['announceText'], FILTER_SANITIZE_STRING) ;
			$you_vid = filter_var($_POST['you_vid'], FILTER_SANITIZE_URL);
			$youtubeId = "";
			$y_err = 0 ;
			
			if(!empty($you_vid)){
				if (preg_match("/(?:https?:\/\/)?(?:youtu\.be\/|(?:www\.|m\.)?youtube\.com\/(?:watch|v|embed)(?:\.php)?(?:\?.*v=|\/))([a-zA-Z0-9\-_]+)/", $you_vid) == 1){
			    	$y_err = 0 ;
			   } else {
			   		$y_err = 1;
			   }
				if($y_err == '0'){
					if(preg_match("/^(?:http(?:s)?:\/\/)?(?:www\.)?(?:m\.)?(?:youtu\.be\/|youtube\.com\/(?:(?:watch)?\?(?:.*&)?v(?:i)?=|(?:embed|v|vi|user)\/))([^\?&\"'>]+)/", $you_vid, $matches) == 1){
					$youtubeId = $matches[1] ;
					} else {
						$youtubeId = "";
					}
				}
			}
			if(($y_err == 0) && !empty($youtubeId)) {
				$upd = $pdo->prepare("update admin_announcement set announcement_text=? , announcement_date=? , youtube_id = ? , youtube_url = ? where announcement_id = ?");
				$upd->execute(array($announceText,$announce_date,$youtubeId,$you_vid,$announceId));
				echo 'Announcement Edited Successfully .' ;
			} else {
				echo 'Error: Youtube Link is wrong. Try Again.' ;	
			}
		} else {
			echo "All fields are mandatory" ; 
		}
	}
}
?>