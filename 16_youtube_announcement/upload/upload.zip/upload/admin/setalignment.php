<?php include("header.php") ; ?>
<div class="container mar-top">
	<div class="row">
		<div class="col-lg-12 col-md-12">
			<div class="row">
				<div class="col-lg-3 col-md-3"></div>
				<div class="col-lg-6 col-md-6">
					<div class="col-lg-12 col-md-12 text-center">Note : Change Alignment Design of Announcement Page works Only in Desktop & Laptop. After change the Design Go to Official Announcement Page of User to Check.</div>
					<div class="card">
                		<div class="card-header bg-secondary text-white text-center"><h4> Change Alignment</h4></div>
                		<div class="card-body">
							<form method="post" action="alignment_action.php">
								<div class="form-group">
									<label ><i class="fa fa-align-center"></i> Set Alignment*</label>
									<select name="align" required class="form-control">
										<option value="0" <?php if($alignment == '0') { ?> selected="selected" <?php } ?>>Align Center</option>
										<option value="1" <?php if($alignment == '1') { ?> selected="selected" <?php } ?>>Align Left</option>
										<option value="2" <?php if($alignment == '2') { ?> selected="selected" <?php } ?>>Align Right</option>
									</select>
								</div>
								
								<div class="col-md-12 text-center">
								<?php 
										if(! empty($_SESSION['error_message'])){ ?>
											<div  class="alert alert-danger errorMessage">
											<button type="button" class="close float-right" aria-label="Close" >
											  <span aria-hidden="true" id="hide">&times;</span>
											</button>
									<?php
											echo $_SESSION['error_message'] ;
											unset($_SESSION['error_message']);
									?>
											</div>
								<?php } ?>
								<input type="submit"  name="submit" class="btn btn-primary text-center" value="Save Design" />
								</div>
							</form>
                		</div>
           			 </div>
				</div>
				<div class="col-lg-3 col-md-3"></div>
			</div>
		</div>
	</div>
</div>
<?php include("footer.php") ; ?>