<?php
ob_start();
session_start();
require_once('db/config.php');
require_once("db/function_xss.php");
if( !empty($_POST['email']) && !empty($_POST['password']) ){
	$email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL) ;
	$password = filter_var($_POST['password'], FILTER_SANITIZE_STRING) ;
	$userAuthentication =  $pdo->prepare("SELECT * FROM ot_admin WHERE admin_email=? ");
	$userAuthentication->execute(array($email));
	$user_ok = $userAuthentication->rowCount();
	$userData = $userAuthentication->fetchAll(PDO::FETCH_ASSOC);
	if($user_ok > 0) {
		foreach($userData as $row){
			$auth_pass = _e($row['auth_pass']) ;
		}
			if(password_verify($password, $auth_pass)) {
				$_SESSION['admin'] = $row ;
				header("location: dashboard.php");
			} else {
				$_SESSION['error_message'] = 'Either wrong Email or Password. Try Again.';
				header("location: index.php");
			}
	}
	else {
		$_SESSION['error_message'] = 'Either wrong Email or Account Deactivated.';
		header("location: index.php");
	}

} else {
	$_SESSION['error_message'] = 'Email/Password cannot be empty.';
	header("location: index.php");
}
?>