<?php include("header.php") ; ?>
<div class="container mar-top">
	<div class="row">
		<div class="col-lg-12 col-md-12">
			<div class="row">
				<div class="col-lg-3 col-md-3"></div>
				<div class="col-lg-6 col-md-6">
					<div class="card">
                		<div class="card-header bg-secondary text-white text-center"><h4> Email Settings</h4></div>
                		<div class="card-body">
							<form method="post" id="email_settings" class="email_settings">
								<div class="form-group">
									<label><i class="fa fa-envelope"></i> Admin Email* (Where Admin receives new Emails)</label>
									<input type="email" class="form-control" name="adminEmail" id="adminEmail" maxlength="50"  value="<?php echo $rec_email ; ?>"required>
								</div>
								<div class="form-group">
									<label> Dark Mode for Users*</label>
									<select class="form-control" name="darkMode" id="darkMode" required>
									<option value="1" <?php if($darkMode == '1'){ echo $sub = 'selected = "selected" ' ; } else { echo $sub = '' ; } ?> >On</option>
									<option value="0" <?php if($darkMode == '0'){ echo $sub = 'selected = "selected" ' ; } else { echo $sub = '' ; } ?> >Off</option>
									</select>
								</div>
								<div class="form-group">
									<label>Send Email to Subscribers whenever Admin New Announcement Posts* </label>
											<select name="email_subscriber" class="form-control" required>
												<option value="1" <?php if($email_subscriber == '1'){ echo $sub = 'selected = "selected" ' ; } else { echo $sub = '' ; } ?>>Yes</option>
												<option value="0" <?php if($email_subscriber == '0'){ echo $sub = 'selected = "selected" ' ; } else { echo $sub = '' ; } ?>>No</option>
											</select>
										</div>
										<div class="form-group">
											<label>Send Email to User whenever Admin Reply on their Comment* </label>
											<select name="email_comment" class="form-control" required>
												<option value="1" <?php if($email_comment == '1'){ echo $com = 'selected = "selected" ' ; } else { echo $com = '' ; } ?>>Yes</option>
												<option value="0"<?php if($email_comment == '0'){ echo $sub = 'selected = "selected" ' ; } else { echo $com = '' ; } ?>>No</option>
											</select>
										</div>
										<div class="form-group">
											<label>Receive Email to Admin whenever New Comment on Any Announcement* </label>
											<select name="rec_email_comment" class="form-control" required>
												<option value="1" <?php if($rec_email_comment == '1'){ echo $reccom = 'selected = "selected" ' ; } else { echo $reccom = '' ; }  ?>>Yes</option>
												<option value="0" <?php if($rec_email_comment == '0'){  echo $reccom = 'selected = "selected" ' ; } else { echo $reccom = '' ; }  ?>>No</option>
											</select>
										</div>
									
								<div class="col-md-12 text-center">
									<div class="remove-messages"></div>
								<input type="hidden" name="uid" value="<?php echo $id ; ?>">
								<input type="hidden" name="sub_submit_pr" value="Submit" />
								<input type="submit" id="sub_submit" name="sub_submit" class="btn btn-primary text-center form_submit" value="Update Settings" />
								</div>
							</form>
                		</div>
           			 </div>
				</div>
				<div class="col-lg-3 col-md-3"></div>
			</div>
		</div>
	</div>
</div>
<?php include("footer.php") ; ?>