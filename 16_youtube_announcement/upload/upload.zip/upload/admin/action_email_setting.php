<?php
ob_start();
session_start();
include("db/config.php");
include("db/function_xss.php");
// Checking Admin is logged in or not
if($_SESSION['admin'] == '' ){
	header('location: '.ADMIN_URL.'/index.php');
	exit;
}
if($_POST['sub_submit_pr']){
	if($_POST['sub_submit_pr'] == 'Submit') {
		$darkMode = filter_var($_POST['darkMode'], FILTER_SANITIZE_NUMBER_INT) ;
		$adminEmail = filter_var($_POST['adminEmail'], FILTER_SANITIZE_EMAIL) ;
		$email_subscriber = filter_var($_POST['email_subscriber'], FILTER_SANITIZE_NUMBER_INT) ;
		$email_comment = filter_var($_POST['email_comment'], FILTER_SANITIZE_NUMBER_INT) ;
		$rec_email_comment = filter_var($_POST['rec_email_comment'], FILTER_SANITIZE_NUMBER_INT) ;
		$statement = $pdo->prepare("update ot_admin set rec_email = '".$adminEmail."' , email_subscriber = '".$email_subscriber."' , email_comment = '".$email_comment."'  , rec_email_comment = '".$rec_email_comment."' , dark_mode = '".$darkMode."' where id = '1'");
		$statement->execute() ;
		$form_message = "Settings Updated Successfully.";
		$output = array( 
						'form_message' => $form_message
					) ;
		echo json_encode($output);
		
	}
} 
?>
