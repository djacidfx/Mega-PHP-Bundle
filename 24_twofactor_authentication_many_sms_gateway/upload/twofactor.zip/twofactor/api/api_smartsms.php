<?php
		$apiDetail = $pdo->prepare("SELECT * FROM key_smartsms WHERE smart_id=?");
		$apiDetail->execute(array(filter_var("10", FILTER_SANITIZE_NUMBER_INT))); 
		$api_smart = $apiDetail->fetchAll(PDO::FETCH_ASSOC);
		foreach($api_smart as $smart)
		{
			$smart_username = _e($smart['smart_username']) ;
			$smart_password = _e(md5($smart['smart_password'])) ;
			$smart_senderid = _e($smart['smart_senderid']) ;
		}
		$to = trim($mobile);
		$m = urlencode($msg);
		$c = curl_init();
		curl_setopt($c, CURLOPT_URL, 'http://www.smartsms.sk/api/send.do');
		curl_setopt($c, CURLOPT_POST, 1);
		curl_setopt($c, CURLOPT_SSL_VERIFYPEER,false);
		curl_setopt($c, CURLOPT_POSTFIELDS, 'username='.$smart_username.'&password='.$smart_password.'&from='.$smart_senderid.'&to='._e($to).'&message='._e($m));
		curl_setopt($c, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($c, CURLOPT_USERAGENT, "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)");
		curl_getinfo($c);
		$result = curl_exec($c);
		curl_close($c);
		return $result;

?>