<?php
		$apiDetail = $pdo->prepare("SELECT * FROM key_customapi_v1 WHERE customapivone_id=?");
		$apiDetail->execute(array(filter_var("7", FILTER_SANITIZE_NUMBER_INT))); 
		$api_customvone = $apiDetail->fetchAll(PDO::FETCH_ASSOC);
		foreach($api_customvone as $customvone)
		{
			$customapivone_url = _e($customvone['customapivone_url']) ;
		}
		$to = trim($mobile);
		$m = urlencode($msg);
		$url = $customapivone_url;
		$url = str_replace("user_phone_abcd", _e($to) , $customapivone_url);
		$url = str_replace("user_message_abcd", _e($m) , $url);
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, filter_var($url, FILTER_SANITIZE_URL));
		curl_setopt($ch, CURLOPT_HEADER, 0);
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
		$response = curl_exec($ch);
		curl_close($ch);
?>