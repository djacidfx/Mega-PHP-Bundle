<?php
		$apiDetail = $pdo->prepare("SELECT * FROM key_bhashsms WHERE bhash_id=?");
		$apiDetail->execute(array(filter_var("1", FILTER_SANITIZE_NUMBER_INT))); 
		$api_bhash = $apiDetail->fetchAll(PDO::FETCH_ASSOC);
		foreach($api_bhash as $bhash)
		{
			$bhash_username = _e($bhash['bhash_username']) ;
			$bhash_password = _e($bhash['bhash_password']) ;
			$bhash_senderid = _e($bhash['bhash_senderid']) ;
			$bhash_priority = _e($bhash['priority']) ;
			$bhash_stype    = _e($bhash['stype']) ;
		}
		$to = trim($mobile);
		$m = urlencode($msg);
		$url = "http://bhashsms.com/api/sendmsg.php?user=".$bhash_username."&pass=".$bhash_password."&sender=".$bhash_senderid."&phone="._e($to)."&text="._e($m)."&priority=".$bhash_priority."&stype=".$bhash_stype."";
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, filter_var($url, FILTER_SANITIZE_URL));
		curl_setopt($ch, CURLOPT_HEADER, 0);
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
		$response = curl_exec($ch);
		$errors = curl_error($ch);
		curl_close($ch);
?>