<?php
		$apiDetail = $pdo->prepare("SELECT * FROM key_infobip WHERE infobip_id=?");
		$apiDetail->execute(array(filter_var("11", FILTER_SANITIZE_NUMBER_INT))); 
		$api_infobip = $apiDetail->fetchAll(PDO::FETCH_ASSOC);
		foreach($api_infobip as $info)
		{
			$info_username = _e($info['infobip_username']) ;
			$info_password = _e($info['infobip_password']) ;
			$info_senderid = _e($info['infobip_senderid']) ;
		}
		$to = trim($countryCode.$mobile);
		$m = urlencode($msg);
		$url = "http://api.infobip.com/api/v3/sendsms/plain?user=".$info_username."&password=".$info_password."&sender=".$info_senderid."&SMSText="._e($m)."&GSM="._e($to)."";
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, filter_var($url, FILTER_SANITIZE_URL));
		curl_setopt($ch, CURLOPT_HEADER, 0);
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
		$response = curl_exec($ch);
		curl_close($ch);

?>