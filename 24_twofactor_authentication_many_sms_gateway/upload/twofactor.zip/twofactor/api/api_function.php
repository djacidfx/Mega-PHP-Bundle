<?php
//check and call which api is active.
$activeApi =  $pdo->prepare("SELECT * FROM api_active WHERE api_active=?");
$activeApi->execute(array(filter_var("1", FILTER_SANITIZE_NUMBER_INT)));
$myApi = $activeApi->fetchAll(PDO::FETCH_ASSOC);
foreach($myApi as $api){
$api_Id = $api['api_id'] ;
}
if($api_Id == '1'){
	require_once('api_bhashsms.php');
}
if($api_Id == '2'){
	require_once('api_indiasms.php');
}
if($api_Id == '3'){
	require_once('api_msgnineone.php');
}
if($api_Id == '4'){
	require_once('api_textlocal.php');
}
if($api_Id == '5'){
	require_once('api_clickatell.php');
}
if($api_Id == '6'){
	require_once('api_twofactor.php');
}
if($api_Id == '7'){
	require_once('api_custom_verone.php');
}
if($api_Id == '8'){
	require_once('api_custom_vertwo.php');
}
if($api_Id == '9'){
	require_once('api_custom_verthree.php');
}
if($api_Id == '10'){
	require_once('api_smartsms.php');
}
if($api_Id == '11'){
	require_once('api_infobip.php');
}
?>