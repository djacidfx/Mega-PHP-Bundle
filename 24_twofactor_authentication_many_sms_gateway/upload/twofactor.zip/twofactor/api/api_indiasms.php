<?php
		$apiDetail = $pdo->prepare("SELECT * FROM key_indiasms WHERE indiasms_id=?");
		$apiDetail->execute(array(filter_var("2", FILTER_SANITIZE_NUMBER_INT))); 
		$api_indiasms = $apiDetail->fetchAll(PDO::FETCH_ASSOC);
		foreach($api_indiasms as $inds)
		{
			$indiasms_username = _e($inds['indiasms_username']) ;
			$indiasms_password = _e($inds['indiasms_password']) ;
			$indiasms_senderid = _e($inds['indiasms_senderid']) ;
			$indiasms_type    = _e($inds['indiasms_type']) ;
		}
		$to = trim($mobile);
		$m = urlencode($msg);
		$url = "https://app.indiasms.com/sendsms/bulksms.php?username=".$indiasms_username."&password=".$indiasms_password."&type=".$indiasms_type."&sender=".$indiasms_senderid."&mobile="._e($to)."&message="._e($m)."";
		$ch = curl_init();
		curl_setopt ( $ch, CURLOPT_URL, filter_var($url, FILTER_SANITIZE_URL) );
		curl_setopt ( $ch, CURLOPT_TIMEOUT, 30 );
		curl_setopt ( $ch, CURLOPT_CONNECTTIMEOUT, 0 );
		curl_setopt ( $ch, CURLOPT_HEADER, 0 );
		curl_setopt ( $ch, CURLOPT_RETURNTRANSFER, 1 );
		$response = curl_exec ( $ch );
		curl_close($ch);
?>