<?php
		$apiDetail = $pdo->prepare("SELECT * FROM key_clickatell WHERE clickatell_id=?");
		$apiDetail->execute(array(filter_var("5", FILTER_SANITIZE_NUMBER_INT))); 
		$api_clickatell = $apiDetail->fetchAll(PDO::FETCH_ASSOC);
		foreach($api_clickatell as $clickatell)
		{
			$clickatell_username = _e($clickatell['clickatell_username']) ;
			$clickatell_password = _e($clickatell['clickatell_password']) ;
			$clickatell_apikey = _e($clickatell['clickatell_apikey']) ;
		}
		$to = trim($countryCode.$mobile);
		$m = urlencode($msg);
		$url = "http://api.clickatell.com/http/sendmsg?api_id=".$clickatell_apikey."&user=".$clickatell_username."&password=".$clickatell_password."&to="._e($to)."&text="._e($m)."";
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, filter_var($url, FILTER_SANITIZE_URL));
		curl_setopt($ch, CURLOPT_HEADER, 0);
		$response = curl_exec($ch);		
		curl_close($ch);
?>