<?php
		$apiDetail = $pdo->prepare("SELECT * FROM key_msgone WHERE msgone_id=?");
		$apiDetail->execute(array(filter_var("3", FILTER_SANITIZE_NUMBER_INT))); 
		$api_msgone = $apiDetail->fetchAll(PDO::FETCH_ASSOC);
		foreach($api_msgone as $msgone)
		{
			$msgone_authkey = _e($msgone['msgone_auth_key']) ;
			$msgone_senderid = _e($msgone['msgone_senderid']) ;
			$route = _e($msgone['msgone_route']) ;
			$country = _e($msgone['msgone_country']) ;
			$template_id = _e($msgone['msgone_template']) ;
		}
		$to = trim($countryCode.$mobile);
		$m = urlencode($msg);
		$ch = curl_init();
		if($template_id == NULL )
		{
			$postData = array(
				'authkey' => $msgone_authkey,
				'mobiles' => _e($to),
				'message' => _e($m),
				'sender' => $msgone_senderid,
				'route' => $route
			);
			$url="http://api.msg91.com/api/sendhttp.php";
			curl_setopt_array($ch, array(
				CURLOPT_URL => filter_var($url, FILTER_SANITIZE_URL),
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_POST => true,
				CURLOPT_POSTFIELDS => $postData
			));
		}
		else {
				$postData = array(
				'authkey' => $msgone_authkey,
				'mobiles' => _e($to),
				'otp' => _e($m),
				'template_id'=>$template_id
				
			);
			$url = "https://api.msg91.com/api/v5/otp?";
			curl_setopt_array($ch, array(
				CURLOPT_URL => filter_var($url, FILTER_SANITIZE_URL),
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_POST => false,
				CURLOPT_POSTFIELDS => $postData
			));
		}
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
			$response = curl_exec($ch);
			curl_close($ch);
?>