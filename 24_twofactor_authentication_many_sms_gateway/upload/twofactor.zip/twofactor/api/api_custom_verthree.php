<?php
		$apiDetail = $pdo->prepare("SELECT * FROM key_customapi_v3 WHERE customapivthree_id=?");
		$apiDetail->execute(array(filter_var("9", FILTER_SANITIZE_NUMBER_INT))); 
		$api_customvthree = $apiDetail->fetchAll(PDO::FETCH_ASSOC);
		foreach($api_customvthree as $customvthree)
		{
			$customapivthree_url = _e($customvthree['customapivthree_url']) ;
		}
		$to = "+".$countryCode.$mobile;
		$m = urlencode($msg);
		$newurl = $customapivthree_url;
		$newurl = str_replace("user_phone_abcd", _e($to) , $customapivthree_url);
		$newurl = str_replace("user_message_abcd", _e($m) , $newurl);
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, filter_var($newurl, FILTER_SANITIZE_URL));
		curl_setopt($ch, CURLOPT_HEADER, 0);
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
		$response = curl_exec($ch);
		curl_close($ch);
?>