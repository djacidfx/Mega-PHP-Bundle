<?php
		$apiDetail = $pdo->prepare("SELECT * FROM key_customapi_v2 WHERE customapivtwo_id=?");
		$apiDetail->execute(array(filter_var("8", FILTER_SANITIZE_NUMBER_INT))); 
		$api_customvtwo = $apiDetail->fetchAll(PDO::FETCH_ASSOC);
		foreach($api_customvtwo as $customvtwo)
		{
			$customapivtwo_url = _e($customvtwo['customapivtwo_url']) ;
		}
		$to = urlencode($countryCode.$mobile);
		$m = urlencode($msg);
		$newurl = $customapivtwo_url;
		$newurl = str_replace("user_phone_abcd", _e($to) , $customapivtwo_url);
		$newurl = str_replace("user_message_abcd", _e($m) , $newurl);
		$curl = curl_init();

		  curl_setopt_array($curl, array(
		  CURLOPT_URL => filter_var($newurl, FILTER_SANITIZE_URL),
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => "",
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 30,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => "POST",
		  CURLOPT_POSTFIELDS => "",
		));
		$response = curl_exec($curl);
		curl_close($curl);
?>