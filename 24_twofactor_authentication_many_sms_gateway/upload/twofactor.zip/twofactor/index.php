<?php
require_once('header.php');
?>
<div class="app-title">
        <div>
          <h1><i class="fa fa-laptop"></i>Dashboard</h1>
          <p>Modify this page as you want. </p>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
        </ul>
 </div>
<?php require_once('footer.php'); ?>
