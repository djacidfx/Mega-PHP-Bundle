<?php 
require_once('header.php');  
$indiasmsStatement = $pdo->prepare("SELECT * FROM key_indiasms WHERE indiasms_id = ?");
$indiasmsStatement->execute(array(filter_var("2", FILTER_SANITIZE_NUMBER_INT))); 
$total = $indiasmsStatement->rowCount();    
$indiasms = $indiasmsStatement->fetchAll(PDO::FETCH_ASSOC); 
foreach($indiasms as $isms) {
	$u_name = _e($isms['indiasms_username']);
	$pass   = _e($isms['indiasms_password']);
	$s_id   = _e($isms['indiasms_senderid']);
	$st     = _e($isms['indiasms_type']);
}
if(isset($_POST['submit'])){
$indiasmsid  = filter_var($_POST['indiasmsid'], FILTER_SANITIZE_NUMBER_INT) ;
$username = filter_var($_POST['Username'], FILTER_SANITIZE_STRING) ;
$password = filter_var($_POST['password'], FILTER_SANITIZE_STRING) ;
$senderid = filter_var($_POST['senderid'], FILTER_SANITIZE_STRING) ;
$stype    = filter_var($_POST['stype'], FILTER_SANITIZE_STRING) ;
$actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
	if($total == 0) {
		$ins = $pdo->prepare("INSERT INTO key_indiasms (indiasms_id, indiasms_username, indiasms_password, indiasms_senderid, indiasms_type) VALUES (?,?,?,?,?)");
		$ins->execute(array($indiasmsid,$username,$password,$senderid,$stype));
	} else {
		$upd = $pdo->prepare("UPDATE key_indiasms SET indiasms_username=? , indiasms_password=? , indiasms_senderid=?, indiasms_type=? WHERE indiasms_id=?");
		$upd->execute(array($username,$password,$senderid,$stype,$indiasmsid));
	}
	header("location:".$actual_link."");
}
?>
<main class="page-content">
	<div class="container-fluid">
		<h2>IndiaSMS Details</h2>
      	<hr>
      	<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="row">
		   			<div class="col-md-3 col-lg-3"></div>
					<div class="col-md-6 col-lg-6">
						<form action="" method="post" >
							<?php $csrf->echoInputField(); ?>
					  		<div class="form-group">
								<label>IndiaSMS Username*</label>
								<input type="text" class="form-control"   placeholder="IndiaSMS Username" name="Username" value="<?php echo $u_name ; ?>" required>
					  		</div>
					  		<div class="form-group">
								<label>IndiaSMS Password*</label>
								<input type="text" class="form-control"  placeholder="IndiaSMS Password" name="password" value="<?php echo $pass; ?>" required>
					  		</div>
					  		<div class="form-group">
								<label>IndiaSMS Sender ID*</label>
								<input type="text" class="form-control"  placeholder="Sender ID" name="senderid" value="<?php echo $s_id; ?>" required>
					  		</div>
					  		<div class="form-group">
								<label>type*<small class="form-text text-muted">TEXT</small></label>
								<input type="text" class="form-control"   name="stype" value="<?php if($st==''){echo "TEXT" ; } else{ echo $st; } ?>" required>
					  		</div>
					  		<div class="form-group" align="center">
					  			<input type="hidden" name="indiasmsid" value="<?php echo filter_var("2", FILTER_SANITIZE_NUMBER_INT) ; ?>" />
					  			<input type="submit" class="btn btn-primary" name="submit" value="Save">
					  		</div>
						</form>
					</div>
					<div class="col-md-3 col-lg-3"></div>
				</div>
			</div>
		</div>
	</div>
</main><!-- page-content" -->
<?php require_once('footer.php'); ?>
