<?php 
require_once('header.php'); 
$success_message =''; 
$smartStatement = $pdo->prepare("SELECT * FROM key_smartsms WHERE smart_id = ?");
$smartStatement->execute(array(filter_var("10", FILTER_SANITIZE_NUMBER_INT))); 
$total = $smartStatement->rowCount();    
$smart = $smartStatement->fetchAll(PDO::FETCH_ASSOC); 
foreach($smart as $b)
	{
		$u_name = _e($b['smart_username']);
		$pass   = _e($b['smart_password']);
		$s_id   = _e($b['smart_senderid']);
	}
if(isset($_POST['submit'])){
	$smartid  = filter_var($_POST['smartid'], FILTER_SANITIZE_NUMBER_INT) ;
	$username = filter_var($_POST['Username'], FILTER_SANITIZE_STRING) ;
	$password = filter_var($_POST['password'], FILTER_SANITIZE_STRING) ;
	$senderid = filter_var($_POST['senderid'], FILTER_SANITIZE_STRING) ;
	$actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
	if($total == 0) {
		$ins = $pdo->prepare("INSERT INTO key_smartsms (smart_id,smart_username,smart_password,smart_senderid) VALUES (?,?,?,?)");
		$ins->execute(array($smartid,$username,$password,$senderid));
	} else {
		$upd = $pdo->prepare("UPDATE key_smartsms SET smart_username=? , smart_password=? , smart_senderid=? WHERE smart_id=?");
		$upd->execute(array($username,$password,$senderid,$smartid));
	}
	header("location:".$actual_link."");
}
?>
<main class="page-content">
    <div class="container-fluid">
      <h2>Smartsms.sk Details</h2>
      <hr>
      <div class="row">
	  	<div class="col-lg-12 col-md-12">
		  <div class="row">
		   	<div class="col-md-3 col-lg-3"></div>
			<div class="col-md-6 col-lg-6">
				<form action="" method="post" >
					  <div class="form-group">
					  	<?php $csrf->echoInputField(); ?>
						<label>Smartsms.sk Username*</label>
						<input type="text" class="form-control"   placeholder="Smartsms.sk Username" name="Username" value="<?php echo $u_name ; ?>" required>
					  </div>
					  <div class="form-group">
						<label>Smartsms.sk Password*</label>
						<input type="text" class="form-control"  placeholder="Smartsms.sk Password" name="password" value="<?php echo $pass; ?>" required>
					  </div>
					  <div class="form-group">
						<label>Smartsms.sk Sender ID (This is your sender id or code)*</label>
						<input type="text" class="form-control"  placeholder="Smartsms.sk Sender ID" name="senderid" value="<?php echo $s_id; ?>" required>
					  </div>
					  <div class="form-group" align="center">
					  <input type="hidden" name="smartid" value="<?php echo filter_var("10", FILTER_SANITIZE_NUMBER_INT) ; ?>" />
					  <input type="submit" class="btn btn-primary" name="submit" value="Save">
					  </div>
					</form>
			</div>
			<div class="col-md-3 col-lg-3"></div>
		  </div>
		</div>
	  </div>
	</div>
</main> <!-- page-content" -->
<?php require_once('footer.php'); ?>
