<?php 
require_once('header.php'); 
$success_message =''; 
$bhashStatement = $pdo->prepare("SELECT * FROM key_bhashsms WHERE bhash_id = ?");
$bhashStatement->execute(array(filter_var("1", FILTER_SANITIZE_NUMBER_INT))); 
$total = $bhashStatement->rowCount();    
$bhash = $bhashStatement->fetchAll(PDO::FETCH_ASSOC); 
foreach($bhash as $b)
	{
		$u_name = _e($b['bhash_username']);
		$pass   = _e($b['bhash_password']);
		$s_id   = _e($b['bhash_senderid']);
		$pr     = _e($b['priority']);
		$st     = _e($b['stype']);
	}
if(isset($_POST['submit'])){
	$bhashid  = filter_var($_POST['bhashid'], FILTER_SANITIZE_NUMBER_INT) ;
	$username = filter_var($_POST['Username'], FILTER_SANITIZE_STRING) ;
	$password = filter_var($_POST['password'], FILTER_SANITIZE_STRING) ;
	$senderid = filter_var($_POST['senderid'], FILTER_SANITIZE_STRING) ;
	$priority = filter_var($_POST['priority'], FILTER_SANITIZE_STRING) ;
	$stype    = filter_var($_POST['stype'], FILTER_SANITIZE_STRING) ;
	$actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
	if($total == 0) {
		$ins = $pdo->prepare("INSERT INTO key_bhashsms (bhash_id,bhash_username,bhash_password,bhash_senderid,priority,stype) VALUES (?,?,?,?,?,?)");
		$ins->execute(array($bhashid,$username,$password,$senderid,$priority,$stype));
	} else {
		$upd = $pdo->prepare("UPDATE key_bhashsms SET bhash_username=? , bhash_password=? , bhash_senderid=?, priority=? , stype=? WHERE bhash_id=?");
		$upd->execute(array($username,$password,$senderid,$priority,$stype,$bhashid));
	}
	header("location:".$actual_link."");
}
?>
<main class="page-content">
    <div class="container-fluid">
      <h2>BhashSMS Details</h2>
      <hr>
      <div class="row">
	  	<div class="col-lg-12 col-md-12">
		  <div class="row">
		   	<div class="col-md-3 col-lg-3"></div>
			<div class="col-md-6 col-lg-6">
				<form action="" method="post" >
					  <div class="form-group">
					  	<?php $csrf->echoInputField(); ?>
						<label>BhashSMS Username*</label>
						<input type="text" class="form-control"   placeholder="BhashSMS Username" name="Username" value="<?php echo $u_name ; ?>" required>
					  </div>
					  <div class="form-group">
						<label>BhashSMS Password*</label>
						<input type="text" class="form-control"  placeholder="BhashSMS Password" name="password" value="<?php echo $pass; ?>" required>
					  </div>
					  <div class="form-group">
						<label>BhashSMS Sender ID*</label>
						<input type="text" class="form-control"  placeholder="Sender ID" name="senderid" value="<?php echo $s_id; ?>" required>
					  </div>
					  <div class="form-group">
						<label>Priority*<small class="form-text text-muted">ndnd/dnd</small></label>
						<input type="text" class="form-control"  placeholder="Priority" name="priority" value="<?php echo $pr; ?>" required>
					  </div>
					  <div class="form-group">
						<label>stype*<small class="form-text text-muted">normal/flash/unicode</small></label>
						<input type="text" class="form-control"  placeholder="Password" name="stype" value="<?php echo $st; ?>" required>
					  </div>
					  <div class="form-group" align="center">
					  <input type="hidden" name="bhashid" value="<?php echo filter_var("1", FILTER_SANITIZE_NUMBER_INT) ; ?>" />
					  <input type="submit" class="btn btn-primary" name="submit" value="Save">
					  </div>
					</form>
			</div>
			<div class="col-md-3 col-lg-3"></div>
		  </div>
		</div>
	  </div>
	</div>
</main> <!-- page-content" -->
<?php require_once('footer.php'); ?>
