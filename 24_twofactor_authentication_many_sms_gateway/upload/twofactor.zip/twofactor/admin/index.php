<?php
require_once('header.php'); 
$error_message ='';
if(isset($_POST['set_api'])){
	if(empty($_POST['mysms'])) {
		$error_message .= 'Please select any Service.<br>';
	} else {
		$mysms = filter_var($_POST['mysms'], FILTER_SANITIZE_NUMBER_INT); 
		$update_servicezero = $pdo->prepare("UPDATE api_active SET api_active=0 WHERE 1");
		$update_servicezero->execute();
		$update_service = $pdo->prepare("UPDATE api_active SET api_active=? WHERE api_id=?");
		$update_service->execute(array(filter_var("1", FILTER_SANITIZE_NUMBER_INT),$mysms));
		$actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
		header("location:".$actual_link."");
	}
}
?>
<main class="page-content">
	<div class="container-fluid">
		<h2>Active Service</h2>
      	<hr>
		<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="row">
					<div class="col-md-12 col-lg-12">
						<?php 
						if( (isset($error_message)) && ($error_message!='') ):
							echo '<div class="alert alert-danger">'.$error_message.'</div>';
						endif;
						?>
						<form action="" method="post" >
							<?php $csrf->echoInputField(); ?>
							<?php
							$api = $pdo->prepare("SELECT * FROM api_active WHERE 1");
							$api->execute();   
							$api_result = $api->fetchAll(PDO::FETCH_ASSOC); 
							foreach($api_result as $API) {
							?>
							<div class="form-group">
								<input class="form-check-input" type="radio" id="<?php echo _e($API['api_id']) ;?>" name="mysms" value="<?php echo _e($API['api_id']) ;?>" <?php if(_e($API['api_active']) == '1'){ echo 'checked="checked"' ; } ?> >
								<label class="form-check-label" for="<?php echo _e($API['api_id']) ;?>">
								<?php echo _e($API['api_name']) ; ?>
								<br />
								<small><?php echo _e($API['api_instruction']) ; ?></small>
								</label>
							</div>
							<hr />
							<?php } ?>
					  		<div class="form-group" >
					  			<input type="submit" class="btn btn-primary" name="set_api" value="Save" >
					  		</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</main> <!-- page-content" -->
<?php require_once('footer.php'); ?>
