<?php 
require_once('header.php'); 
$success_message =''; 
$infobipStatement = $pdo->prepare("SELECT * FROM key_infobip WHERE infobip_id = ?");
$infobipStatement->execute(array(filter_var("11", FILTER_SANITIZE_NUMBER_INT))); 
$total = $infobipStatement->rowCount();    
$infobip = $infobipStatement->fetchAll(PDO::FETCH_ASSOC); 
foreach($infobip as $b)
	{
		$u_name = _e($b['infobip_username']);
		$pass   = _e($b['infobip_password']);
		$s_id   = _e($b['infobip_senderid']);
	}
if(isset($_POST['submit'])){
	$infobipid  = filter_var($_POST['infobipid'], FILTER_SANITIZE_NUMBER_INT) ;
	$username = filter_var($_POST['Username'], FILTER_SANITIZE_STRING) ;
	$password = filter_var($_POST['password'], FILTER_SANITIZE_STRING) ;
	$senderid = filter_var($_POST['senderid'], FILTER_SANITIZE_STRING) ;
	$actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
	if($total == 0) {
		$ins = $pdo->prepare("INSERT INTO key_infobip (infobip_id,infobip_username,infobip_password,infobip_senderid) VALUES (?,?,?,?)");
		$ins->execute(array($infobipid,$username,$password,$senderid));
	} else {
		$upd = $pdo->prepare("UPDATE key_infobip SET infobip_username=? , infobip_password=? , infobip_senderid=? WHERE infobip_id=?");
		$upd->execute(array($username,$password,$senderid,$infobipid));
	}
	header("location:".$actual_link."");
}
?>
<main class="page-content">
    <div class="container-fluid">
      <h2>Infobip.in Details</h2>
      <hr>
      <div class="row">
	  	<div class="col-lg-12 col-md-12">
		  <div class="row">
		   	<div class="col-md-3 col-lg-3"></div>
			<div class="col-md-6 col-lg-6">
				<form action="" method="post" >
					  <div class="form-group">
					  	<?php $csrf->echoInputField(); ?>
						<label>Infobip Username*</label>
						<input type="text" class="form-control"   placeholder="Infobip Username" name="Username" value="<?php echo $u_name ; ?>" required>
					  </div>
					  <div class="form-group">
						<label>Infobip Password*</label>
						<input type="text" class="form-control"  placeholder="Infobip Password" name="password" value="<?php echo $pass; ?>" required>
					  </div>
					  <div class="form-group">
						<label>Infobip Sender ID (This is your sender id or code)*</label>
						<input type="text" class="form-control"  placeholder="Infobip Sender ID" name="senderid" value="<?php echo $s_id; ?>" required>
					  </div>
					  <div class="form-group" align="center">
					  <input type="hidden" name="infobipid" value="<?php echo filter_var("11", FILTER_SANITIZE_NUMBER_INT) ; ?>" />
					  <input type="submit" class="btn btn-primary" name="submit" value="Save">
					  </div>
					</form>
			</div>
			<div class="col-md-3 col-lg-3"></div>
		  </div>
		</div>
	  </div>
	</div>
</main> <!-- page-content" -->
<?php require_once('footer.php'); ?>
