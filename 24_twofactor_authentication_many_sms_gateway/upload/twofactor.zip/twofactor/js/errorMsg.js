// JavaScript Document
jQuery(function ($) {
	
	"use strict";
	$(document).on("click","#hide", function() {
		$(".errorMessage").hide();
	});
});