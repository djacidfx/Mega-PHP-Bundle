-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jun 06, 2020 at 05:55 AM
-- Server version: 5.7.28
-- PHP Version: 7.2.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;



-- --------------------------------------------------------

--
-- Table structure for table `expense_admin`
--

DROP TABLE IF EXISTS `expense_admin`;
CREATE TABLE IF NOT EXISTS `expense_admin` (
  `id` int(11) NOT NULL,
  `adm_email` varchar(100) NOT NULL,
  `adm_password` varchar(60) NOT NULL,
  `adm_otp` int(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `expense_admin`
--

INSERT INTO `expense_admin` (`id`, `adm_email`, `adm_password`, `adm_otp`) VALUES
(1, 'admin@admin.com', '$2y$10$dtllVJZBMzAsbt608Vs1sOyi8DCAL4pzqZM/6oZEXoXg6BHOIpale', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `expense_biller`
--

DROP TABLE IF EXISTS `expense_biller`;
CREATE TABLE IF NOT EXISTS `expense_biller` (
  `biller_id` int(11) NOT NULL AUTO_INCREMENT,
  `biller_contact` int(11) NOT NULL,
  `biller_email` varchar(55) NOT NULL,
  `biller_name` varchar(255) NOT NULL,
  `biller_tax` varchar(100) NOT NULL,
  `biller_address` text NOT NULL,
  `biller_date` date NOT NULL,
  `biller_status` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`biller_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `expense_logbook`
--

DROP TABLE IF EXISTS `expense_logbook`;
CREATE TABLE IF NOT EXISTS `expense_logbook` (
  `logbook_id` int(11) NOT NULL AUTO_INCREMENT,
  `logbook_name` varchar(255) NOT NULL,
  `logbook_taxable_amt` decimal(18,2) NOT NULL,
  `logbook_tax_amt` decimal(18,2) NOT NULL,
  `logbook_totalamt` decimal(18,2) NOT NULL,
  `logbook_date` date NOT NULL,
  `logbook_status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`logbook_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `expense_purchase`
--

DROP TABLE IF EXISTS `expense_purchase`;
CREATE TABLE IF NOT EXISTS `expense_purchase` (
  `purchase_id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_biller_id` int(11) NOT NULL,
  `purchase_invoice` varchar(255) DEFAULT NULL,
  `purchase_total` decimal(18,2) NOT NULL,
  `purchase_taxable_total` decimal(18,2) NOT NULL,
  `purchase_tax_total` decimal(18,2) NOT NULL,
  `purchase_date` date NOT NULL,
  `purchase_status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`purchase_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `expense_purchase_item`
--

DROP TABLE IF EXISTS `expense_purchase_item`;
CREATE TABLE IF NOT EXISTS `expense_purchase_item` (
  `purchase_serial_id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_order_id` int(11) NOT NULL,
  `purchase_product_name` varchar(255) NOT NULL,
  `purchase_product_taxabletotal` decimal(18,2) NOT NULL,
  `purchase_product_taxtotal` decimal(18,2) NOT NULL,
  PRIMARY KEY (`purchase_serial_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
