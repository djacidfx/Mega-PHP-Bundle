<?php include("header.php") ; ?>

<div class="app-title">
        <div>
          <h1><i class="fa fa-laptop"></i> Dashboard Analysis</h1>
          <p>Hassle Free Admin Panel Dashboard</p>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
        </ul>
 </div>
 <div class="row">
 		<div class="col-lg-12 col-md-12">
				<h5 class="border-bottom text-muted">Earning Analysis</h5>
			</div>
        <div class="col-md-4 col-lg-4">
          <div class="widget-small primary coloured-icon"><i class="icon fa fa-usd fa-3x"></i>
            <div class="info">
              <h5 class="font-italic text-muted">Today</h5>
              <p><b><?php echo count_total_purchase_value_curday($pdo) ; ?></b></p>
            </div>
          </div>
        </div>
		<div class="col-md-4 col-lg-4">
          <div class="widget-small warning coloured-icon"><i class="icon fa fa-usd fa-3x"></i>
            <div class="info">
              <h5 class="font-italic text-muted">This Month</h5>
              <p><b><?php echo count_total_purchase_value_curmonth($pdo) ; ?></b></p>
            </div>
          </div>
        </div>
        <div class="col-md-4 col-lg-4">
          <div class="widget-small info coloured-icon"><i class="icon fa fa-usd fa-3x"></i>
            <div class="info">
              <h5 class="font-italic text-muted">Total</h5>
              <p><b><?php echo count_total_purchase_value($pdo) ; ?></b></p>
            </div>
          </div>
        </div>
</div>
<div class="row">
 		<div class="col-lg-12 col-md-12">
				<h5 class="border-bottom text-muted">Bills Analysis</h5>
			</div>
        <div class="col-md-4 col-lg-4">
          <div class="widget-small primary coloured-icon"><i class="icon fa fa-file fa-3x"></i>
            <div class="info">
              <h5 class="font-italic text-muted">Total Bills</h5>
              <p><b><?php echo count_total_bill($pdo) ; ?></b></p>
            </div>
          </div>
        </div>
		<div class="col-md-4 col-lg-4">
          <div class="widget-small warning coloured-icon"><i class="icon fa fa-check fa-3x"></i>
            <div class="info">
              <h5 class="font-italic text-muted">Active Bills</h5>
              <p><b><?php echo count_total_active_bill($pdo) ; ?></b></p>
            </div>
          </div>
        </div>
        <div class="col-md-4 col-lg-4">
          <div class="widget-small info coloured-icon"><i class="icon fa fa-times fa-3x"></i>
            <div class="info">
              <h5 class="font-italic text-muted">Deactive Bills</h5>
              <p><b><?php echo count_total__deactive_bill($pdo) ; ?></b></p>
            </div>
          </div>
        </div>
        
      </div>
<div class="row">
 		<div class="col-lg-12 col-md-12">
				<h5 class="border-bottom text-muted">Payment Analysis</h5>
			</div>
        <div class="col-md-4 col-lg-4">
          <div class="widget-small primary coloured-icon"><i class="icon fa fa-arrows-alt fa-3x"></i>
            <div class="info">
              <h5 class="font-italic text-muted">Active Bills</h5>
              <p><b><?php echo count_total_active_bill($pdo) ; ?></b></p>
            </div>
          </div>
        </div>
		<div class="col-md-4 col-lg-4">
          <div class="widget-small warning coloured-icon"><i class="icon fa fa-check fa-3x"></i>
            <div class="info">
              <h5 class="font-italic text-muted">Successful Payments</h5>
              <p><b><?php echo count_total_completed_bill($pdo) ; ?></b></p>
            </div>
          </div>
        </div>
        <div class="col-md-4 col-lg-4">
          <div class="widget-small info coloured-icon"><i class="icon fa fa-times fa-3x"></i>
            <div class="info">
              <h5 class="font-italic text-muted">Due Payments</h5>
              <p><b><?php echo count_total_due_bill($pdo) ; ?></b></p>
            </div>
          </div>
        </div>
        
      </div>
<?php include("footer.php") ; ?>