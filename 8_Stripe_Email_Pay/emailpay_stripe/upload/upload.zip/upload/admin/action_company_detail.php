<?php
ob_start();
session_start();
include("db/config.php");
include("db/function_xss.php");
// Checking Admin is logged in or not
if( empty($_SESSION['admin']['id'])  ){
	header('location: index.php');
	exit;
}
if($_POST['c_submit_pr']){
	if($_POST['c_submit_pr'] == 'Submit') {
		$cphone = filter_var($_POST['cphone'], FILTER_SANITIZE_NUMBER_INT) ;
		$cname = filter_var($_POST['cname'], FILTER_SANITIZE_STRING) ;
		$ctax =  filter_var($_POST['ctax'], FILTER_SANITIZE_STRING) ;
		$cemail = filter_var($_POST['cemail'], FILTER_SANITIZE_EMAIL) ;
		$id = filter_var($_POST['uid'], FILTER_SANITIZE_NUMBER_INT) ;
		
		$update_company = $pdo->prepare("update subscription_admin set c_name = ? , c_email = ?  , c_phone = ? , c_tax = ? where id = ?");
		$update_company->execute(array($cname,$cemail,$cphone,$ctax,$id));
		$form_message = "Company Details saved Successfully.";
		$output = array( 
					'form_message' => $form_message
				) ;
		echo json_encode($output);
		} else {
			$form_message = "This is not authorized.";
			$output = array( 
					'form_message' => $form_message
					) ;
			echo json_encode($output);
		}
} 
?>
