<?php include("header.php") ; ?>
<div class="container mar-top">
	<div class="row">
		<div class="col-lg-12 col-md-12">
			<div class="row">
				<div class="col-lg-3 col-md-3"></div>
				<div class="col-lg-6 col-md-6">
					<div class="card">
                		<div class="card-header bg-secondary text-white text-center"><h4> Company Details</h4></div>
                		<div class="card-body">
							<form method="post" id="company_validation" class="company_validation">
								<div class="form-group">
									<label><i class="fa fa-envelope"></i> Company Email* <small>(Here You'll also get Successfull Paypal Transaction Details)</small></label>
									<input type="email" class="form-control" name="cemail" id="cemail" value="<?php echo $c_email ; ?>"  maxlength="50" required>
								</div>
								<div class="form-group">
									<label><i class="fa fa-pencil-alt"></i> Company Name*</label>
									<input type="text" class="form-control" name="cname" id="cname" value="<?php echo $c_name ; ?>" maxlength="100" required>
								</div>
								<div class="form-group">
									<label><i class="fa fa-phone"></i> Company Phone</label>
									<input type="text" class="form-control" name="cphone" id="cphone" value="<?php echo $c_phone ; ?>" maxlength="20">
								</div>
								<div class="form-group">
									<label><i class="fa fa-list"></i> Company Tax Number</label>
									<input type="text" class="form-control" name="ctax" id="ctax" value="<?php echo $c_tax ; ?>" maxlength="50">
								</div>
								
								<div class="col-md-12 text-center">
									<div class="remove-messages"></div>
								<input type="hidden" name="uid" value="<?php echo $id ; ?>">
								<input type="hidden" name="c_submit_pr" value="Submit" />
								<input type="submit" id="c_submit" name="c_submit" class="btn btn-primary text-center form_submit" value="Save Details" />
								</div>
							</form>
                		</div>
           			 </div>
				</div>
				<div class="col-lg-3 col-md-3"></div>
			</div>
		</div>
	</div>
</div>
<?php include("footer.php") ; ?>