<?php
ob_start();
session_start();
require_once('admin/db/config.php');
require_once("admin/db/function_xss.php");
$err = 0;
if( !empty($_POST['email']) && !empty($_POST['orderId']) ){
		 $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL) ;
		 $orderId = filter_var($_POST['orderId'], FILTER_SANITIZE_NUMBER_INT);
		 $checkOrder =  $pdo->prepare("SELECT * FROM payments WHERE customer_email=? and id=?");
		 $checkOrder->execute(array($email,$orderId));
		 $ok = $checkOrder->rowCount();
		 $order_data = $checkOrder->fetchAll(PDO::FETCH_ASSOC);
		 if($ok > 0){
			$email = base64_encode($email) ;
			$output = array( 
						'email'    => $email,
						'orderId'  => $orderId,
						'err'      => '1'
					) ;
			echo json_encode($output);
			
		} else {
			echo $err ;
		}
}
?>