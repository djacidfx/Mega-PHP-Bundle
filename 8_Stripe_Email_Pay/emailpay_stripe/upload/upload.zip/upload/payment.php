<?php
require_once("admin/db/config.php");
require_once("admin/db/function_xss.php");

$admin = $pdo->prepare("SELECT * FROM subscription_admin WHERE  id = '1'");
$admin->execute();   
$admin_result = $admin->fetchAll(PDO::FETCH_ASSOC);
foreach($admin_result as $adm) {
//escape all  data
	$c_name = _e($adm['c_name']) ;
	$c_email = _e($adm['c_email']) ;
	$c_phone = _e($adm['c_phone']) ;
	$c_tax = _e($adm['c_tax']) ;
}
$headers = "";

$payment_id = $statusMsg = $payment_status = ''; 
$ordStatus = 'error'; 

// Check whether stripe token is not empty 
if(!empty($_POST['tokenStripe'])){ 
     
	$item_id = $_POST['item_number'] ; 
	$itemName = $_POST['item_name'] ;
    $token  = $_POST['tokenStripe'] ; 
    $name = $_POST['cname']; 
    $email = $_POST['cemail'] ; 
	$itemPrice = $_POST['item_amount'] ;
	$currency = $_POST['currency_code'] ;
    // Include Stripe PHP library 
    require_once 'stripe-php/init.php'; 
     
    // Set API key 
    \Stripe\Stripe::setApiKey(STRIPE_API_KEY); 
	
	 $curl = new \Stripe\HttpClient\CurlClient();
	$curl->setEnablePersistentConnections(false);
	\Stripe\ApiRequestor::setHttpClient($curl);
     
    // Add customer to stripe 
    try {  
        $customer = \Stripe\Customer::create(array( 
            'email' => $email, 
			'name' => $name,
            'source'  => $token 
        )); 
    }catch(Exception $e) {  
        $api_error = $e->getMessage();  
    } 
     
    if(empty($api_error) && $customer){  
         
        // Convert price to cents 
        $itemPriceCents = ($itemPrice*100); 
         
        // Charge a credit or a debit card 
        try {  
            $charge = \Stripe\Charge::create(array( 
                'customer' => $customer->id, 
                'amount'   => $itemPriceCents, 
                'currency' => $currency, 
                'description' => $itemName 
            )); 
        }catch(Exception $e) {  
            $api_error = $e->getMessage();  
        } 
         
        if(empty($api_error) && $charge){ 
         
            // Retrieve charge details 
            $chargeJsonData = $charge->jsonSerialize(); 
         
            // Check whether the charge is successful 
            if($chargeJsonData['amount_refunded'] == 0 && empty($chargeJsonData['failure_code']) && $chargeJsonData['paid'] == 1 && $chargeJsonData['captured'] == 1){ 
                // Transaction details  
                $txn_id = $chargeJsonData['balance_transaction']; 
                $total_amt = $chargeJsonData['amount']; 
                $total_amt = ($total_amt/100); 
                $paidCurrency = $chargeJsonData['currency']; 
                $payment_status = "Completed"; 
                $payDate = date('Y-m-d') ;
				$statement = $pdo->prepare("update payments set txn_id = ?, total_amt = ?, payment_status = ?, pay_date = ? where id = ? ");
				$sql = $statement->execute(array($txn_id,$total_amt,$payment_status,$payDate,$item_id));
				if($sql){
					$cust = $pdo->prepare("select * from payments where id='".$item_id."'");
					$cust->execute();
					$custData = $cust->fetchAll(PDO::FETCH_ASSOC);
					foreach($custData as $user){
					$cemail = _e($user['customer_email']) ;
					$cname = _e($user['customer_name']) ;
					$cphone = _e($user['customer_phone']) ;
					$ctax = _e($user['customer_tax_number']) ;
					$purpose = _e($user['payment_purpose']) ;
					$price = _e($user['total_amt']) ;
					$order_id = _e($user['id']) ;
					}
					$to = $cemail ;
					$subject = "Stripe Transaction is ".$payment_status ;
					$headers .= 'MIME-Version: 1.0' . "\r\n" ;
					$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n" ; 
					$headers .= "X-Priority: 1 (Highest)\n";
					$headers .= "X-MSMail-Priority: High\n";
					$headers .= "Importance: High\n";
					include("send_email.php");
					$toAdmin = $c_email ;
					$adminSubject = "Congratulations! New Stripe Transaction from User.";
					mail($to, $subject, $body, $headers);
					mail($toAdmin, $adminSubject, $body, $headers);
				}
                // If the order is successful 
                if($payment_status == 'Completed'){ 
                    $ordStatus = 'Success'; 
					$plan = $pdo->prepare("select success_message from subscription_admin where id='1'") ;
					$plan->execute();
					$planData = $plan->fetchAll(PDO::FETCH_ASSOC);
					foreach($planData as $data){
						$statusMsg = _e($data['success_message']) ;
					}
                }else{ 
                    $statusMsg = "Your Payment has Failed!"; 
                } 
            }else{ 
                $statusMsg = "Transaction has been failed!"; 
            } 
        }else{ 
            $statusMsg = "Charge creation failed! $api_error";  
        } 
    }else{  
       $statusMsg = "Invalid card details! $api_error";  
    } 
}else{ 
    $statusMsg = "We found some error."; 
} 
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Stripe Payment Page</title>
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<meta name="description" content="Stripe Payment Page">
	<link rel="stylesheet" type="text/css" href="<?php echo BASE_URL; ?>css/main.css">
	<link rel="stylesheet" type="text/css" href="<?php echo BASE_URL; ?>css/all.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo BASE_URL; ?>css/custom.css">
</head>
<body>
<div id="logreg-forms" class="shadow-lg">
	<div class="modal-header justify-content-center bg-white">
		<img src="<?php echo ADMIN_URL; ?>/images/siteLogo.png" class="img-fluid"  alt="Logo">
	</div>
        	
				<?php
				
				?>
				<div class="col-lg-12 text-center p-3">
					<h5 class="text-muted">
						<?php 
						if($payment_status === "Completed") {
						?>
						<i class="fa fa-check text-success"></i>
						<?php
						} else {
						?>
						<i class="fa fa-times text-danger"></i>
						<?php 
						}
							echo $statusMsg ; 
						?>
					</h5>
				</div>
				<?php if(!empty($txn_id)){ ?>
				<div class="col-lg-12 text-left p-3">
					<h4>Payment Information</h4>
					<p><b>Transaction ID:</b> <?php echo $txn_id; ?></p>
					<p><b>Paid Amount:</b> <?php echo $total_amt.' '.$paidCurrency; ?></p>
					<p><b>Payment Status:</b> <?php echo $payment_status; ?></p>
					<h4>Product Information</h4>
					<p><b>Name:</b> <?php echo $itemName; ?></p>
					<p><b>Price:</b> <?php echo $itemPrice.' '.$currency; ?></p>
					<p><b>Every Details has been emailed to you.Thanks.</b></p>
				</div>
				<?php } ?>
				<div class="col-lg-12 text-center p-3"> 
				<a href="<?php echo BASE_URL ; ?>" class="btn btn-info btn-md text-white"> Back to Home</a>
				</div>
				
</div>
</body>
</html>

