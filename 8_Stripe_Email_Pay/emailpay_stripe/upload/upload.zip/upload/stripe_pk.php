<?php
include("admin/db/config.php");
$data = STRIPE_PUBLISHABLE_KEY ;
echo $data ;
?>