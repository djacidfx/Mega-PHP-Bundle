<?php 
require_once('header.php');
?>
<div class="app-title">
        <div>
          <h1><i class="fa fa-key"></i> Clickatell SMS Gateway Setup</h1>
		  <p class="text-success">This form required Clickatell Api Key, Username & Password, After saving It enables Clickatell SMS OTP for Users.</p>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
        </ul>
 </div>
  <div class="container mar-top">
	<div class="row">
		<div class="col-lg-12 col-md-12">
			<div class="row">
				<div class="col-lg-3 col-md-3"></div>
				<div class="col-lg-6 col-md-6">
					<div class="card">
                		<div class="card-header bg-secondary text-white text-center"><h4> Clickatell Setup</h4></div>
                		<div class="card-body">
							<div class="remove-smsmessages"></div>
							<form class="verifyClickatell" method="post" >
					  		<div class="form-group">
								<label>Clickatell API Key*</label>
								<input type="text" class="form-control"  value="<?php echo $clickatell_apikey ; ?>" name="clickatellApi" id="clickatellApi" maxlength="200" required  >
					  		</div>
							<div class="form-group">
								<label>Clickatell Username*</label>
								<input type="text" class="form-control"  value="<?php echo $clickatell_username ; ?>" name="clickatellUsername" id="clickatellUsername" maxlength="100" required >
					  		</div>
							<div class="form-group">
								<label>Clickatell Password*</label>
								<input type="text" class="form-control"  value="<?php echo $clickatell_password ; ?>" name="clickatellPassword" id="clickatellPassword" maxlength="200" required >
					  		</div>
					  		<div class="form-group text-center">
					  			<input type="submit" class="btn btn-primary" name="submit" value="Save Clickatell Settings">
					  		</div>
						</form>
						</div>
           			 </div>
				</div>
				<div class="col-lg-3 col-md-3"></div>
			</div>
		</div>
	</div>
</div>
<?php require_once('footer.php'); ?>