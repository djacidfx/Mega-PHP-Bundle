<?php
ob_start();
session_start();
require_once('db/config.php');
if(!isset($_SESSION['admin'])) {
	header('location: '.ADMIN_URL.'/login.php');
	exit;
}
$err = 1 ;
if( !empty($_POST['clickatellApi']) && !empty($_POST['clickatellUsername']) && !empty($_POST['clickatellPassword'])){
	$clickatellApi = filter_var($_POST['clickatellApi'], FILTER_SANITIZE_STRING) ;
	$clickatellUsername = filter_var($_POST['clickatellUsername'], FILTER_SANITIZE_STRING);
	$clickatellPassword = filter_var($_POST['clickatellPassword'], FILTER_SANITIZE_STRING) ;
	$update_setting = $pdo->prepare("UPDATE ot_admin SET clickatell_apikey=? , clickatell_username = ? , clickatell_password = ?  WHERE id='1'");
	$update_setting->execute(array($clickatellApi,$clickatellUsername,$clickatellPassword));
	$err = 0 ;
	echo $err ;
} else {
	$err = 1 ;
	echo $err ;
}
?>