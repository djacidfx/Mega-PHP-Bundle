<?php 
require_once('header.php');
//if page refreshed
$RequestSignature = md5($_SERVER['REQUEST_URI'].$_SERVER['QUERY_STRING'].print_r($_POST, true));
if ($_SESSION['LastRequest'] == $RequestSignature){
	$_SESSION['mobile_verify_message'] = 'Sorry, You have Refreshed the Page. Try Again';
	header("location: manage_email.php");
}
else {
	$_SESSION['LastRequest'] = $RequestSignature;
	if( !empty($_POST['email']) ){
		$email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL) ;
		//check this new mobile is already registered or not
		$checkUser =  $pdo->prepare("SELECT * FROM customer_active WHERE user_email=?");
		$checkUser->execute(array($email));
		$user_ok = $checkUser->rowCount();
		if($user_ok > 0) {
			$_SESSION['email_verify_message'] = 'Sorry, This Email is already registered. Try Again with another Email.';
			header("location: manage_email.php");
		} else {
			$otp = filter_var(code(4), FILTER_SANITIZE_NUMBER_INT) ;
			$to = $email ;
			$from = $admin_email ;
			$from = "From: ".$from ;
			$headers .= 'MIME-Version: 1.0' . "\r\n" ;
			$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n" ; 
			$headers .= $from . "\r\n" ; 
			$subject = "Update Email OTP" ;
			$body = "<br>Update Email OTP is <br><h3>".$otp."</h3><br>Please Do not share with anyone at any cost.";
			if (mail($to, $subject, $body, $headers)){
				$update_tmp_mobile = $pdo->prepare("UPDATE customer_active SET user_otp = ? , user_tmp_email = ? WHERE user_email=?");
				$update_tmp_mobile->execute(array($otp,$email,$customer_email));
			} else {
				$_SESSION['email_verify_message'] = 'Sorry, Email not send. Try Again.';
				header("location: manage_email.php");
			}
		}
	
	} else {
		$_SESSION['email_verify_message'] = 'Email cannot be Empty. Try Again';
		header("location: manage_email.php");
	}
}
?>
<main class="page-content">
	<div class="container-fluid">
		<h2>Manage Email</h2>
      	<hr>
      	<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="row">
		   			<div class="col-md-3 col-lg-3"></div>
					<div class="col-md-6 col-lg-6">
						<form action="user_verify_otp.php" method="post" >
							<?php $csrf->echoInputField(); ?>
					  		<div class="form-group">
								<label>Email</label>
								<input type="text" class="form-control"  name="newemail" value="<?php echo $email ; ?>" readonly="readonly">
								<input type="hidden" name="id" value="<?php echo $id ; ?>">
					  		</div>
					  		<div class="form-group">
								<label>OTP*</label>
								<input type="password" class="form-control"   placeholder="OTP" name="otp" maxlength="10" required>
					  		</div>
					  		<div class="form-group" align="center">
					  			<input type="submit" class="btn btn-primary" name="submit" value="Verify">
					  		</div>
						</form>
					</div>
					<div class="col-md-3 col-lg-3"></div>
			  	</div>
		   	</div>
	  	</div>
	</div>
</main> <!-- page-content" -->
<?php require_once('footer.php'); ?>