<?php
require_once('header.php');
if( !empty($_POST['email']) && !empty($_POST['id']) && !empty($_POST['otp']) ){
	$id = filter_var($_POST['id'], FILTER_SANITIZE_NUMBER_INT) ;
	$mobile = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL) ;
	$otp = filter_var($_POST['otp'], FILTER_SANITIZE_NUMBER_INT);
	$otpAuthentication =  $pdo->prepare("SELECT * FROM customer_active WHERE user_id=? and user_otp=? and active_status=?");
	$otpAuthentication->execute(array($id,$otp,filter_var("1", FILTER_SANITIZE_NUMBER_INT)));
	$otp_ok = $otpAuthentication->rowCount();
	$userData = $otpAuthentication->fetchAll(PDO::FETCH_ASSOC);
	if($otp_ok > 0) {
		?>
		<main class="page-content">
			<div class="container-fluid">
			  <div class="row">
				   <div class="col-lg-12 col-md-12">
					  <div class="row">
						<div class="col-md-3 col-lg-3"></div>
						<div class="col-md-6 col-lg-6">
							<form action="change_user_password.php" method="post" >
							  <?php $csrf->echoInputField(); ?>
							  <div class="form-group">
								<label>Email*</label>
								<input type="text" class="form-control"  value="<?php echo $customer_email ; ?>" name="email" readonly="readonly" >
							  </div>
							  <div class="form-group">
							  	<small>Password must contain minimum 8 Character, at least 1 Uppercase character, at least 1 Lowercase character & at least 1 Number.</small>
							  </div>
							  <div class="form-group">
								<label>New Password*</label>
								<input type="password" class="form-control"  name="newpassword" maxlength="50">
							  </div>
							  <div class="form-group">
								<label>Confirm New Password*</label>
								<input type="text" class="form-control"   name="confirmnewpassword" maxlength="50"  >
							  </div>
							  <div class="form-group" align="center">
							  <input type="submit" class="btn btn-primary" name="submit" value="Change Password">
							  </div>
							</form>
						</div>
						<div class="col-md-3 col-lg-3"></div>
					  </div>
				   </div>
			  </div>
			</div>
		 </main><!-- page-content" -->
		<?php require_once('footer.php'); ?>
		<?php
	}
	else {
		$_SESSION['password_message'] = 'Wrong OTP Entered.';
		header("location: user_password.php");
	}

} else {
	$_SESSION['password_message'] = 'Any of the Field cannot be empty.';
	header("location: user_password.php");
}
?>