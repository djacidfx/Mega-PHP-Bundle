<?php 
include("header.php") ;
if($admin_result == 0){ 
	header("location:dashboard.php") ;
}
$sel = $pdo->prepare("select * from user_announcement_read where user_id = '".$id."'");
$sel->execute();
$fe_total = $sel->rowCount();
if($fe_total > 0){
	$update = $pdo->prepare("update user_announcement_read set read_announcement='1' where user_id = ?");
	$update->execute(array($id));
} else {
	$ins = $pdo->prepare("insert into user_announcement_read (user_id, read_announcement) values (?,?)");
	$ins->execute(array($id,'1'));
}
 ?>

<main class="page-content">
    <div class="container-fluid">
      <h3 class="text-center"> <i class="fa fa-bullhorn"></i> Official Announcements</h3>
      <hr>
      <div class="row">
	  	<div class="col-lg-12 col-md-12">
			<div class="row">
				<div class="col-md-3 col-lg-3"></div>
				<div class="col-md-6 col-lg-6">
				<?php
				foreach($announcement as $notice) {
					$Note = _e($notice['announcement_text']);
					$officialDate = _e($notice['announcement_date']);
				
				?>
					<div class="card-deck mb-3 text-center ">
					<div class="card mb-3 box-shadow basic-my-div ">
					  <div class="card-header">
						<h4 class="my-0 font-weight-normal"><?php echo $officialDate ; ?></h4>
					  </div>
					  <div class="card-body ">
						<?php echo $Note ; ?>
					  </div>
					</div>
					</div>
				<?php
				}
				?>
				
				</div>
				<div class="col-md-3 col-lg-3"></div>
			  </div>
		   </div>
	  </div>
   </div>
</main> <!-- page-content" -->

<?php include("footer.php") ; ?>