<?php 
require_once('header.php');
unset($_SESSION['LastRequest']);
?>
<main class="page-content">
	<div class="container-fluid">
		<h2>Manage Password</h2><small>Sometimes User saves the password so Verify OTP first & after Change the password. This Feature adds an extra layer security.</small> 
      	<hr>
      	<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="row">
		   			<div class="col-md-3 col-lg-3"></div>
					<div class="col-md-6 col-lg-6">
						<?php 
							if(! empty($_SESSION['password_message'])){ ?>
								<div  class="alert alert-danger errorMessage">
								<button type="button" class="close float-right" aria-label="Close" >
								  <span aria-hidden="true" id="hide">&times;</span>
								</button>
								<?php
									echo $_SESSION['password_message'] ;
									unset($_SESSION['password_message']);
								?>
								</div>
						<?php
							}
						?>
						<form action="verify_userpassword_otp.php" method="post" >
							<?php $csrf->echoInputField(); ?>
					  		<div class="form-group">
								<label>Email*</label>
								<input type="text" class="form-control"  value="<?php echo $customer_email ; ?>" name="email" maxlength="50" readonly="readonly" >
					  		</div>
					  		<div class="form-group" align="center">
					  			<input type="submit" class="btn btn-primary" name="submit" value="Continue">
					  		</div>
						</form>
					</div>
					<div class="col-md-3 col-lg-3"></div>
			  	</div>
		   	</div>
	  	</div>
	</div>
</main> <!-- page-content" -->
<?php require_once('footer.php'); ?>