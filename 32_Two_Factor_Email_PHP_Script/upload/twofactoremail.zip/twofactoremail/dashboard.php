<?php
require_once('header.php');
?>
<main class="page-content">
    <div class="container-fluid">
      <h2>User Dashboard</h2>
      <hr>
      <div class="row">
	  	<div class="col-lg-12 col-md-12">
			<div class="row">
				<div class="col-md-3 col-lg-3"></div>
				<div class="col-md-6 col-lg-6">
					<h4>Modify this page as you want.</h4>
				</div>
				<div class="col-md-3 col-lg-3"></div>
			  </div>
		   </div>
	  </div>
   </div>
</main> <!-- page-content" -->
<?php require_once('footer.php'); ?>
