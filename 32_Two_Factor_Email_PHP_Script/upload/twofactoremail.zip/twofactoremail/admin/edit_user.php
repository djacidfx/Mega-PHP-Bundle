<?php 
require_once('header.php');
?>
<main class="page-content">
	<div class="container-fluid">
		<h2>User Details & Activate / Deactivate</h2>
      	<hr>
      	<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="row">
		   			<div class="col-md-12 col-lg-12">
						<div class="panel panel-default">
							<div class="panel-heading">
								<div class="page-heading"> Manage Customer</div>
							</div> <!-- /panel-heading -->
							<div class="panel-body">
								<div class="remove-messages"></div>
								<div class="table-responsive">
									<table class="table table-bordered table-striped" id="manageCustomerTable">
										<thead>
											<tr>
												<th>ID</th>						
												<th>Fullname</th>
												<th>Country</th>							
												<th>Email</th>
												<th>Address</th>
												<th>State</th>
												<th>City</th>
												<th>Zipcode</th>
												<th>Status</th>
												<th>Options</th>
												<th>Delete Permanently</th>
											</tr>
										</thead>
									</table><!-- /table -->
								</div>
							</div> <!-- /panel-body -->
					</div> <!-- /panel -->	
					</div>
				</div>
			</div>
		</div>
	</div>
</main>	<!-- page-content" -->
<?php require_once('footer.php'); ?>

