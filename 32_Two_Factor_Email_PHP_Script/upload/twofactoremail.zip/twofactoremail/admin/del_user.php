<?php
ob_start();
session_start();
include("db/config.php");
// Checking Admin is logged in or not
if(!isset($_SESSION['admin'])) {
	header('location: login.php');
	exit;
}
if($_POST['btn_action'] == 'deleteUserStatus')
	{
		$customerId = filter_var($_POST['delcustomerId'], FILTER_SANITIZE_NUMBER_INT);
		if($customerId) {
			$update = $pdo->prepare("DELETE from customer_active  WHERE user_id=?");
			$result_new = $update->execute(array($customerId));
		}
		if($result_new) {
			echo 'User Deleted Successfully.' ;		
		}
}
?>