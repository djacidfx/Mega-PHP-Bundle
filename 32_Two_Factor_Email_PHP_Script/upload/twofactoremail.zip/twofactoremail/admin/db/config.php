<?php
// Error Reporting Turn Off
ini_set('error_reporting', 0);

// Host Name
$dbhost = 'Your_LocalHost_Name' ;

// Database Name
$dbname = 'Your_Database_Name' ;

// Database Username
$dbuser = 'Your_Database_UserName' ;

// Database Password
$dbpass = 'Your_Database_Password' ;

try {
	$pdo = new PDO("mysql:host={$dbhost};dbname={$dbname}", $dbuser, $dbpass);
	$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch( PDOException $exception ) {
	echo "Connection error :" . $exception->getMessage();
}
?>