<?php 
ob_start();
session_start();
include("../config/db.php") ; 
include("../controller/functions.php") ;
?>