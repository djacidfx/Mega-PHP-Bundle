
				<?php
				if($total_pinned > 0) {
				?>
				
				<?php
					foreach($announcement_pinned as $notice) {
					
						$announceId = _e($notice['announcement_id']);
						$Note = strip_tags($notice['announcement_text']);
						$announceTitle = substr_replace($Note, "", 100);
						$Note = displayTextWithLinks($Note);
						$officialDate = _e($notice['announcement_date']);
						$officialDate =  date('d F, Y',strtotime($officialDate));
						$like = _e($notice['like_count']) ;
						$youtubeId = _e($notice['youtube_id']);
						$twitter_url = _e($notice['twitter_url']);
						$fb_url = _e($notice['fb_url']);
						$fb_url = urlencode($fb_url) ;
						$insta_url = _e($notice['insta_url']);
						$comStatus = _e($notice['comment_active']);
						$comment_sql = "SELECT * FROM comments WHERE announceID = '".$announceId."' and comment_status = '1' " ;
						$comment = $pdo->prepare($comment_sql);
						$comment->execute();
						$total_comment = $comment->rowCount();
						$newcomment_sql = "SELECT * FROM comments WHERE announceID = '".$announceId."' and comment_status = '1' order by comment_id desc LIMIT 3  " ;
						$newcomment = $pdo->prepare($newcomment_sql);
						$newcomment->execute();
						$myComment = $newcomment->fetchAll(PDO::FETCH_ASSOC);
						$total_newcomment = $newcomment->rowCount();
						?>
						<meta name="twitter:title" content="<?php echo $announceTitle  ; ?>">
						<meta name="twitter:description" content="<?php echo strip_tags($Note) ; ?>">
						<meta name="twitter:image" content="">
						<meta name="twitter:card" content="">
						<meta property="og:title" content="<?php echo $announceTitle  ; ?>">
						<meta property="og:description" content="<?php echo strip_tags($Note) ; ?>">
						<meta property="og:image" content="">
						<meta property="og:url" content="">
						<div class="card-deck mb-3 text-left mt-3 ">
							<div class="card mb-3 box-shadow basic-my-div shadow-lg <?php echo $bg ; ?> <?php echo $border ; ?>">
								  <div class="card-header <?php echo $border ; ?>">
									<h5 class="my-0 font-weight-normal <?php echo $color ; ?>"><i class="fa fa-thumb-tack text-success"></i>&ensp;<?php echo $officialDate ; ?></h5>
									<p class="text-right mt-n4"><a href="post/<?php echo $announceId ; ?>"><i class="fa fa-external-link-alt <?php echo $color ; ?>"></i></a></p>
								  </div>
								  <div class="card-body <?php echo $border ; ?>">
									<h5 class="myLi <?php echo $color ; ?>"><?php echo nl2br($Note) ; ?></h5>
									<?php
									if(!empty($youtubeId)){
									?>
									<hr class="<?php echo $color ; ?> <?php echo $border ; ?>">
									<div class="embed-responsive embed-responsive-16by9">
										<iframe  allowfullscreen="allowfullscreen" mozallowfullscreen="mozallowfullscreen"  msallowfullscreen="msallowfullscreen" oallowfullscreen="oallowfullscreen"  webkitallowfullscreen="webkitallowfullscreen" src="https://www.youtube.com/embed/<?php echo $youtubeId ; ?>"></iframe>
									</div>
									<?php
									}
									?>
									<?php
									if(!empty($twitter_url)){
									?>
									<hr>
									<div class="p-1">
									<blockquote class="twitter-tweet" tw-align-center="" data-lang="en"><p dir="ltr" lang="en"><a href="<?php echo $twitter_url ; ?>"></a></p></blockquote>
									</div>
									<?php
									}
									?>
									<?php
									if(!empty($fb_url)){
									?>
									<hr>
									<div class="embed-responsive embed-responsive-1by1">
									<center><iframe src="https://www.facebook.com/plugins/post.php?href=<?php echo $fb_url ; ?>&width=500" width="500" height="659" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe></center>
									</div>
									<?php
									}
									?>
									<?php
									if(!empty($insta_url)){
									?>
									<hr>
									<div class="embed-responsive embed-responsive-1by1">
									<center><iframe src="<?php echo $insta_url ; ?>embed" width="320" height="400" frameborder="0" scrolling="no" allowtransparency="true"></iframe></center>
									</div>
									<?php
									}
									?>
								  </div>
								  <div class="card-footer <?php echo $border ; ?>">
								  <?php
								  	if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
											$ip = $_SERVER['HTTP_CLIENT_IP'];
										} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
											$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
										} else {
											$ip = $_SERVER['REMOTE_ADDR'];
										}
							$statement = $pdo->prepare("select * from announcement_like where announce_id = ? and user_ip = ?");
							$statement->execute(array($announceId,$ip));
							$total_like = $statement->rowCount();
								  ?>
								  <form method="post" class="like_form" id="<?php echo $announceId ; ?>">
								  <input type="hidden" name="announceId" class="announceId" value="<?php echo $announceId ; ?>" >
								  <input type="hidden" name="user_ip" value="<?php echo $ip ; ?>" >
								  <input type="hidden" name="like_counting" id="like_counting<?php echo $announceId ; ?>" value="<?php echo $like ; ?>" >
								  <input type="hidden" name="btn_action" value="Submit">
								  <?php
								  if($total_like > 0){
								  ?>
								  <button  class="btn-darks mt-n2 ml-n3 disabled" disabled="disabled"><img src="admin/images/like.png" class="img-fluid img-comment" /></button><b class="myFo text-success myLike<?php echo $announceId ; ?>"><?php echo $like ; ?></b><?php if($comStatus == '1'){ ?><a href="#!" class="btn-darks text-primary add_comment" id="<?php echo $announceId ; ?>" ><img src="admin/images/comment.png" class="img-fluid img-comment" /></a><?php } ?> <a href="#!" class="btn-darks showComment text-success " id="<?php echo $announceId ; ?>"><b class="myFo">&ensp;<?php echo $total_comment ; ?> Comments</b> <i class="fa fa-caret-down"></i></a> <?php include("sharer_multi.php") ; ?>
								  <?php
								  } else {
								  ?>
								  <button type="submit" id="lik<?php echo $announceId ; ?>" class="btn-darks mt-n2 ml-n3"><img src="admin/images/like.png" class="img-fluid img-comment" /></button><b class="myFo text-success myLike<?php echo $announceId ; ?>"><?php echo $like ; ?></b><?php if($comStatus == '1'){ ?><a href="#!" class="btn-darks  text-primary add_comment" id="<?php echo $announceId ; ?>" ><img src="admin/images/comment.png" class="img-fluid img-comment" /></a><?php } ?><a href="#!" class="btn-darks showComment text-success " id="<?php echo $announceId ; ?>"><b class="myFo">&ensp;<?php echo $total_comment ; ?> Comments</b> <i class="fa fa-caret-down"></i></a>  <?php include("sharer_multi.php") ; ?>
								  <div class="col-lg-12 col-md-12 remove-messages<?php echo $announceId ; ?>"></div>
								  <?php 
								  }
								  ?>
								</form>
								<?php
								if($total_comment > 0) {
								?>
								<div class="col-lg-12 col-md-12 myComment<?php echo $announceId ; ?>  myComm ml-n4 mt-2">
									<span class="shCom">
									<?php 
										foreach($myComment as $com) {
										$commentId = _e($com['comment_id']) ;
										$username = _e($com['fullname']) ;
										$comment_text = strip_tags($com['comment_text']) ;
										$commentDate = _e($com['comment_date']);
										$adminReply = strip_tags($com['admin_reply']);
										$commentDate =  date('d F, Y',strtotime($commentDate));
										?>
									<div class="col-lg-12 col-md-12 <?php echo $color ; ?>">
										<i class="fa fa-user  <?php echo $color ; ?>"></i>  &ensp;<?php echo $username ; ?>&ensp;-&ensp;<small><?php echo $commentDate ; ?></small>
									</div>
									<?php if(empty($adminReply)){ ?>
									<div class="col-lg-12 col-md-12 <?php echo $color ; ?> ml-4 mt-1">
										 <?php echo nl2br($comment_text) ; ?>
									</div>
									<?php } else { ?>
									<div class="col-lg-12 col-md-12 <?php echo $color ; ?> ml-4 mt-1 border <?php echo $bg ; ?>">
										<div class="mt-2">
										 <?php echo nl2br($comment_text) ; ?>
										 <hr class="<?php echo $border ; ?>">
										</div>
										<div>
										<i class="fa fa-user-secret <?php echo $color ; ?>"></i>  &ensp;Admin&ensp;<i class="fa fa-check-circle text-success"></i> <br /><?php echo nl2br($adminReply) ; ?>
										</div>
									</div>
									<?php } ?>
									<hr />
									</span>
									<?php
									}
									?>
									<div class="show_more_new_comment " id="show_more_new_comment<?php echo $commentId; ?>">
							
									<div class="col text-center p-2">
									<div id="loader-icon"><img src="<?php echo BASE_URL ; ?>admin/images/loader.gif" class="img-fluid img-loader" /></div>
									<button id="<?php echo $commentId; ?>" class="show_more_comment btn btn-light btn-sm ann<?php echo $announceId ; ?> " >Load More Comment</button>
									</div>
									</div>
								</div>
								<?php
									}
									?>
								  </div>
							</div>
						</div>
						  <!-- Add Comment Modal -->
								<div id="commentModal<?php echo $announceId; ?>" class="modal fade commentModal ">
									<div class="modal-dialog ">
										<form method="post" id="<?php echo $announceId; ?>" class="comment_form">
											<div class="modal-content <?php echo $bg ; ?> <?php echo $border ; ?>">
												<div class="modal-header">
													<h4 class="modal-title text-success"><i class="fa fa-comment"></i> Add Comment</h4>
													<button type="button" class="close  <?php echo $color ; ?>" data-dismiss="modal" aria-label="Close">
													  <span aria-hidden="true">&times;</span>
													</button>
												</div>
												<div class="modal-body">
													
													<div class="form-group col-md-12">
													<input type="text" name="username" id="username" class="form-control <?php echo $bg ; ?> <?php echo $color ; ?>" placeholder="Full Name*" maxlength="50" required autofocus>
													<input type="email" name="useremail" id="useremail" class="form-control <?php echo $bg ; ?> <?php echo $color ; ?>" placeholder="Email Address*" maxlength="50" required autofocus>
														<textarea placeholder="Comment*" rows="6" class="form-control <?php echo $bg ; ?> <?php echo $color ; ?>" id="comment" name="comment" required ></textarea>
													</div> 
												</div> 
												<div class="modal-footer"> 
													<input type="hidden" name="announcement_id"  value="<?php echo $announceId ; ?>"/>
													<input type="hidden" name="comment_date" value="<?php echo date('Y-m-d') ; ?>"  />
													<input type="hidden" name="announcement_text"  value="<?php echo _e($Note) ; ?>"/>
													<input type="hidden" name="btn_action" id="btn_action" value="AddComment" />
													<input type="submit" name="action" id="action" class="btn btn-info" value="Add Comment" />
													<button type="button" class="btn <?php echo $btn ; ?> <?php echo $border ; ?>" data-dismiss="modal">Close</button>
												</div>
											</div>
										</form>
									</div>
								</div>
						<?php
					
					}
				?>
				
				<?php	
				}
				?>
				
				