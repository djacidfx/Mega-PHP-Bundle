<?php 
require_once('header.php');
if(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
         $url = "https://";   
   } else  {
         $url = "http://";  
	} 
    // Append the host(domain name, ip) to the URL.   
    $url.= $_SERVER['HTTP_HOST'];   
    
    // Append the requested resource location to the URL   
    $url.= $_SERVER['REQUEST_URI'];
	$replace = "";
	$url = str_replace('/admin/addAnnouncement.php', '' . $replace . '/', $url); 
	$serverUrl = $url ; 
	$serverUrl .= "post/";
?>
<main class="page-content">
	<div class="container-fluid">
      	<div class="row">
			<div class="col-lg-12 col-md-12">
				<div class="row">
		   			<div class="col-md-12 col-lg-12">
						<div class="panel panel-default">
							<div class="panel-heading">
								<div class="page-heading d-inline"><h5 class="text-left">Manage Official Announcements
									</h5>
								</div>
								<hr>
								<button class="btn btn-info  m-1 bg-primary border-primary" id="add_announce"><i class="fa fa-bullhorn"></i> Add Official Announcement</button>
							</div> <!-- /panel-heading -->
							<div class="panel-body">
								<div class="remove-messages"></div>
								<div class="row">
									<div class="col-md-12">
									  <div class="tile">
										<div class="tile-body">
											<div class="table-responsive">
												<table class="table table-bordered table-hover" id="manageAnnouncementTable">
													<thead>
														<tr>
															<th>Announcement ID</th>	
															<th>Date</th>					
															<th style="min-width:30%;">Text</th>
															<th class="text-center"><i class="fab fa-youtube text-danger fa-2x"></i></th>
															<th class="text-center"><i class="fab fa-twitter-square text-info fa-2x"></i></th>
															<th class="text-center"><i class="fab fa-facebook-square text-info fa-2x"></i></th>
															<th class="text-center"><i class="fab fa-instagram text-success fa-2x"></i></th>
															
															<th class="text-center"><i class="fa fa-thumb-tack text-success fa-2x"></i></th>
															<th><i class="fa fa-thumbs-up"></i></th>
															<th>Status</th>
															<th><i class="fa fa-pencil-alt"></i></th>
															<th>Add Comment Disable</th>
															<th>Edit Adding Comments</th>
															<th>Pinned to Top</th>
															<th><i class="fa fa-ban"></i></th>
														</tr>
													</thead>
												</table><!-- /table -->
											</div>
										</div>
									</div>
								</div>
							</div>
							</div> <!-- /panel-body -->
					</div> <!-- /panel -->	
					</div>
				</div>
			</div>
		</div>
	</div>
</main><!-- page-content" -->
	<!-- Add Announcement Modal -->
	<div id="announcementModal" class="modal fade" data-backdrop="static" data-keyboard="false">
    	<div class="modal-dialog">
    		<form method="post" id="announcement_form">
    			<div class="modal-content">
    				<div class="modal-header">
						<h4 class="modal-title"><i class="fa fa-plus"></i> Add Announcement</h4>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						  <span aria-hidden="true">&times;</span>
						</button>
    				</div>
    				<div class="modal-body">
						<div class="form-group col-md-6 my-1">
							<label>Announcement Date*</label>
							<input type="text" class="form-control announce_date" id="announce_date" name="announce_date" placeholder="Announcement Date*" autocomplete="off" required>
						</div>
						<div class="form-group col-md-12">
							<label>Announcement Text*</label>
							<textarea placeholder="Announcement Text*" rows="6" class="form-control" id="announceText" name="announceText" required ></textarea>
						</div> 
						<div class="form-group col-md-12">
							<label>Youtube Video URL (Optional)</label>
							<input type="text" class="form-control" id="you_vid" name="you_vid" placeholder="Youtube Video URL" autocomplete="off">
						</div>
						<div class="form-group col-md-12">
							<label>Twitter Status URL (Optional)</label>
							<input type="text" class="form-control" id="twitter_status" name="twitter_status" placeholder="Twitter Status URL" autocomplete="off">
						</div>
						<div class="form-group col-md-12">
							<label>Facebook Post/Video URL (Optional)</label>
							<input type="text" class="form-control" id="fb_status" name="fb_status" placeholder="Facebook Post/Video URL" autocomplete="off">
						</div>
						<div class="form-group col-md-12">
							<label>Instagram Post/Video URL (Optional)</label>
							<input type="text" class="form-control" id="insta_status" name="insta_status" placeholder="Instagram Post/Video URL" autocomplete="off">
						</div>
    				</div> 
    				<div class="modal-footer">
						<input type="hidden" name="webUrl" value="<?php echo $serverUrl ; ?>" >
						<input type="hidden" name="announcement_id" id="announcement_id"/>
						<input type="hidden" name="btn_action" id="btn_action" />
    					<input type="submit" name="action" id="action" class="btn btn-info" value="Add Announcement" />
    					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
    				</div>
    			</div>
    		</form>
    	</div>
    </div>
	<!-- View Youtube Video Modal -->
	<div id="youtubeModal" class="modal fade youtubeModal">
    	<div class="modal-dialog">
    			<div class="modal-content">
    				<div class="modal-header">
						<h4 class="modal-title"><i class="fa fa-video"></i> Youtube Video</h4>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						  <span aria-hidden="true">&times;</span>
						</button>
    				</div>
    				<div class="modal-body1 text-center">
    				</div> 
    				<div class="modal-footer"> 
    					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
    				</div>
    			</div>
    		
    	</div>
    </div>
<?php require_once('footer.php'); ?>

