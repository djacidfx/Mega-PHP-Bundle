<?php
ob_start();
session_start();
include("db/config.php");
include("db/CSRF_Protect.php");
include("db/function_xss.php");
include("countAnnouncementFunction.php") ; 
$csrf = new CSRF_Protect();
// Checking Admin is logged in or not
if($_SESSION['admin'] == '' ){
	header('location: '.ADMIN_URL.'/index.php');
	exit;
}
$id = _e($_SESSION['admin']['id']) ; 
$admin = $pdo->prepare("SELECT * FROM ot_admin WHERE id = ?");
$admin->execute(array($id));   
$admin_result = $admin->fetchAll(PDO::FETCH_ASSOC);
$total = $admin->rowCount();
foreach($admin_result as $adm) {
//escape all  data
	$id = _e($adm['id']);
	$email   = _e($adm['admin_email']);
	$old_password = _e($adm['auth_pass']);
	$alignment = _e($adm['alignment']) ;
	$rec_email = _e($adm['rec_email']);
	$email_subscriber = _e($adm['email_subscriber']);
	$email_comment = _e($adm['email_comment']);
	$rec_email_comment = _e($adm['rec_email_comment']);
	$darkMode = _e($adm['dark_mode']) ;
}
$lim = $pdo->prepare("select * from announcement_limit where id= '1'");
$lim->execute();
$limi = $lim->fetchAll(PDO::FETCH_ASSOC);
foreach($limi as $stLimit){
	$startLim = _e($stLimit['start_lim']);
	$endLim = _e($stLimit['load_lim']);
}

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Dashboard</title>

	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<link rel="stylesheet" href="<?php echo ADMIN_URL ;?>/css/main.css">
	<link rel="stylesheet" href="<?php echo ADMIN_URL ;?>/css/bootstrap-select.min.css">
	<link rel="stylesheet" href="<?php echo ADMIN_URL ;?>/css/all.min.css">
	<link rel="stylesheet" href="<?php echo ADMIN_URL ;?>/css/datepicker.css">
	<link rel="stylesheet" href="<?php echo ADMIN_URL ;?>/css/Latofont.css">
	<link rel="stylesheet" href="<?php echo ADMIN_URL ;?>/css/Niconnefont.css">
	<link rel="icon" href="<?php echo ADMIN_URL; ?>/favicon.png" type="image/png">	
</head>
<body class="app sidebar-mini">
    <!-- Navbar-->
    <header class="app-header"><a class="app-header__logo text-left" href="dashboard.php"><img src="<?php echo ADMIN_URL; ?>/images/siteLogo.png" class="img-fluid" alt="Logo"></a>
      <!-- Sidebar toggle button--><a class="app-sidebar__toggle" href="#" data-toggle="sidebar" aria-label="Hide Sidebar"><i class="fa fa-bars fa-2x"></i></a>
      <!-- Navbar Right Menu-->
      <ul class="app-nav">
        <!-- User Menu-->
        <li class="dropdown"><a class="app-nav__item" href="#" data-toggle="dropdown" aria-label="Open Profile Menu"><i class="fa fa-user fa-lg"></i></a>
          <ul class="dropdown-menu settings-menu dropdown-menu-right">
		  	<li><a class="dropdown-item"  href="change_email.php"><i class="fa fa-envelope"></i> Email</a></li>
            <li><a class="dropdown-item"  href="change_password.php"><i class="fa fa-key"></i> Password</a></li>
            <li><a class="dropdown-item" href="logout.php"><i class="fa fa-sign-out-alt fa-lg"></i> Logout</a></li>
          </ul>
        </li>
      </ul>
    </header>
    <!-- Sidebar menu-->
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
    <aside class="app-sidebar">
      <div class="app-sidebar__user"><i class="fa fa-user-secret fa-2x text-warning"></i>
        <div>
          <p class="app-sidebar__user-name"><?php echo $email ;?></p>
          <p class="app-sidebar__user-designation">Admin</p>
        </div>
      </div>
      <ul class="app-menu">
        <li><a class="app-menu__item" href="dashboard.php"><i class="app-menu__icon fa fa-laptop"></i><span class="app-menu__label">Dashboard</span></a></li>
		<li><a class="app-menu__item" href="<?php echo BASE_URL ; ?>" target="_blank"><i class="app-menu__icon fa fa-bookmark text-warning"></i><span class="app-menu__label text-warning"><b>My Page</b></span></a></li>
		<li><a class="app-menu__item" href="emailSetting.php"><i class="app-menu__icon fa fa-cog text-warning"></i><span class="app-menu__label text-warning"><b>Settings</b>&ensp;<span class="badge badge-warning badge-pill"> Imp</span></span></a></li>
		 <li><a class="app-menu__item" href="setLimit.php"><i class="app-menu__icon fa fa-cubes"></i><span class="app-menu__label">Set Limits</span></a></li>
		<li><a href="addAnnouncement.php" class="app-menu__item"><i class="app-menu__icon fa fa-pencil-alt"></i><span class="app-menu__label"> Announcements</span></a></li>
		<li><a class="app-menu__item" href="iframePreview.php"><i class="app-menu__icon fa fa-eye"></i><span class="app-menu__label">Iframe Preview</span></a></li>
		<li><a href="subscribers.php" class="app-menu__item"><i class="app-menu__icon fa fa-chart-bar"></i><span class="app-menu__label"> Subscribers</span></a></li>
		<li><a href="comments.php" class="app-menu__item"><i class="app-menu__icon fa fa-comment"></i><span class="app-menu__label"> Comments</span></a></li>
		<li><a href="approvecomments.php" class="app-menu__item"><i class="app-menu__icon fa fa-check"></i><span class="app-menu__label"> Approved Comments</span></a></li>
		<li><a href="unapprovecomments.php" class="app-menu__item"><i class="app-menu__icon fa fa-times"></i><span class="app-menu__label"> Unapproved Comments</span></a></li>
		<li><a href="setalignment.php" class="app-menu__item"><i class="app-menu__icon fa fa-align-center"></i><span class="app-menu__label"> Design Alignment</span></a></li>
	  </ul>
    </aside>
    <main class="app-content">