<?php
function count_total_announcement($pdo){
	$Statement = $pdo->prepare("SELECT * FROM admin_announcement WHERE 1  ");
	$Statement->execute(); 
	$total = $Statement->rowCount();
	return $total ;
}
function count_total_active_announcement($pdo){
	$Statement = $pdo->prepare("SELECT * FROM admin_announcement WHERE announcement_status = '1' ");
	$Statement->execute(); 
	$total = $Statement->rowCount();
	return $total ;
}
function count_total_deactive_announcement($pdo){
	$Statement = $pdo->prepare("SELECT * FROM admin_announcement WHERE  announcement_status = '0' ");
	$Statement->execute(); 
	$total = $Statement->rowCount();
	return $total ;
}
function count_total_comments($pdo){
	$Statement = $pdo->prepare("SELECT * FROM comments WHERE 1  ");
	$Statement->execute(); 
	$total = $Statement->rowCount();
	return $total ;
}
function count_total_approved_comments($pdo){
	$Statement = $pdo->prepare("SELECT * FROM comments WHERE comment_status = '1' ");
	$Statement->execute(); 
	$total = $Statement->rowCount();
	return $total ;
}
function count_total_unapproved_comments($pdo){
	$Statement = $pdo->prepare("SELECT * FROM comments WHERE  comment_status = '0' ");
	$Statement->execute(); 
	$total = $Statement->rowCount();
	return $total ;
}
?>