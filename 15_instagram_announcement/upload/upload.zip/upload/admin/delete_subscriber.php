<?php
ob_start();
session_start();
include("db/config.php");
include("db/function_xss.php") ;
// Checking Admin is logged in or not
if($_SESSION['admin'] == '' ){
	header('location: '.ADMIN_URL.'/index.php');
	exit;
}
if(isset($_POST['btn_action']))
{
	if($_POST['btn_action'] == 'deleteSubscriber')
	{
		$delId = filter_var($_POST['delId'], FILTER_SANITIZE_NUMBER_INT);
		if($delId) { 
			$update = $pdo->prepare("DELETE FROM `tbl_subscriber`  WHERE id=?");
			$result_new = $update->execute(array($delId));
			if($result_new) {
				echo 'Subscriber Deleted Successfully.' ;		
			}
		}
	}
}
?>