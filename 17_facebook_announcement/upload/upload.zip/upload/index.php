<?php 
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: 0"); 
require_once('admin/db/config.php') ;
require_once('admin/db/function_xss.php') ;
$lim = $pdo->prepare("select * from announcement_limit where id= '1'");
$lim->execute();
$limi = $lim->fetchAll(PDO::FETCH_ASSOC);
foreach($limi as $stLimit){
	$startLim = _e($stLimit['start_lim']);
	$endLim = _e($stLimit['load_lim']);
}
$sql = "SELECT * FROM admin_announcement WHERE announcement_status='1' and pinned = '0' order by announcement_id desc LIMIT $startLim" ;
$admin_announcement = $pdo->prepare($sql);
$admin_announcement->execute(); 
$announcement = $admin_announcement->fetchAll(PDO::FETCH_ASSOC);
$total = $admin_announcement->rowCount();

$sqlPinned = "SELECT * FROM admin_announcement WHERE announcement_status='1' and pinned = '1' order by announcement_id desc LIMIT $startLim" ;
$admin_announcement_pinned = $pdo->prepare($sqlPinned);
$admin_announcement_pinned->execute(); 
$announcement_pinned = $admin_announcement_pinned->fetchAll(PDO::FETCH_ASSOC);
$total_pinned = $admin_announcement_pinned->rowCount();

$alignment_sql = "SELECT alignment,dark_mode FROM ot_admin WHERE id = '1'" ;
$alignment = $pdo->prepare($alignment_sql);
$alignment->execute(); 
$align = $alignment->fetchAll(PDO::FETCH_ASSOC);
foreach($align as $alig) {
	$design = _e($alig['alignment']);
	$darkMode = _e($alig['dark_mode']) ;
}
$bg = "";
$color = "text-muted";
$btn = "btn-light";
$border = "";
if($darkMode == '1') {
	$bg = "bg-dark" ;
	$color = "text-white";
	$border = "border border-white";
	$btn = "btn-dark";
}
function displayTextWithLinks($s) {
  return preg_replace('@(https?://([-\w\.]+[-\w])+(:\d+)?(/([\w/_\.#-]*(\?\S+)?[^\.\s])?)?)@', '<a href="$1" target="_blank">$1</a>', $s);
}
$first_no = '';
$second_no = '';
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Facebook Announcements</title>
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<meta name="description" content="Facebook Announcements">
	<link rel="stylesheet" href="<?php echo ADMIN_URL ; ?>/css/main.css">
	<link rel="stylesheet" href="<?php echo ADMIN_URL ; ?>/css/all.min.css">
	<link rel="stylesheet" href="<?php echo ADMIN_URL ; ?>/css/Latofont.css">
	<link rel="stylesheet" href="<?php echo ADMIN_URL ; ?>/css/Niconnefont.css">
	<link rel="stylesheet" href="<?php echo ADMIN_URL ; ?>/css/link.css">
	<link rel="icon" href="<?php echo ADMIN_URL; ?>/favicon.png" type="image/png">
</head>
<body class="myColor <?php echo $bg ; ?>">
<!-- Navbar-->
    <header class="app-header"><a class="app-header__logo" href=""><img src="<?php echo ADMIN_URL ; ?>/images/siteLogo.png" class="img-fluid" alt="Logo"></a>
	<!-- Navbar Right Menu-->
      <ul class="app-nav">
        <!-- User Menu-->
        <li class="dropdown"><a class="app-nav__item" href="#" data-toggle="dropdown" aria-label="Open Profile Menu"><i class="fa fa-bars fa-lg"></i></a>
          <ul class="dropdown-menu settings-menu dropdown-menu-right">
            <li><a class="dropdown-item subscribe" href="#!"><i class="fa fa-handshake fa-lg"></i> Subscribe Now</a></li>
          </ul>
        </li>
      </ul>
    </header>
<main class="page-content">
    <div class="container-fluid mt-5">
		
      <div class="row">
	  	<div class="col-lg-12 col-md-12">
			<?php 
			if($design == '0') 
			{
				require_once("alignCenter.php") ;
			}
			if($design == '1') 
			{
				require_once("alignLeft.php") ;
			}
			if($design == '2') 
			{
				require_once("alignRight.php") ;
			}
			
			?>
		</div>
	  </div>
	 
   </div>
</main> <!-- page-content" -->
<!-- Add Subscribe Modal -->
<div id="subscribeModal" class="modal fade subscribeModal">
	<div class="modal-dialog ">
		<form method="post" class="subscribe_form">
			<div class="modal-content <?php echo $bg ; ?> <?php echo $border ; ?>">
				<div class="modal-header">
					<h4 class="modal-title text-success"><i class="fa fa-bell"></i> Subscribe Now</h4>
					<button type="button" class="close <?php echo $color ; ?>" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body">
					<div class="form-group mb-3">
						<input type="email" name="subemail" id="subemail" class="form-control <?php echo $bg ; ?> <?php echo $color ; ?>" placeholder="Email Address*" maxlength="50" required autofocus>
						
					</div> 
					<div class="form-group text-left">
						<label for="message" class="<?php echo $color ; ?>"><i class="fa fa-user-circle "></i> Prove, You are Human*</label>
						<div class="input-group mb-3">
							<div class="input-group-prepend">
								<span class="input-group-text" id="basic-addon1"><span id="newfirst"></span>+<span id="newsecond"></span>
							</div>
							<input type="text" class="form-control <?php echo $bg ; ?> <?php echo $color ; ?>" placeholder="Sum & Enter Value" name="sumvalue" id="sumvalue" autocomplete="off" >
						</div>
					</div>
					<br>
					<small class="<?php echo $color ; ?>">You will never miss New Announcements. We'll Notified you via Email.</small>
					<br>
					<div class="remove-messages"></div>
				</div> 
				<div class="modal-footer"> 
					<input type="hidden" name="firstno"  id="firstno" />
					<input type="hidden" name="secondno" id="secondno" />
					<input type="hidden" name="btn_action_sb" id="btn_action_sb" value="Subscribe" />
					<input type="submit" name="action_sb" id="action_sb" class="btn btn-info" value="Subscribe" />
					<button type="button" class="btn <?php echo $btn ; ?> <?php echo $border ; ?>" data-dismiss="modal">Close</button>
				</div>
			</div>
		</form>
	</div>
</div>
<!--Success Comment Modal -->
<div id="commentSuccessModal" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content <?php echo $bg ; ?> <?php echo $border ; ?>">
			<div class="modal-header">
				<h4 class="modal-title text-success"><i class="fa fa-comment"></i> Comment Message</h4>
				
				<button type="button" class="close <?php echo $color ; ?>" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<h5 class="<?php echo $color ; ?>"> Your comment has been sent to Admin for Approval. Thanks.</h5>
			</div> 
			<div class="modal-footer"> 
				<button type="button" class="btn <?php echo $btn ; ?> <?php echo $border ; ?>" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>
<!--Success Subscriber Modal -->
<div id="sbSuccessModal" class="modal fade">
	<div class="modal-dialog ">
		<div class="modal-content <?php echo $bg ; ?> <?php echo $border ; ?>">
			<div class="modal-header">
				<h4 class="modal-title text-success"><i class="fa fa-bell"></i> Subscriber</h4>
				
				<button type="button" class="close <?php echo $color ; ?>" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<h5 class="<?php echo $color ; ?>"> Thanks for Subscribing Us. We'll Notified you via Email whenever New Announcement Posts.</h5>
			</div> 
			<div class="modal-footer"> 
				<button type="button" class="btn btn-light" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript" src="<?php echo ADMIN_URL ; ?>/js/jquery-3.5.1.min.js"></script>
<script type="text/javascript" src="<?php echo ADMIN_URL ; ?>/js/popper.min.js"></script>
<script type="text/javascript" src="<?php echo ADMIN_URL ; ?>/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo BASE_URL ; ?>user.js"></script>
</body>
</html>
