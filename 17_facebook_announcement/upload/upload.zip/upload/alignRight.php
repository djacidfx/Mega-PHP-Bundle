<div class="row">
				<div class="col-md-4 col-lg-4">
					
				</div>
				<div class="col-md-4 col-lg-4">
				
				</div>
				<div class="col-md-4 col-lg-4">
				<?php include_once("common_announce.php") ; ?>
				</div>
</div>
