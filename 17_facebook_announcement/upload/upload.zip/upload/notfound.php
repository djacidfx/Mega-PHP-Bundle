<!DOCTYPE html>
<html>
<head>
	
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Not Found</title>
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<link rel="stylesheet" type="text/css" href="<?php echo ADMIN_URL ; ?>/css/main.css" />
	<link rel="stylesheet" href="<?php echo ADMIN_URL ; ?>/css/all.min.css">
	<link rel="stylesheet" href="<?php echo ADMIN_URL ; ?>/css/Latofont.css">
	<link rel="stylesheet" href="<?php echo ADMIN_URL ; ?>/css/Niconnefont.css">
	<link rel="icon" href="<?php echo ADMIN_URL; ?>/favicon.png" type="image/png">
</head>
<body class="myColor <?php echo $bg ; ?>">
<!-- Navbar-->
    <header class="app-header"><a class="app-header__logo" href=""><img src="<?php echo ADMIN_URL ; ?>/images/siteLogo.png" class="img-fluid" alt="Logo"></a>
	<!-- Navbar Right Menu-->
      <ul class="app-nav">
        <!-- User Menu-->
        <li class="dropdown"><a class="app-nav__item" href="#" data-toggle="dropdown" aria-label="Open Profile Menu"><i class="fa fa-bars fa-lg"></i></a>
          <ul class="dropdown-menu settings-menu dropdown-menu-right">
            <li><a class="dropdown-item subscribe" href="#!"><i class="fa fa-handshake fa-lg"></i> Subscribe Now</a></li>
          </ul>
        </li>
      </ul>
    </header>
<main class="">
    <div class="container-fluid mt-5">
      <div class="row">
	  	<div class="col-lg-12 col-md-12">
		<div class="row mt-3">
				<div class="col-md-3 col-lg-3"></div>
				<div class="col-md-6 col-lg-6">
					<div class="card-deck mb-3 text-center  ">
					<div class="card mb-3 box-shadow basic-my-div shadow-lg p-4">
						<h5 class="text-danger">Sorry, But The Announcement You are Looking for Either Not Exist or Disabled By Admin.</h5>
					</div>
					</div>
				</div>
				<div class="col-md-3 col-lg-3"></div>
		</div>
		</div>
	</div>
	</div>
</main>
</body>
</html>