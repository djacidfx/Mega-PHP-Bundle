<?php
ob_start();
session_start();
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: 0"); 
include("db/config.php");
include("db/function_xss.php");
// Checking Admin is logged in or not
if($_SESSION['admin'] == '' ){
	header('location: '.ADMIN_URL.'/index.php');
	exit;
}
$newurl = filter_var($_POST['newurl'], FILTER_SANITIZE_URL) ;
$container = filter_var($_POST['container'], FILTER_SANITIZE_NUMBER_INT) ;

?>
<link type="text/css" rel="stylesheet" href="<?php echo ADMIN_URL ; ?>/iframe.css" />
<?php if($container == "46") { ?>
	<div class="iframe-container-46">
<?php } if($container == "64") { ?>
	<div class="iframe-container-64">
<?php } if($container == "66") { ?>
	<div class="iframe-container-66">
<?php } if($container == "100") { ?>
	<div class="iframe-container-100">
<?php } ?>
		<iframe class="myIframe" src="<?php echo $newurl ; ?>" scrolling="yes"></iframe>
	</div>
