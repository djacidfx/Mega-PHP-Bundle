<?php 
ob_start();
session_start();
include 'admin/db/config.php'; 
unset($_SESSION['type']);
header("location: ".BASE_URL."index.php"); 
?>
