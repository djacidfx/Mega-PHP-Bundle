<?php include("user_header.php") ; ?>
<div class="app-title">
        <div>
          <h1><i class="fa fa-laptop"></i> User Dashboard</h1>
          <p>Hassle Free Dashboard to Analysis. </p>
		  <div class="remove-messages"></div>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
          <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
        </ul>
 </div>
 <div class="row">
 		<div class="col-lg-12 col-md-12">
				<h5 class="border-bottom text-muted">Today Analysis</h5>
			</div>
        <div class="col-md-6 col-lg-3">
          <div class="widget-small primary coloured-icon"><i class="icon fa fa-shopping-bag fa-3x"></i>
            <div class="info">
              <h5 class="font-italic text-muted">Orders</h5>
              <p><b><?php echo count_total_order_curday($pdo); ?></b></p>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-3">
          <div class="widget-small info coloured-icon"><i class="icon fa fa-bookmark fa-3x"></i>
            <div class="info">
              <h5 class="font-italic text-muted">Orders Amount</h5>
              <p><b><?php echo fetch_currency($pdo)."&ensp;".count_total_order_value_curday($pdo); ?></b></p>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-3">
          <div class="widget-small warning coloured-icon"><i class="icon fa fa-fire fa-3x"></i>
            <div class="info">
              <h5 class="font-italic text-muted">Taxable Amt</h5>
              <p><b><?php echo fetch_currency($pdo)."&ensp;".count_total_orderwithouttax_value_curday($pdo); ?></b></p>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-3">
          <div class="widget-small danger coloured-icon"><i class="icon fa fa-exclamation-circle fa-3x"></i>
            <div class="info">
              <h5 class="font-italic text-muted">Tax Amount</h5>
              <p><b><?php echo fetch_currency($pdo)."&ensp;".count_total_ordertax_value_curday($pdo); ?></b></p>
            </div>
          </div>
        </div>
      </div>
 <div class="row">
 		<div class="col-lg-12 col-md-12">
				<h5 class="border-bottom text-muted">This Month Analysis</h5>
			</div>
        <div class="col-md-6 col-lg-3">
          <div class="widget-small primary coloured-icon"><i class="icon fa fa-shopping-bag fa-3x"></i>
            <div class="info">
              <h5 class="font-italic text-muted">Orders</h5>
              <p><b><?php echo count_total_order_curmonth($pdo); ?></b></p>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-3">
          <div class="widget-small info coloured-icon"><i class="icon fa fa-bookmark fa-3x"></i>
            <div class="info">
              <h5 class="font-italic text-muted">Orders Amount</h5>
              <p><b><?php echo fetch_currency($pdo)."&ensp;".count_total_order_value_curmonth($pdo); ?></b></p>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-3">
          <div class="widget-small warning coloured-icon"><i class="icon fa fa-fire fa-3x"></i>
            <div class="info">
              <h5 class="font-italic text-muted">Taxable Amt</h5>
              <p><b><?php echo fetch_currency($pdo)."&ensp;".count_total_orderwithouttax_value_curmonth($pdo); ?></b></p>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-3">
          <div class="widget-small danger coloured-icon"><i class="icon fa fa-exclamation-circle fa-3x"></i>
            <div class="info">
              <h5 class="font-italic text-muted">Tax Amount</h5>
              <p><b><?php echo fetch_currency($pdo)."&ensp;".count_total_ordertax_value_curmonth($pdo); ?></b></p>
            </div>
          </div>
        </div>
      </div>
	<div class="row">
 		<div class="col-lg-12 col-md-12">
				<h5 class="border-bottom text-muted">Total Analysis</h5>
			</div>
        <div class="col-md-6 col-lg-3">
          <div class="widget-small primary coloured-icon"><i class="icon fa fa-shopping-bag fa-3x"></i>
            <div class="info">
              <h5 class="font-italic text-muted">Orders</h5>
              <p><b><?php echo count_total_order($pdo); ?></b></p>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-3">
          <div class="widget-small info coloured-icon"><i class="icon fa fa-bookmark fa-3x"></i>
            <div class="info">
              <h5 class="font-italic text-muted">Orders Amount</h5>
              <p><b><?php echo fetch_currency($pdo)."&ensp;".count_total_order_value($pdo); ?></b></p>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-3">
          <div class="widget-small warning coloured-icon"><i class="icon fa fa-fire fa-3x"></i>
            <div class="info">
              <h5 class="font-italic text-muted">Taxable Amt</h5>
              <p><b><?php echo fetch_currency($pdo)."&ensp;".count_total_orderwithouttax_value($pdo); ?></b></p>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-3">
          <div class="widget-small danger coloured-icon"><i class="icon fa fa-exclamation-circle fa-3x"></i>
            <div class="info">
              <h5 class="font-italic text-muted">Tax Amount</h5>
              <p><b><?php echo fetch_currency($pdo)."&ensp;".count_total_ordertax_value($pdo); ?></b></p>
            </div>
          </div>
        </div>
      </div>
		
		<div class="row mar-top-auto">
			<div class="col-lg-12 col-md-12">
				<div class="row">
		   			<div class="col-md-12 col-lg-12">
						<div class="panel panel-default">
							<div class="panel-heading">
								<div class="page-heading"> <h6 class="text-muted mt-4">Total Order</h6></div>
							</div> <!-- /panel-heading -->
							<div class="panel-body">
								<div class="remove-messages"></div>
								<div class="row">
									<div class="col-md-12">
									  <div class="tile">
										<div class="tile-body">
											<div class="table-responsive">
												<table class="table table-bordered table-hover" id="manageUserOrderTable">
													<thead>
														<tr>
															<th>Order No.</th>	
															<th>Order Date</th>				
															<th>Total Amount</th>
															<th>Taxable Amount</th>
															<th>Tax Amount</th>
															<th>Download</th>
														</tr>
													</thead>
												</table><!-- /table -->
											</div>
										</div>
									</div>
								</div>
							</div>
							</div> <!-- /panel-body -->
					</div> <!-- /panel -->	
					</div>
				</div>
			</div>
		</div>

<?php include("user_footer.php") ; ?>