<?php 
require_once('user_header.php');
?>
<div class="container mar-top">
	<div class="row">
		<div class="col-lg-12 col-md-12">
			<div class="row">
				<div class="col-lg-3 col-md-3"></div>
				<div class="col-lg-6 col-md-6">
					<div class="card">
                		<div class="card-header bg-secondary text-white text-center"><h4> User Detail</h4></div>
                		<div class="card-body">
							<form>
							<div class="row">
								<div class="col-lg-6">
									<div class="form-group">
										<label for="username"><i class="fa fa-key text-success"></i>UserName</label>
										<input type="text" class="form-control" name="companyname" id="companyname" placeholder="Name" maxlength="50" value="<?php echo $customer_username ; ?>" readonly="readonly">
									</div>
								</div>
								<div class="col-lg-6">
									<div class="form-group">
										<label for="name"><i class="fa fa-address-book text-success"></i> Name</label>
										<input type="text" class="form-control" value="<?php echo $customer_name ; ?>" readonly="readonly">
									</div>
								</div>
							</div>
								<div class="row">
									<div class="col-lg-6">
										<div class="form-group">
											<label for="email"><i class="fa fa-envelope text-success"></i> Email</label>
											<input type="email" class="form-control" value="<?php echo $customer_email ; ?>" readonly="readonly">
										</div>
									</div>
									<div class="col-lg-6">
										<div class="form-group">
											<label for="phone"><i class="fa fa-phone-square text-success"></i> Phone</label>
											<input type="text" class="form-control"  value="<?php echo $customer_phone ; ?>" readonly="readonly">
										</div>
									</div>
								</div>
								
								<div class="form-group">
									<label for="message"><i class="fa fa-comment text-success"></i> Tax No.</label>
									<input type="text" class="form-control" value="<?php echo $customer_tax_no; ?>" readonly="readonly">
								</div>
								
							</form>
                		</div>
           			 </div>
				</div>
				<div class="col-lg-3 col-md-3"></div>
			</div>
		</div>
	</div>
</div>
<?php require_once('user_footer.php'); ?>