<?php
ob_start();
session_start();
include("admin/db/config.php");
include("admin/db/function_xss.php");
// Checking User is logged in or not
if( ($_SESSION['type']['customer_id'] == '') ){
	header('location: '.BASE_URL.'index.php');
	exit;
}

$Statement = $pdo->prepare("select * from billing_order where order_customer_id = '".$_SESSION['type']['customer_id']."' and order_status = '1' order by order_id desc");
$Statement->execute();
$total = $Statement->rowCount();    
$result = $Statement->fetchAll(PDO::FETCH_ASSOC); 
$output = array('data' => array());
if($total > 0) {
	foreach($result as $row) {
		$orderId = _e($row['order_id']) ;
		$customerId = _e($row['order_customer_id']) ;
		$orderTotal = _e($row['order_total']) ;
		$orderDate = _e($row['order_date']) ;
		$productDetail = "";
		$product_statement = $pdo->prepare("select sum(cast((REPLACE(CONCAT(billing_order_detail.product_price_beforetax), ',', '')) as decimal(10,2))) as ProductTotalPriceBeforeTax, sum(cast((REPLACE(CONCAT(billing_order_detail.product_price_taxamount), ',', '')) as decimal(10,2))) as TaxAmount from billing_order_detail where billing_order_id= ?");
		$product_statement->execute(array($orderId));
		$result_product = $product_statement->fetchAll(PDO::FETCH_ASSOC);
		$total = $product_statement->rowCount();
		if($total > 0) {
			foreach ($result_product as $product) {
				$TaxAmount = _e($product['TaxAmount']) ;
				$ProductTotalPriceBeforeTax = _e($product['ProductTotalPriceBeforeTax']) ;
			}
		}
		
		$download = '<a href="admin/view_order.php?pdf=1&oid='.$orderId.'&cid='.$_SESSION['type']['customer_id'].'" target="_blank" class="btn btn-sm btn-success">Download</a>';
		
		$output['data'][] = array( 		
		$orderId,
		$orderDate,
		$orderTotal,
		$ProductTotalPriceBeforeTax,
		$TaxAmount,
		$download
		);
		
	}
}
echo json_encode($output);
?>
