<?php
ob_start();
session_start();
require_once("admin/db/config.php");
require_once("admin/db/function_xss.php");
if( !empty($_POST['username']) && !empty($_POST['password']) ){
	$username = filter_var($_POST['username'], FILTER_SANITIZE_STRING) ;
	$password = filter_var($_POST['password'], FILTER_SANITIZE_STRING) ;
	$userAuthentication =  $pdo->prepare("SELECT * FROM billing_user WHERE customer_username=? and customer_status=?");
	$userAuthentication->execute(array($username,filter_var("1", FILTER_SANITIZE_NUMBER_INT)));
	$user_ok = $userAuthentication->rowCount();
	$userData = $userAuthentication->fetchAll(PDO::FETCH_ASSOC);
	if($user_ok > 0) {
		foreach($userData as $row){
			$auth_pass = _e($row['customer_password']) ;
		}
			if(password_verify($password, $auth_pass)) {
				$_SESSION['type'] = $row ;
				header("location: ".BASE_URL."dashboard.php");
			} else {
				$_SESSION['error_message'] = 'Either wrong Username or Password. Try Again.';
				header("location: ".BASE_URL."index.php");
			}
	}
	else {
		$_SESSION['error_message'] = 'Either wrong Username or Account Deactivated.';
		header("location: ".BASE_URL."index.php");
	}

} else {
	$_SESSION['error_message'] = 'Username/Password cannot be empty.';
	header("location: ".BASE_URL."index.php");
}
?>